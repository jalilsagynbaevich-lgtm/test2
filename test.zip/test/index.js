const data = [
  {
    "_id": "697498d6f72c0a6e41fa1700",
    "question": "Как типизировать payload в Redux Toolkit? / Redux Toolkitте payload кантип типтеш керек?",
    "options": [
      "action.payload / action.payload",
      "PayloadAction<T> / PayloadAction<T>",
      "useDispatch / useDispatch",
      "createStore / createStore"
    ],
    "answer": "PayloadAction<T> / PayloadAction<T>",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f0",
    "question": "Для чего используется dispatch? / Dispatch эмне үчүн колдонулат?",
    "options": [
      "Для получения данных / Маалымат алуу үчүн",
      "Для отправки action / Action жөнөтүү үчүн",
      "Для роутинга / Роутинг үчүн",
      "Для подписки / Подписка үчүн"
    ],
    "answer": "Для отправки action / Action жөнөтүү үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f1",
    "question": "Что такое typed dispatch в Redux с TypeScript? / Reduxте typed dispatch деген эмне?",
    "options": [
      "dispatch без типов / Типсиз dispatch",
      "dispatch с AppDispatch / AppDispatch менен dispatch",
      "dispatch из React / Reactтен dispatch",
      "dispatch только для async / Async үчүн гана"
    ],
    "answer": "dispatch с AppDispatch / AppDispatch менен dispatch",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f4",
    "question": "Что делает useSelector? / useSelector эмнени аткарат?",
    "options": [
      "Изменяет state / State өзгөртөт",
      "Получает данные из store / Storeдон маалымат алат",
      "Создает store / Store түзөт",
      "Делает запрос / Суроо аткарат"
    ],
    "answer": "Получает данные из store / Storeдон маалымат алат",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f6",
    "question": "Какой CSS-код создаёт FlexBox-контейнер с горизонтальным расположением элементов и переносом строк? / Горизонталдуу FlexBox контейнер жана саптарды өткөрүү коду?",
    "options": [
      "display: flex; flex-direction: row; flex-wrap: wrap;",
      "display: flex; flex-direction: column; flex-wrap: nowrap;",
      "display: grid; flex-direction: row; flex-wrap: wrap;",
      "display: flex; flex-direction: row; wrap: wrap;"
    ],
    "answer": "display: flex; flex-direction: row; flex-wrap: wrap;",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f8",
    "question": "Как создать store в Redux Toolkit? / Redux Toolkitте store кантип түзүлөт?",
    "options": [
      "createStore(reducer) / createStore(reducer)",
      "configureStore({ reducer }) / configureStore({ reducer })",
      "new Store(reducer) / new Store(reducer)",
      "Redux.createStore(reducer) / Redux.createStore(reducer)"
    ],
    "answer": "configureStore({ reducer }) / configureStore({ reducer })",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f9",
    "question": "Где обычно объявляется RootState? / RootState көбүнчө кайсы жерде жарыяланат?",
    "options": [
      "В компоненте / Компонентте",
      "В store файле / Store файлында",
      "В slice / Slice ичинде",
      "В CSS / CSSде"
    ],
    "answer": "В store файле / Store файлында",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16fd",
    "question": "Где типизируется initialState в slice? / Slice ичиндеги initialState кантип типтеш керек?",
    "options": [
      "В reducers / Reducerде",
      "В createSlice / createSlice ичинде",
      "В интерфейсе состояния / State интерфейсинде",
      "В компоненте / Компонентте"
    ],
    "answer": "В createSlice / createSlice ичинде",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f7",
    "question": "Что делает setInterval? / setInterval эмнени аткарат?",
    "options": [
      "Выполняет код один раз / Кодду бир жолу аткарат",
      "Выполняет код с задержкой / Кодду кечиктирип аткарат",
      "Выполняет код регулярно / Кодду үзгүлтүксүз аткарат",
      "Останавливает таймер / Таймерди токтотот"
    ],
    "answer": "Выполняет код регулярно / Кодду үзгүлтүксүз аткарат",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f3",
    "question": "Как сохранить данные в localStorage? / localStorage’га маалыматты кантип сактайбыз?",
    "options": [
      "localStorage.add() / localStorage.add()",
      "localStorage.save() / localStorage.save()",
      "localStorage.setItem() / localStorage.setItem()",
      "localStorage.push() / localStorage.push()"
    ],
    "answer": "localStorage.setItem() / localStorage.setItem()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16fc",
    "question": "Что такое initialState в slice? / Slice ичиндеги initialState деген эмне?",
    "options": [
      "Reducer логикасы / Reducer логикасы",
      "Начальное состояние / Баштапкы абал",
      "Action генерациясы / Action генерациясы",
      "Middleware / Middleware"
    ],
    "answer": "Начальное состояние / Баштапкы абал",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1709",
    "question": "то улучшает поддержку кода в TypeScript? / TypeScriptте эмнени колдонуу кодду жакшыраак кылат?",
    "options": [
      "any / any",
      "enums и типы / Enumдар жана типтер",
      "console.log / console.log",
      "var / var"
    ],
    "answer": "enums и типы / Enumдар жана типтер",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1701",
    "question": "Что типизирует payload в Redux Toolkit? / Redux Toolkitте payload эмнени типтешет?",
    "options": [
      "action.payload / action.payload",
      "PayloadAction<T> / PayloadAction<T>",
      "useDispatch / useDispatch",
      "createStore / createStore"
    ],
    "answer": "PayloadAction<T> / PayloadAction<T>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1704",
    "question": "Что НЕ является best practice в Redux? / Reduxте кайсысы best practice эмес?",
    "options": [
      "Использовать any / any колдонуу",
      "Типизировать props / Propsти типтөө",
      "Использовать generics / Generics колдонуу",
      "Строгая типизация / Катуу типтөө"
    ],
    "answer": "Использовать any / any колдонуу",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1705",
    "question": "Что НЕ является best practice в TypeScript? / TypeScriptте кайсысы best practice эмес?",
    "options": [
      "Использовать any / any колдонуу",
      "Типизировать props / Propsти типтөө",
      "Использовать generics / Generics колдонуу",
      "Строгая типизация / Катуу типтөө"
    ],
    "answer": "Использовать any / any колдонуу",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f2",
    "question": "Какой тег используется для подключения Google Fonts? / Google Fonts кошуу үчүн кайсы тег колдонулат?",
    "options": [
      "<style> / <style>",
      "<link> / <link>",
      "<script> / <script>",
      "<font> / <font>"
    ],
    "answer": "<link> / <link>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16f5",
    "question": "Как типизировать useSelector? / useSelector кантип типтеш керек?",
    "options": [
      "useSelector<any> / useSelector<any>",
      "TypedUseSelectorHook / TypedUseSelectorHook",
      "useSelector<State> / useSelector<State>",
      "selector() / selector()"
    ],
    "answer": "TypedUseSelectorHook / TypedUseSelectorHook",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16fb",
    "question": "Как получить данные с сервера? / Сервердеги маалыматты кантип алабыз?",
    "options": [
      "fetch / fetch",
      "getData / getData",
      "axios() / axios()",
      "request() / request()"
    ],
    "answer": "fetch / fetch",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16fe",
    "question": "Какой CSS-код размещает элемент в правом нижнем углу контейнера с position: relative? / position: relative контейнерде элементти төмөнкү оң бурчка коюу?",
    "options": [
      "position: absolute; bottom: 0; right: 0;",
      "position: relative; bottom: 0; right: 0;",
      "position: fixed; bottom: 0; right: 0;",
      "position: absolute; bottom: 10px; right: 10px;"
    ],
    "answer": "position: absolute; bottom: 0; right: 0;",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1706",
    "question": "Какая разница между visibility: hidden и display: none? / visibility: hidden менен display: none айырмасы эмнеде?",
    "options": [
      "Они идентичны / Экиси бирдей",
      "Первый скрывает, но оставляет место; второй — полностью убирает / Биринчиси жашырат, бирок орун калтырат; экинчиси толугу менен жок кылат",
      "Первый удаляет элемент; второй прячет / Биринчиси жок кылат, экинчиси жашырат",
      "Первый работает в Safari / Биринчиси Safariда гана иштейт"
    ],
    "answer": "Первый скрывает, но оставляет место; второй — полностью убирает / Биринчиси жашырат, бирок орун калтырат; экинчиси толугу менен жок кылат",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1708",
    "question": "Что показывает уровень React Redux разработчика? / React Redux программисттин деңгээлин эмнеден көрүүгө болот?",
    "options": [
      "Верстка / Верстка",
      "Умение писать классы / Класстарды жазуу жөндөмү",
      "Типизированный SPA с Redux / TypeScript менен типтештирилген SPA Redux",
      "Только знание JS / Тек JS билүү"
    ],
    "answer": "Типизированный SPA с Redux / TypeScript менен типтештирилген SPA Redux",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1707",
    "question": "Что такое this? / this деген эмне?",
    "options": [
      "Функция / Функция",
      "Класс / Класс",
      "Контекст вызова / Чакыруу контексти",
      "Объект window всегда / Ар дайым window объектиси"
    ],
    "answer": "Контекст вызова / Чакыруу контексти",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1703",
    "question": "Как объявить функцию через стрелочную запись? / Функцияны стрелка менен кантип жазабыз?",
    "options": [
      "function myFunc() {} / function myFunc() {}",
      "const myFunc = () => {} / const myFunc = () => {}",
      "var myFunc = function() {} / var myFunc = function() {}",
      "func myFunc = {} / func myFunc = {}"
    ],
    "answer": "const myFunc = () => {} / const myFunc = () => {}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1702",
    "question": "Как задать анимацию с использованием CSS? / CSS менен анимация кантип берүү керек?",
    "options": [
      "animation: mymove 3s infinite;",
      "transition: mymove 3s;",
      "motion: mymove 3s;",
      "effect: mymove;"
    ],
    "answer": "animation: mymove 3s infinite;",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ff",
    "question": "Что делает async/await? / async/await эмнени аткарат?",
    "options": [
      "Ускоряет код / Кодду тездетет",
      "Делает код синхронным / Кодду синхрон кылат",
      "Упрощает работу с Promise / Promise менен иштөөнү жеңилдетет",
      "Удаляет then / then’ди жок кылат"
    ],
    "answer": "Упрощает работу с Promise / Promise менен иштөөнү жеңилдетет",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16fa",
    "question": "Каким способом можно задать несколько стилей одновременно к одному элементу? / Бир эле элементке бир нече стиль кантип берүү керек?",
    "options": [
      "Использовать несколько style / Бир нече style колдонуу",
      "Использовать , между селекторами / Селекторлорду \",\" менен колдонуу",
      "Обернуть элемент в div / Элементти div ичине салуу",
      "Использовать id и class вместе / id жана classты бирге колдонуу"
    ],
    "answer": "Использовать , между селекторами / Селекторлорду \",\" менен колдонуу",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.177Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b0",
    "question": "Как правильно назвать компонент? / Компонентти кантип туура атаса болот?",
    "options": [
      "header / header",
      "myComponent / myComponent",
      "Header / Header",
      "component / component"
    ],
    "answer": "Header / Header",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c4",
    "question": "Где чаще всего делают API запросы в React? / Reactте API суроо кайсы жерде көп жасалат?",
    "options": [
      "В render / render ичинде",
      "В useEffect / useEffect ичинде",
      "В JSX / JSX ичинде",
      "В CSS / CSS ичинде"
    ],
    "answer": "В useEffect / useEffect ичинде",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ad",
    "question": "Какой тип предпочтительнее использовать вместо any? / Anyнин ордуна кайсы типти колдонуу сунушталат?",
    "options": [
      "any / any",
      "unknown / unknown",
      "var / var",
      "null / null"
    ],
    "answer": "unknown / unknown",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a8",
    "question": "Как правильно вставить JS в JSX? / JSXке JS кантип туура киргизилет?",
    "options": [
      "{{ value }} / {{ value }}",
      "<% value %> / <% value %>",
      "{ value } / { value }",
      "( value ) / ( value )"
    ],
    "answer": "{ value } / { value }",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16cb",
    "question": "Как обратиться к свойству объекта? / Объекттин касиетине кантип кайрылсак болот?",
    "options": [
      "obj[property] / obj[property]",
      "obj.property / obj.property",
      "Оба варианта / Эки вариант тең",
      "Только через [] / Тек [] аркылуу"
    ],
    "answer": "Оба варианта / Эки вариант тең",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16da",
    "question": "Какой медиа-запрос применяется для экранов шириной меньше 768px? / Экраны 768pxден кичине болгондор үчүн медиа-запрос кандай болот?",
    "options": [
      "@screen and (min-width:768px)",
      "@media screen and (max-width:768px)",
      "@media screen only",
      "@max-width(768px)"
    ],
    "answer": "@media screen and (max-width:768px)",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16dc",
    "question": "Когда useCallback наиболее полезен? / useCallback качан эң пайдалуу?",
    "options": [
      "При работе с формами / Формалар менен иштөөдө",
      "При передаче функций в дочерние компоненты / Функцияларды балалык компоненттерге өткөрүүдө",
      "Для роутинга / Роутинг үчүн",
      "Для стилей / Стиль үчүн"
    ],
    "answer": "При передаче функций в дочерние компоненты / Функцияларды балалык компоненттерге өткөрүүдө",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e2",
    "question": "В чём отличие transition и animation? / transition менен animation айырмасы эмнеде?",
    "options": [
      "Никакого / Айырмасы жок",
      "animation работает только на hover / animation тек hoverда иштейт",
      "transition — для плавных изменений, animation — для сложных движений / transition — жумшак өзгөрүүлөр үчүн, animation — татаал кыймылдар үчүн",
      "transition делает элементы блочными / transition элементтерди блочными кылат"
    ],
    "answer": "transition — для плавных изменений, animation — для сложных движений / transition — жумшак өзгөрүүлөр үчүн, animation — татаал кыймылдар үчүн",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e6",
    "question": "Какой HTML-код создаёт ссылку на \"https://example.com \" с текстом \"Посетить\"? / \"https://example.com \" шилтемесин \"Посетить\" текст менен кантип түзөбүз?",
    "options": [
      "<a href=\"https://example.com\">Посетить</a>",
      "<link src=\"https://example.com\">Посетить</link>",
      "<a src=\"https://example.com\">Посетить</a>",
      "<a url=\"https://example.com\">Посетить</a>"
    ],
    "answer": "<a href=\"https://example.com\">Посетить</a>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ee",
    "question": "Какой способ центрирования лучше использовать для блока по вертикали и горизонтали в Flexbox? / Flexboxта блокту вертикалдуу жана горизонталдуу борборлоонун эң жакшы жолу?",
    "options": [
      "align-items: center; justify-content: center;",
      "margin: auto;",
      "float: center;",
      "position: absolute;"
    ],
    "answer": "align-items: center; justify-content: center;",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e4",
    "question": "Что такое Redux Toolkit? / Redux Toolkit деген эмне?",
    "options": [
      "Отдельный Redux / Өзүнчө Redux",
      "Надстройка над Redux / Redux үстүндө надстройка",
      "CSS библиотека / CSS китепкана",
      "Router / Роутер"
    ],
    "answer": "Надстройка над Redux / Redux үстүндө надстройка",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ab",
    "question": "Как объявить переменную (ES6)? / Өзгөрмөнү ES6 менен кантип жарыялайбыз?",
    "options": [
      "var / var",
      "let / let",
      "const / const",
      "B и C / B жана C"
    ],
    "answer": "const / const",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b1",
    "question": "Что такое union тип? / Union тип деген эмне?",
    "options": [
      "Объединение типов через & / & аркылуу бириктирүү",
      "Один тип / Бир тип",
      "Объединение типов через | / | аркылуу бириктирүү",
      "Наследование / Наследование"
    ],
    "answer": "Объединение типов через | / | аркылуу бириктирүү",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b5",
    "question": "Что означает тип string | number? / string | number деген эмне?",
    "options": [
      "Только string / Тек string",
      "Только number / Тек number",
      "string И number / string жана number",
      "string ИЛИ number / string же number"
    ],
    "answer": "string ИЛИ number / string же number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16bb",
    "question": "Какое условие используется чаще всего? / Эң көп колдонулган шарттык оператор кайсы?",
    "options": [
      "switch / switch",
      "if / else / if / else",
      "for / for",
      "while / while"
    ],
    "answer": "if / else / if / else",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16cc",
    "question": "Для чего используется Context API? / Context API эмне үчүн колдонулат?",
    "options": [
      "Для роутинга / Роутинг үчүн",
      "Для глобального состояния / Глобалдык state үчүн",
      "Для стилей / Стиль үчүн",
      "Для API запросов / API суроо үчүн"
    ],
    "answer": "Для глобального состояния / Глобалдык state үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d1",
    "question": "Где чаще всего используют generics? / Generics көбүнчө кайсы жерде колдонулат?",
    "options": [
      "В CSS / CSS ичинде",
      "В функциях и хуках / Функциялар жана хуктарда",
      "В HTML / HTMLде",
      "В роутинге / Роутингде"
    ],
    "answer": "В функциях и хуках / Функциялар жана хуктарда",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d4",
    "question": "Что такое custom hook? / Custom hook деген эмне?",
    "options": [
      "Компонент / Компонент",
      "Обычная функция / Жай функция",
      "Функция с хуками / Хук менен функция",
      "Redux middleware / Redux middleware"
    ],
    "answer": "Функция с хуками / Хук менен функция",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d9",
    "question": "Когда лучше использовать enum? / Enum качан колдонуу жакшы?",
    "options": [
      "Для случайных значений / Кездейсоқ маанилер үчүн",
      "Для фиксированных значений / Туруктуу маанилер үчүн",
      "Для API / API үчүн",
      "Для форм / Формалар үчүн"
    ],
    "answer": "Для фиксированных значений / Туруктуу маанилер үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16dd",
    "question": "Как типизировать функциональный компонент в React с TS? / React функционалдык компонентти TS менен кантип типтеш керек?",
    "options": [
      "const Comp = () => {} / const Comp = () => {}",
      "const Comp: FC = () => {} / const Comp: FC = () => {}",
      "function Comp() {} / function Comp() {}",
      "React.Comp() / React.Comp()"
    ],
    "answer": "const Comp: FC = () => {} / const Comp: FC = () => {}",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e1",
    "question": "Где типизируются props? / Props кайсы жерде типтеш керек?",
    "options": [
      "В useEffect / useEffect ичинде",
      "В аргументах компонента / Компоненттин аргументинде",
      "В JSX / JSX ичинде",
      "В CSS / CSS ичинде"
    ],
    "answer": "В аргументах компонента / Компоненттин аргументинде",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ec",
    "question": "Что хранится в store? / Store эмнени сактайт?",
    "options": [
      "JSX / JSX",
      "Props / Props",
      "Глобальное состояние / Глобалдык state",
      "Локальный state / Локалдык state"
    ],
    "answer": "Глобальное состояние / Глобалдык state",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16be",
    "question": "В чём разница между em и rem? / em менен rem айырмасы эмнеде?",
    "options": [
      "Одинаковые / Бирдей",
      "em зависит от html, rem — от родителя / em htmlдан көз каранды, rem ата-энеден",
      "em зависит от родителя, rem — от корня документа / em ата-энеден көз каранды, rem түп-тексттен",
      "Оба отступают одинаково / Экиси тең бирдей"
    ],
    "answer": "em зависит от родителя, rem — от корня документа / em ата-энеден көз каранды, rem түп-тексттен",
    "category": "html",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c6",
    "question": "Что даёт использование БЭМ? / BEM колдонгондо кандай артыкчылык болот?",
    "options": [
      "Ускоряет загрузку сайта / Сайтты тез жүктөйт",
      "Делает CSS-код читаемым и переиспользуемым / CSS кодун окумдуу жана кайра колдонулуучу кылат",
      "Делает сайт адаптивным / Сайтты адаптивдүү кылат",
      "Убирает лишние отступы / Артыкча отступтарды жок кылат"
    ],
    "answer": "Делает CSS-код читаемым и переиспользуемым / CSS кодун окумдуу жана кайра колдонулуучу кылат",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b9",
    "question": "Что такое intersection тип? / Intersection тип деген эмне?",
    "options": [
      "| / |",
      "& / &",
      "? / ?",
      "=> / =>"
    ],
    "answer": "& / &",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b8",
    "question": "Для чего используются props? / Props эмне үчүн колдонулат?",
    "options": [
      "Для хранения состояния / State сактоо үчүн",
      "Для передачи данных / Маалымат өткөрүү үчүн",
      "Для работы с DOM / DOM менен иштөө үчүн",
      "Для навигации / Навигация үчүн"
    ],
    "answer": "Для передачи данных / Маалымат өткөрүү үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b7",
    "question": "Какой оператор сравнивает по значению и типу? / Кайсы оператор мааниге жана типке салыштырат?",
    "options": [
      "== / ==",
      "= / =",
      "=== / ===",
      "!= / !="
    ],
    "answer": "=== / ===",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b4",
    "question": "Что возвращает React-компонент? / React компонент эмне кайтарат?",
    "options": [
      "HTML / HTML",
      "JSX / JSX",
      "CSS / CSS",
      "JSON / JSON"
    ],
    "answer": "JSX / JSX",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ae",
    "question": "Какой селектор выберет все <p> внутри <div> с классом .article? / .article классындагы <div> ичиндеги бардык <p> элементтерди тандаган селектор кайсы?",
    "options": [
      ".article.p / .article.p",
      "div.article, p / div.article, p",
      ".article p / .article p",
      "p.article div / p.article div"
    ],
    "answer": ".article p / .article p",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16aa",
    "question": "Какой тег HTML используется для вставки другой веб-страницы? / Башка веб-баракчаны кошуу үчүн кайсы тег колдонулат?",
    "options": [
      "<object> / <object>",
      "<iframe> / <iframe>",
      "<embed> / <embed>",
      "<link> / <link>"
    ],
    "answer": "<iframe> / <iframe>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ca",
    "question": "Чем отличается relative от absolute в CSS? / relative менен absolute айырмасы эмнеде?",
    "options": [
      "relative фиксирует элемент, а absolute делает адаптивным / relative элементти бекитет, absolute адаптив кылат",
      "relative — смещает от себя, absolute — от предка / relative өзү боюнча жылдырат, absolute ата-энеден",
      "relative работает только с текстом, absolute — с блоками / relative тек текст менен, absolute блок менен",
      "Разницы нет / Айырмасы жок"
    ],
    "answer": "relative — смещает от себя, absolute — от предка / relative өзү боюнча жылдырат, absolute ата-энеден",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c8",
    "question": "Как правильно хранить компоненты? / Компоненттерди кантип туура сактоо керек?",
    "options": [
      "В одном файле / Бир файлда",
      "Без структуры / Структурасыз",
      "По папкам (pages, components) / Папкаларга бөлүп (pages, components)",
      "Только в App.jsx / Тек App.jsx ичинде"
    ],
    "answer": "По папкам (pages, components) / Папкаларга бөлүп (pages, components)",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d3",
    "question": "Как выглядит rest параметр? / rest параметри кантип жазылат?",
    "options": [
      "...args / ...args",
      "args... / args...",
      "rest(args) / rest(args)",
      "[args] / [args]"
    ],
    "answer": "...args / ...args",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a9",
    "question": "Чем отличается unknown от any? / Unknown менен any айырмасы эмнеде?",
    "options": [
      "Ничем / Айырмасы жок",
      "unknown безопаснее / Unknown коопсузураак",
      "any строже / any катуу",
      "unknown нельзя использовать / Unknown колдонулбайт"
    ],
    "answer": "unknown безопаснее / Unknown коопсузураак",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e9",
    "question": "Как типизировать событие input? / Input событие кантип типтеш керек?",
    "options": [
      "Event / Event",
      "MouseEvent / MouseEvent",
      "ChangeEvent<HTMLInputElement> / ChangeEvent<HTMLInputElement>",
      "InputEvent / InputEvent"
    ],
    "answer": "ChangeEvent<HTMLInputElement> / ChangeEvent<HTMLInputElement>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e7",
    "question": "Какое событие срабатывает при клике? / Клик болгондо кайсы событие иштейт?",
    "options": [
      "submit / submit",
      "input / input",
      "click / click",
      "change / change"
    ],
    "answer": "click / click",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e5",
    "question": "Как типизировать useState? / useState кантип типтеш керек?",
    "options": [
      "useState<string>() / useState<string>()",
      "useState(\"text\") / useState(\"text\")",
      "Оба варианта / Эки вариант тең",
      "Нельзя / Болбойт"
    ],
    "answer": "useState<string>() / useState<string>()",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e3",
    "question": "Чем отличается append от prepend? / append менен prepend айырмасы эмнеде?",
    "options": [
      "Ничем / Айырмасы жок",
      "append — в начало / append — башына",
      "prepend — в начало / prepend — башына",
      "prepend удаляет / prepend өчүрөт"
    ],
    "answer": "prepend — в начало / prepend — башына",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e0",
    "question": "Что делает React.memo? / React.memo эмне кылат?",
    "options": [
      "Для стилизации / Стиль үчүн",
      "Для оптимизации рендера компонентов / Компоненттердин рендерин оптималдаштырат",
      "Для навигации / Навигация үчүн",
      "Для работы с формами / Формалар менен иштөө үчүн"
    ],
    "answer": "Для оптимизации рендера компонентов / Компоненттердин рендерин оптималдаштырат",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16df",
    "question": "Как создать HTML элемент через JS? / JS аркылуу HTML элементти кантип түзсөк болот?",
    "options": [
      "new Element() / new Element()",
      "document.createElement() / document.createElement()",
      "document.addElement() / document.addElement()",
      "create.element() / create.element()"
    ],
    "answer": "document.createElement() / document.createElement()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16db",
    "question": "Что делает classList.add()? / classList.add() эмнени аткарат?",
    "options": [
      "Удаляет класс / Классты өчүрөт",
      "Добавляет класс / Классты кошот",
      "Переключает класс / Классты өзгөртөт",
      "Проверяет класс / Классты текшерет"
    ],
    "answer": "Добавляет класс / Классты кошот",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d6",
    "question": "Что делает transform: scale(1.5);? / Бул касиет элементке кандай таасир берет?",
    "options": [
      "Увеличивает элемент в 1.5 раза / Элементти 1.5 эсе чоңойтот",
      "Уменьшает элемент",
      "Поворачивает элемент",
      "Смещает элемент"
    ],
    "answer": "Увеличивает элемент в 1.5 раза / Элементти 1.5 эсе чоңойтот",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ac",
    "question": "Что такое компонент в React? / React компонент деген эмне?",
    "options": [
      "HTML файл / HTML файл",
      "CSS класс / CSS класс",
      "Функция, возвращающая JSX / JSX кайтарган функция",
      "Объект / Объект"
    ],
    "answer": "Функция, возвращающая JSX / JSX кайтарган функция",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d0",
    "question": "Когда НЕ рекомендуется использовать Context API? / Кайсы учурда Context API колдонбоо сунушталат?",
    "options": [
      "Для темы / Тема үчүн",
      "Для локального состояния / Локалдык state үчүн",
      "Для редко меняющихся данных / Сейрек өзгөргөн маалымат үчүн",
      "Для авторизации / Авторизация үчүн"
    ],
    "answer": "Для локального состояния / Локалдык state үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16cf",
    "question": "Что делает оператор spread? / spread оператору эмнени аткарат?",
    "options": [
      "Удаляет элементы / Элементтерди өчүрөт",
      "Расширяет элементы / Элементтерди кеңейтет",
      "Копирует массив/объект / Массивди/объектти көчүрөт",
      "Создает функцию / Функция түзөт"
    ],
    "answer": "Копирует массив/объект / Массивди/объектти көчүрөт",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ce",
    "question": "Какое значение position позволяет элементу оставаться видимым при прокрутке страницы? / Баракты жылдырганда элемент ордунда калыш үчүн кайсы position колдонулат?",
    "options": [
      "relative / relative",
      "absolute / absolute",
      "fixed / fixed",
      "sticky / sticky"
    ],
    "answer": "fixed / fixed",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16cd",
    "question": "Как выглядит generic? / Generic кантип жазылат?",
    "options": [
      "<T> / <T>",
      "(T) / (T)",
      "[T] / [T]",
      "{T} / {T}"
    ],
    "answer": "<T> / <T>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c9",
    "question": "Что такое generics? / Generics деген эмне?",
    "options": [
      "Тип по умолчанию / Default тип",
      "Универсальные типы / Универсалдык типтер",
      "Типы только для массивов / Тек массив үчүн",
      "Только для классов / Тек класстар үчүн"
    ],
    "answer": "Универсальные типы / Универсалдык типтер",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c7",
    "question": "Как получить длину массива? / Массивдин узундугун кантип алса болот?",
    "options": [
      "size / size",
      "count / count",
      "length / length",
      "items / items"
    ],
    "answer": "length / length",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c5",
    "question": "Можно ли объединять interface? / Interface’терди бириктирүүгө болобу?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только type / Тек type",
      "Только с enum / Тек enum менен"
    ],
    "answer": "Да / Ооба",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c3",
    "question": "Как объявить функцию? / Функцияны кантип жарыялайбыз?",
    "options": [
      "function myFunc() {} / function myFunc() {}",
      "def myFunc() {} / def myFunc() {}",
      "create myFunc() / create myFunc()",
      "method myFunc() / method myFunc()"
    ],
    "answer": "function myFunc() {} / function myFunc() {}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d2",
    "question": "Какой параметр делает элемент прозрачным? / Элементти тунук кылган касиет кайсы?",
    "options": [
      "background-opacity / background-opacity",
      "visibility: hidden / visibility: hidden",
      "opacity: 0.5 / opacity: 0.5",
      "filter: blur(0) / filter: blur(0)"
    ],
    "answer": "opacity: 0.5 / opacity: 0.5",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ef",
    "question": "Что хранит localStorage? / localStorage эмнени сактайт?",
    "options": [
      "Временные данные / Убактылуу маалымат",
      "Данные до закрытия вкладки / Вкладка жабылмайынча сакталат",
      "Данные без срока хранения / Сактоо мөөнөтүсүз маалымат",
      "Только cookies / Тек cookies"
    ],
    "answer": "Данные без срока хранения / Сактоо мөөнөтүсүз маалымат",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ed",
    "question": "Что вернет useRef<HTMLInputElement>(null)? / useRef<HTMLInputElement>(null) эмнени кайтарат?",
    "options": [
      "Строку / Строка",
      "HTML элемент / HTML элемент",
      "Ref объект / Ref объект",
      "null / null"
    ],
    "answer": "Ref объект / Ref объект",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16eb",
    "question": "Какое событие срабатывает при отправке формы? / Форма жөнөтүлгөндө кайсы событие иштейт?",
    "options": [
      "click / click",
      "send / send",
      "submit / submit",
      "input / input"
    ],
    "answer": "submit / submit",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16e8",
    "question": "Что такое slice? / Slice деген эмне?",
    "options": [
      "Компонент / Компонент",
      "Часть store с логикой / Store’дун логикасы бар бөлүгү",
      "Middleware / Middleware",
      "API / API"
    ],
    "answer": "Часть store с логикой / Store’дун логикасы бар бөлүгү",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16de",
    "question": "Какой селектор выберет каждый второй элемент списка? / Тизмедеги ар экинчи элементти тандайт?",
    "options": [
      "li:nth-of-type(2) / li:nth-of-type(2)",
      "li:nth-child(2n) / li:nth-child(2n)",
      "li:even / li:even",
      "li:nth(2) / li:nth(2)"
    ],
    "answer": "li:nth-child(2n) / li:nth-child(2n)",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d8",
    "question": "Для чего используется useMemo? / useMemo эмне үчүн колдонулат?",
    "options": [
      "Для API запросов / API суроо үчүн",
      "Для мемоизации значений / Маанилерди мемоизациялоо үчүн",
      "Для событий / Событие үчүн",
      "Для CSS / CSS үчүн"
    ],
    "answer": "Для мемоизации значений / Маанилерди мемоизациялоо үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d7",
    "question": "Как создается template string? / template string кантип түзүлөт?",
    "options": [
      "'text' / 'text'",
      "\\text\" / \\text\"",
      "text ${var} / text ${var}",
      "(text)\" / (text)\""
    ],
    "answer": "text ${var} / text ${var}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16d5",
    "question": "Что такое enum? / Enum деген эмне?",
    "options": [
      "Функция / Функция",
      "Класс / Класс",
      "Набор именованных значений / Атайын маанилердин топтому",
      "Тип массива / Массив типи"
    ],
    "answer": "Набор именованных значений / Атайын маанилердин топтому",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16bf",
    "question": "Какой цикл используется, если количество итераций известно? / Эгер цикл канча жолу иштей турганы белгилүү болсо кайсы колдонулат?",
    "options": [
      "while / while",
      "do while / do while",
      "for / for",
      "if / if"
    ],
    "answer": "for / for",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c2",
    "question": "Что делает свойство box-sizing: border-box;? / Бул касиет эмнени өзгөртөт?",
    "options": [
      "Включает padding и border в общую ширину блока / padding жана border блоктун жалпы туурасына кирет",
      "Убирает рамки у блока / Блоктун чекиттерин жок кылат",
      "Делает блок невидимым / Блокту көрүнбөйт кылат",
      "Расширяет границы за пределы родителя / Чектик чегин кеңейтет"
    ],
    "answer": "Включает padding и border в общую ширину блока / padding жана border блоктун жалпы туурасына кирет",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c1",
    "question": "Что лучше использовать для props? / Props үчүн эмнени колдонуу жакшы?",
    "options": [
      "any / any",
      "interface / Interface",
      "var / var",
      "enum / enum"
    ],
    "answer": "interface / Interface",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16bd",
    "question": "В чём отличие interface от type? / Interface менен type айырмасы эмнеде?",
    "options": [
      "Нет отличий / Айырмасы жок",
      "interface можно расширять / Interface кеңейтүүгө болот",
      "type нельзя использовать с объектами / Type объект менен колдонулбайт",
      "interface устарел / Interface эскирген"
    ],
    "answer": "interface можно расширять / Interface кеңейтүүгө болот",
    "category": "typescript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16ba",
    "question": "Чем отличается inline-block от block? / inline-block менен block айырмасы эмнеде?",
    "options": [
      "inline-block не учитывает отступы / inline-block отступтарды эске албайт",
      "inline-block можно ставить рядом с другими элементами / inline-block элементтерди катар коюуга болот",
      "block всегда фиксирован / block дайым туруктуу",
      "Ничем / Айырмасы жок"
    ],
    "answer": "inline-block можно ставить рядом с другими элементами / inline-block элементтерди катар коюуга болот",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b6",
    "question": "Что будет, если внутри <a> вставить другой <a> тег? / Эгер <a> тегинин ичине дагы <a> теги кошулса эмне болот?",
    "options": [
      "HTML разрешает это, оба будут работать / HTML уруксат берет, экөө иштейт",
      "Это ошибка — вложенные ссылки не поддерживаются / Бул ката — вложенные шилтемелер колдоого алынбайт",
      "Вторая ссылка заменит первую / Экинчи шилтеме биринчи менен алмашат",
      "Браузер объединит их в одну / Браузер экөөнү бириктирет"
    ],
    "answer": "Это ошибка — вложенные ссылки не поддерживаются / Бул ката — вложенные шилтемелер колдоого алынбайт",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b3",
    "question": "Что вернет typeof null? / typeof null эмне кайтарат?",
    "options": [
      "null / null",
      "object / объект",
      "undefined / undefined",
      "number / number"
    ],
    "answer": "object / объект",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16b2",
    "question": "Какой способ подключения CSS считается внешним? / CSS файлды тышкы түрдө кошуунун жолу кайсы?",
    "options": [
      "<style> / <style>",
      "<link rel=\"stylesheet\" href=\"style.css\"> / <link rel=\"stylesheet\" href=\"style.css\">",
      "@import / @import",
      "inline-стиль / inline-стиль"
    ],
    "answer": "<link rel=\"stylesheet\" href=\"style.css\"> / <link rel=\"stylesheet\" href=\"style.css\">",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16af",
    "question": "Какой тип данных НЕ существует в JS? / JSте кайсы тип жок?",
    "options": [
      "string / string",
      "number / number",
      "boolean / boolean",
      "float / float"
    ],
    "answer": "float / float",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16bc",
    "question": "Можно ли изменять props внутри компонента? / Компонент ичинде props өзгөртүүгө болобу?",
    "options": [
      "Да / Ооба",
      "Нет / Жок",
      "Только через useEffect / Тек useEffect аркылуу",
      "Иногда / Кээде"
    ],
    "answer": "Нет / Жок",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16c0",
    "question": "Что такое state? / State деген эмне?",
    "options": [
      "Внешние данные / Сырттан келген маалымат",
      "Локальное состояние компонента / Компоненттин локалдык абалы",
      "Props / Props",
      "Глобальное хранилище / Глобалдык сактагыч"
    ],
    "answer": "Локальное состояние компонента / Компоненттин локалдык абалы",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.176Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1699",
    "question": "Основная цель TypeScript? / TypeScriptтин негизги максаты?",
    "options": [
      "Ускорить код / Кодду ылдамдатуу",
      "Добавить типизацию / Типизация кошуу",
      "Уменьшить размер бандла / Бандл өлчөмүн кыскартуу",
      "Убрать баги полностью / Багдарды толук жок кылуу"
    ],
    "answer": "Добавить типизацию / Типизация кошуу",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa168c",
    "question": "Для чего используется dispatch? / dispatch эмне үчүн колдонулат?",
    "options": [
      "Для получения данных / Маалымат алуу үчүн",
      "Для отправки action / Action жиберүү үчүн",
      "Для роутинга / Роутинг үчүн",
      "Для подписки / Подписка үчүн"
    ],
    "answer": "Для отправки action / Action жиберүү үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa168d",
    "question": "Что улучшает поддержку кода? / Кодду колдоону эмне жакшыртат?",
    "options": [
      "any / any",
      "enums и типы / Enum’дор жана типтер",
      "console.log / console.log",
      "var / var"
    ],
    "answer": "enums и типы / Enum’дор жана типтер",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa168f",
    "question": "Что такое this? / this деген эмне?",
    "options": [
      "Функция / Функция",
      "Класс / Класс",
      "Контекст вызова / Чакыруу контексти",
      "Объект window всегда / Ар дайым window объектиси"
    ],
    "answer": "Контекст вызова / Чакыруу контексти",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1691",
    "question": "Что показывает уровень React TS разработчика? / React TS программисттин деңгээлин эмнеге карайт?",
    "options": [
      "Верстка / Верстка",
      "Умение писать классы / Класстарды жазуу жөндөмү",
      "Типизированный SPA с Redux / Типтелген SPA Redux менен",
      "Только знание JS / Факты JS билүү"
    ],
    "answer": "Типизированный SPA с Redux / Типтелген SPA Redux менен",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa169a",
    "question": "Какое свойство задаёт расстояние между колонками в Grid? / Grid ичинде мамычалар ортосундагы аралыкты кайсы касиет жөндөйт?",
    "options": [
      "column-width / column-width",
      "grid-template-columns / grid-template-columns",
      "gap / gap",
      "padding / padding"
    ],
    "answer": "gap / gap",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa169d",
    "question": "Что происходит с TypeScript кодом? / TypeScript коду менен эмне болот?",
    "options": [
      "Выполняется напрямую в браузере / Браузерде түздөн-түз аткарылат",
      "Компилируется в JavaScript / JavaScriptке компиляцияланат",
      "Запускается на сервере / Серверде аткарылат",
      "Удаляется / Жок кылынат"
    ],
    "answer": "Компилируется в JavaScript / JavaScriptке компиляцияланат",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa169e",
    "question": "Какой тег используется для создания выпадающего списка? / Төмөн түшүүчү тизмени түзүү үчүн кайсы тег колдонулат?",
    "options": [
      "<datalist> / <datalist>",
      "<select> / <select>",
      "<option> / <option>",
      "<input> / <input>"
    ],
    "answer": "<select> / <select>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a1",
    "question": "Как указать тип number? / Number типти кантип көрсөтөсүз?",
    "options": [
      "let a = number / let a = number",
      "let a: number / let a: number",
      "number a / number a",
      "let number = a / let number = a"
    ],
    "answer": "let a: number / let a: number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1680",
    "question": "Что такое Redux Toolkit? / Redux Toolkit деген эмне?",
    "options": [
      "Отдельный Redux / Өзүнчө Redux",
      "Надстройка над Redux / Redux үстүндө кошумча китепкана",
      "CSS библиотека / CSS китепканасы",
      "Router / Router"
    ],
    "answer": "Надстройка над Redux / Redux үстүндө кошумча китепкана",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1697",
    "question": "Как JavaScript работает в браузере? / JavaScript браузерде кантип иштейт?",
    "options": [
      "Выполняется на сервере / Серверде аткарылат",
      "Компилируется заранее / Алдын ала компиляцияланат",
      "Выполняется движком браузера / Браузердин движогу аркылуу иштейт",
      "Работает только с HTML / Тек HTML менен гана иштейт"
    ],
    "answer": "Выполняется движком браузера / Браузердин движогу аркылуу иштейт",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1694",
    "question": "Что такое React? / React деген эмне?",
    "options": [
      "JavaScript библиотека для UI / UI түзүү үчүн JavaScript китепкана",
      "Язык программирования / Программалоо тили",
      "Backend-фреймворк / Сервер жаатындагы фреймворк",
      "CMS система / CMS система"
    ],
    "answer": "JavaScript библиотека для UI / UI түзүү үчүн JavaScript китепкана",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa168b",
    "question": "Как объявить функцию через стрелочную запись? / Стрелка (arrow) функциясын кантип жарыялайт?",
    "options": [
      "function myFunc() {} / function myFunc() {}",
      "const myFunc = () => {} / const myFunc = () => {}",
      "var myFunc = function() {} / var myFunc = function() {}",
      "func myFunc = {} / func myFunc = {}"
    ],
    "answer": "const myFunc = () => {} / const myFunc = () => {}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1686",
    "question": "Какое значение position «прилипает» при скролле? / Скроллда «чапталуучу» позиция кайсы?",
    "options": [
      "fixed / fixed",
      "absolute / absolute",
      "relative / relative",
      "sticky / sticky"
    ],
    "answer": "sticky / sticky",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1682",
    "question": "Как включить CSS Grid? / CSS Gridти кантип күйгүзүү керек?",
    "options": [
      "display: grid / display: grid",
      "grid: on / grid: on",
      "position: grid / position: grid",
      "layout: grid / layout: grid"
    ],
    "answer": "display: grid / display: grid",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1681",
    "question": "Где типизируется initialState? / initialState кайда типтелет?",
    "options": [
      "В reducers / Reducer’лерде",
      "В createSlice / createSlice ичинде",
      "В интерфейсе состояния / State интерфейсинде",
      "В компоненте / Компонентте"
    ],
    "answer": "В createSlice / createSlice ичинде",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa167c",
    "question": "Зачем нужна архитектура в React? / Reactте архитектура эмне үчүн керек?",
    "options": [
      "Для красоты / Сырткы көрүнүш үчүн",
      "Для SEO / SEO үчүн",
      "Для масштабируемости / Масштабдалуучулук үчүн",
      "Для скорости интернета / Интернет ылдамдыгы үчүн"
    ],
    "answer": "Для масштабируемости / Масштабдалуучулук үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1677",
    "question": "Что хранит localStorage? / localStorage эмне сактайт?",
    "options": [
      "Временные данные / Убакыттуу маалымат",
      "Данные до закрытия вкладки / Вкладка жабылганга чейин маалымат",
      "Данные без срока хранения / Сактоо мөөнөтү жок маалымат",
      "Только cookies / Факты cookies"
    ],
    "answer": "Данные без срока хранения / Сактоо мөөнөтү жок маалымат",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1675",
    "question": "Что такое typed dispatch? / Typed dispatch деген эмне?",
    "options": [
      "dispatch без типов / Типсиз dispatch",
      "dispatch с AppDispatch / AppDispatch менен dispatch",
      "dispatch из React / Reactтеги dispatch",
      "dispatch только для async / Факты async үчүн dispatch"
    ],
    "answer": "dispatch с AppDispatch / AppDispatch менен dispatch",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1685",
    "question": "Что типизирует payload? / Payload эмне типтейт?",
    "options": [
      "action.payload / action.payload",
      "PayloadAction<T> / PayloadAction<T>",
      "useDispatch / useDispatch",
      "createStore / createStore"
    ],
    "answer": "PayloadAction<T> / PayloadAction<T>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa168a",
    "question": "Какое свойство добавляет плавность изменения? / Өзгөрүүнү жайуу үчүн кайсы касиет колдонулат?",
    "options": [
      "animation / animation",
      "transform / transform",
      "transition / transition",
      "hover / hover"
    ],
    "answer": "transition / transition",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a7",
    "question": "Какое окно позволяет вводить текст? / Кайсы терезе текст киргизүүгө мүмкүнчүлүк берет?",
    "options": [
      "alert / alert",
      "confirm / confirm",
      "prompt / prompt",
      "message / message"
    ],
    "answer": "prompt / prompt",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a5",
    "question": "Как указать тип string? / String типти кантип көрсөтөсүз?",
    "options": [
      "let a: text / let a: text",
      "let a: string / let a: string",
      "string a / string a",
      "let string = a / let string = a"
    ],
    "answer": "let a: string / let a: string",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a4",
    "question": "В что компилируется JSX? / JSX эмнеге компиляцияланат?",
    "options": [
      "HTML / HTML",
      "CSS / CSS",
      "JavaScript / JavaScript",
      "JSON / JSON"
    ],
    "answer": "JavaScript / JavaScript",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a2",
    "question": "Чем <section> отличается от <div>? / <section> менен <div> кандай айырмаланат?",
    "options": [
      "<div> используется только внутри <header> / <div> тек <header> ичинде колдонулат",
      "<section> несёт смысл, а <div> — только контейнер / <section> мааниге ээ, <div> жөн эле контейнер",
      "<section> нельзя вложить в <div> / <section>ти <div> ичине кошууга болбойт",
      "Они абсолютно одинаковы / Экиси бирдей"
    ],
    "answer": "<section> несёт смысл, а <div> — только контейнер / <section> мааниге ээ, <div> жөн эле контейнер",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa169f",
    "question": "Какое окно показывает сообщение без ввода? / Эгер текст киргизбестен билдирүү көрсөтүлсө кайсы?",
    "options": [
      "prompt / prompt",
      "alert / alert",
      "confirm / confirm",
      "modal / modal"
    ],
    "answer": "alert / alert",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1683",
    "question": "Как получить данные с сервера? / Серверден маалымат кантип алса болот?",
    "options": [
      "fetch / fetch",
      "getData / getData",
      "axios() / axios()",
      "request() / request()"
    ],
    "answer": "fetch / fetch",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1684",
    "question": "Что такое slice? / Slice деген эмне?",
    "options": [
      "Компонент / Компонент",
      "Часть store с логикой / Storeдун логикасы менен бөлүгү",
      "Middleware / Middleware",
      "API / API"
    ],
    "answer": "Часть store с логикой / Storeдун логикасы менен бөлүгү",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa167a",
    "question": "Как включить flexbox? / Flexboxту кантип күйгүзүү керек?",
    "options": [
      "position: flex / position: flex",
      "display: flex / display: flex",
      "flex: block / flex: block",
      "align: flex / align: flex"
    ],
    "answer": "display: flex / display: flex",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1689",
    "question": "Что НЕ является best practice? / Эмне — best practice эмес?",
    "options": [
      "Использовать any / any колдонуу",
      "Типизировать props / Propsту типтөө",
      "Использовать generics / Generics колдонуу",
      "Строгая типизация / Катуу типтөө"
    ],
    "answer": "Использовать any / any колдонуу",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a3",
    "question": "Какое окно возвращает true или false? / Кайсы терезе true же false кайтарат?",
    "options": [
      "alert / alert",
      "prompt / prompt",
      "confirm / confirm",
      "input / input"
    ],
    "answer": "confirm / confirm",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa169c",
    "question": "Что такое SPA? / SPA деген эмне?",
    "options": [
      "Многостраничный сайт / Көп барактуу сайт",
      "Сайт без JavaScript / JavaScript жок сайт",
      "Приложение без перезагрузки страниц / Баракчаны кайра жүктөлбөгөн тиркеме",
      "Только мобильное приложение / Тек мобилдик тиркеме"
    ],
    "answer": "Приложение без перезагрузки страниц / Баракчаны кайра жүктөлбөгөн тиркеме",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa169b",
    "question": "Что делает метод Array.push()? / Array.push() методу эмнени аткарат?",
    "options": [
      "Удаляет последний элемент / Акыркы элементти өчүрөт",
      "Добавляет элемент в конец массива / Массивдин аягына элемент кошот",
      "Сортирует массив / Массивди сорттойт",
      "Создает новый массив / Жаңы массив түзөт"
    ],
    "answer": "Добавляет элемент в конец массива / Массивдин аягына элемент кошот",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1698",
    "question": "Кто разработал React? / React ким иштеп чыккан?",
    "options": [
      "Google / Google",
      "Microsoft / Microsoft",
      "Facebook (Meta) / Facebook (Meta)",
      "Amazon / Amazon"
    ],
    "answer": "Facebook (Meta) / Facebook (Meta)",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1690",
    "question": "Что делает useSelector? / useSelector эмне кылат?",
    "options": [
      "Изменяет state / Stateти өзгөртөт",
      "Получает данные из store / Storeдон маалымат алат",
      "Создает store / Store түзөт",
      "Делает запрос / Чакыруу жасайт"
    ],
    "answer": "Получает данные из store / Storeдон маалымат алат",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1687",
    "question": "Что делает async/await? / async/await эмне кылат?",
    "options": [
      "Ускоряет код / Кодду ылдамдатат",
      "Делает код синхронным / Кодту синхрон кылат",
      "Упрощает работу с Promise / Promise менен иштөөнү жеңилдетет",
      "Удаляет then / thenди өчүрөт"
    ],
    "answer": "Упрощает работу с Promise / Promise менен иштөөнү жеңилдетет",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1678",
    "question": "Для чего используется React.memo? / React.memo эмне үчүн колдонулат?",
    "options": [
      "Для стилизации / Стилдөө үчүн",
      "Для оптимизации рендера компонентов / Компоненттердин рендерин оптимизациялоо үчүн",
      "Для навигации / Навигация үчүн",
      "Для работы с формами / Формалар менен иштөө үчүн"
    ],
    "answer": "Для оптимизации рендера компонентов / Компоненттердин рендерин оптимизациялоо үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa167d",
    "question": "Где обычно объявляется RootState? / RootState көбүнчө кайда жарыяланат?",
    "options": [
      "В компоненте / Компонентте",
      "В store файле / Store файлына",
      "В slice / Slice’та",
      "В CSS / CSSте"
    ],
    "answer": "В store файле / Store файлына",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa167b",
    "question": "Как сохранить данные в localStorage? / localStorageге маалымат кантип сакталат?",
    "options": [
      "localStorage.add() / localStorage.add()",
      "localStorage.save() / localStorage.save()",
      "localStorage.setItem() / localStorage.setItem()",
      "localStorage.push() / localStorage.push()"
    ],
    "answer": "localStorage.setItem() / localStorage.setItem()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a6",
    "question": "Что из перечисленного не является блочным элементом? / Төмөндөгү кайсысы блочный элемент эмес?",
    "options": [
      "<section> / <section>",
      "<p> / <p>",
      "<span> / <span>",
      "<form> / <form>"
    ],
    "answer": "<span> / <span>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa16a0",
    "question": "Что такое JSX? / JSX деген эмне? JavaScript синтаксисинин кеңейтилиши",
    "options": [
      "Отдельный язык / Өзүнчө тил",
      "HTML файл / HTML файл",
      "Расширение синтаксиса JavaScript /",
      "CSS препроцессор / CSS препроцессору"
    ],
    "answer": "Расширение синтаксиса JavaScript /",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1696",
    "question": "Какой атрибут задаёт альтернативный текст изображения? / Сүрөт чыкпаса текст көрсөтүүчү атрибут кайсы?",
    "options": [
      "title / title",
      "name / name",
      "src / src",
      "alt / alt"
    ],
    "answer": "alt / alt",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1695",
    "question": "Что такое TypeScript? / TypeScript деген эмне?",
    "options": [
      "Надстройка над JavaScript с типизацией / JavaScriptке типизация кошуучу надстройка",
      "Новый язык вместо JavaScript / JavaScriptтин жаңы тили",
      "Backend язык / Сервер тили",
      "Фреймворк / Фреймворк"
    ],
    "answer": "Надстройка над JavaScript с типизацией / JavaScriptке типизация кошуучу надстройка",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1693",
    "question": "Что такое JavaScript? / JavaScript деген эмне?",
    "options": [
      "Язык разметки / Белгилөө тили",
      "Язык стилей / Стиль тили",
      "Язык программирования / Программалоо тили",
      "База данных / Маалымат базасы"
    ],
    "answer": "Язык программирования / Программалоо тили",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1692",
    "question": "Какова основная цель объявления <!DOCTYPE html>? / <!DOCTYPE html> декларациясынын негизги максаты эмнеде?",
    "options": [
      "Задаёт кодировку страницы / Барактын кодировкасын белгилейт",
      "Указывает браузеру версию HTML / Браузерге HTML версиясын көрсөтөт",
      "Подключает CSS-файл / CSS файлын кошот",
      "Определяет язык страницы / Барактын тилин аныктайт"
    ],
    "answer": "Указывает браузеру версию HTML / Браузерге HTML версиясын көрсөтөт",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa168e",
    "question": "Что такое Mobile-first? / Mobile-first деген эмне?",
    "options": [
      "Сначала ПК версия / Алгач ПК версиясы",
      "Сначала мобильная версия / Алгач мобилдик версиясы",
      "Только мобильный сайт / Факты мобилдик сайт",
      "Без media queries / Media queriesсиз"
    ],
    "answer": "Сначала мобильная версия / Алгач мобилдик версиясы",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1688",
    "question": "Что хранится в store? / Storeде эмне сакталат?",
    "options": [
      "JSX / JSX",
      "Props / Props",
      "Глобальное состояние / Глобалдык state",
      "Локальный state / Локалдык state"
    ],
    "answer": "Глобальное состояние / Глобалдык state",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa167f",
    "question": "Что делает setInterval? / setInterval эмне кылат?",
    "options": [
      "Выполняет код один раз / Кодту бир жолу иштетет",
      "Выполняет код с задержкой / Кодту кечиктирип иштетет",
      "Выполняет код регулярно / Кодту үзгүлтүксүз (кайталанып) иштетет",
      "Останавливает таймер / Таймерди токтотот"
    ],
    "answer": "Выполняет код регулярно / Кодту үзгүлтүксүз (кайталанып) иштетет",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa167e",
    "question": "Какое свойство выравнивает элементы по главной оси? / Элементтерди негизги огу боюнча кантип түздөө керек?",
    "options": [
      "align-items / align-items",
      "justify-content / justify-content",
      "flex-wrap / flex-wrap",
      "gap / gap"
    ],
    "answer": "justify-content / justify-content",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1679",
    "question": "Как типизировать useSelector? / useSelectorти кантип типтөө керек?",
    "options": [
      "useSelector<any> / useSelector<any>",
      "TypedUseSelectorHook / TypedUseSelectorHook",
      "useSelector<State> / useSelector<State>",
      "selector() / selector()"
    ],
    "answer": "TypedUseSelectorHook / TypedUseSelectorHook",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1676",
    "question": "Какое свойство отвечает за внутренний отступ? / Ички боштук (padding) үчүн кайсы касиет жооптуу?",
    "options": [
      "margin / margin",
      "border / border",
      "padding / padding",
      "gap / gap"
    ],
    "answer": "padding / padding",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.175Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1650",
    "question": "Для чего нужен React Router? / React Router эмне үчүн керек?",
    "options": [
      "Для API / API үчүн",
      "Для управления состоянием / State башкаруу үчүн",
      "Для навигации в SPA / SPA ичинде навигация үчүн",
      "Для работы с формами / Формалар менен иштөө үчүн"
    ],
    "answer": "Для навигации в SPA / SPA ичинде навигация үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1653",
    "question": "Как обратиться к свойству объекта? / Объекттин касиетине кантип кайрылат?",
    "options": [
      "obj[property] / obj[property]",
      "obj.property / obj.property",
      "Оба варианта / Эки вариант тең",
      "Только через [] / Факты [] аркылуу"
    ],
    "answer": "Оба варианта / Эки вариант тең",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1634",
    "question": "Что такое компонент в React? / Reactте компонент деген эмне?",
    "options": [
      "HTML файл / HTML файлы",
      "CSS класс / CSS классы",
      "Функция, возвращающая JSX / JSX кайтарган функция",
      "Объект / Объект"
    ],
    "answer": "Функция, возвращающая JSX / JSX кайтарган функция",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1637",
    "question": "Какой тип данных НЕ существует в JS? / JavaScriptте кайсы тип жок?",
    "options": [
      "string / string",
      "number / number",
      "boolean / boolean",
      "float / float"
    ],
    "answer": "float / float",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa163a",
    "question": "Чем отличается <article> от <section>? / <article> менен <section> эмнеге айырмаланат?",
    "options": [
      "Ничем / Эч нерседен айырмаланбайт",
      "<article> — независимый контент / <article> — көз карандысыз контент",
      "<section> нельзя использовать / <section> колдонулбайт",
      "<article> только для текста / <article> жөн гана текст үчүн"
    ],
    "answer": "<article> — независимый контент / <article> — көз карандысыз контент",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa163c",
    "question": "Что возвращает React-компонент? / React-компонент эмне кайтарат?",
    "options": [
      "HTML / HTML",
      "JSX / JSX",
      "CSS / CSS",
      "JSON / JSON"
    ],
    "answer": "JSX / JSX",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1645",
    "question": "Что лучше использовать для props? / Props үчүн эмнени колдонуу жакшы?",
    "options": [
      "any / any",
      "interface / interface",
      "var / var",
      "enum / enum"
    ],
    "answer": "interface / interface",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1647",
    "question": "Какой цикл используется, если количество итераций известно? / Итерациялар саны белгилүү болсо кайсы цикл колдонулат?",
    "options": [
      "while / while",
      "do while / do while",
      "for / for",
      "if / if"
    ],
    "answer": "for / for",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa164b",
    "question": "Как объявить функцию? / Функцияны кантип жарыялайт?",
    "options": [
      "function myFunc() {} / function myFunc() {}",
      "def myFunc() {} / def myFunc() {}",
      "create myFunc() / create myFunc()",
      "method myFunc() / method myFunc()"
    ],
    "answer": "function myFunc() {} / function myFunc() {}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1658",
    "question": "Где чаще всего делают API запросы в React? / Reactте API чакырууларды көбүнчө кайда жасайт?",
    "options": [
      "В render / render ичинде",
      "В useEffect / useEffect ичинде",
      "В JSX / JSXте",
      "В CSS / CSSте"
    ],
    "answer": "В useEffect / useEffect ичинде",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1649",
    "question": "Можно ли объединять interface? / Interface’терди бириктирүүгө болобу?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только type / Факты type менен",
      "Только с enum / Факты enum менен"
    ],
    "answer": "Да / Ооба",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1671",
    "question": "Что вернет useRef<HTMLInputElement>(null)? / useRef<HTMLInputElement>(null) эмне кайтарат?",
    "options": [
      "Строку / Строка",
      "HTML элемент / HTML элемент",
      "Ref объект / Ref объекти",
      "null / null"
    ],
    "answer": "Ref объект / Ref объекти",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa166a",
    "question": "Что такое CSS? / CSS деген эмне?",
    "options": [
      "Язык программирования / Программалоо тили",
      "Язык стилей / Стиль тили",
      "База данных / Маалымат базасы",
      "Фреймворк / Фреймворк"
    ],
    "answer": "Язык стилей / Стиль тили",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1651",
    "question": "Как выглядит generic? / Generic кандай жазылат?",
    "options": [
      "<T> / <T>",
      "(T) / (T)",
      "[T] / [T]",
      "{T} / {T}"
    ],
    "answer": "<T> / <T>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1662",
    "question": "Какой input позволяет выбрать файл? / Файл тандаш үчүн кайсы input колдонулат?",
    "options": [
      "file / file",
      "upload / upload",
      "image / image",
      "media / media"
    ],
    "answer": "file / file",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1661",
    "question": "Как типизировать функциональный компонент? / Функционалдык компонентти кантип типизациялоо керек?",
    "options": [
      "const Comp = () => {} / const Comp = () => {}",
      "const Comp: FC = () => {} / const Comp: FC = () => {}",
      "function Comp() {} / function Comp() {}",
      "React.Comp() / React.Comp()"
    ],
    "answer": "const Comp: FC = () => {} / const Comp: FC = () => {}",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa165f",
    "question": "Как создаётся template string? / Template string кантип түзүлөт?",
    "options": [
      "'text' / 'text'",
      "\\text\" / \\text\"",
      "text ${var} / text ${var}",
      "(text) / (text)"
    ],
    "answer": "text ${var} / text ${var}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1630",
    "question": "Как правильно вставить JS в JSX? / JSXке JavaScriptти кантип туура киргизүү керек?",
    "options": [
      "{{ value }} / {{ value }}",
      "<% value %> / <% value %>",
      "{ value } / { value }",
      "( value ) / ( value )"
    ],
    "answer": "{ value } / { value }",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa166f",
    "question": "Какое событие срабатывает при клике? / Click (чычкан басуу) учурунда кайсы окуя иштейт?",
    "options": [
      "submit / submit",
      "input / input",
      "click / click",
      "change / change"
    ],
    "answer": "click / click",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa166e",
    "question": "Какой селектор выбирает элемент по id? / ID боюнча элементти тандай турган селектор кайсы?",
    "options": [
      ". / .",
      "# / #",
      "* / *",
      "@ / @"
    ],
    "answer": "# / #",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa166c",
    "question": "Для чего используется useMemo? / useMemo эмне үчүн колдонулат?",
    "options": [
      "Для API запросов / API чакыруулар үчүн",
      "Для мемоизации значений / Маанилерди мемоизациялоо үчүн",
      "Для событий / Окуялар үчүн",
      "Для CSS / CSS үчүн"
    ],
    "answer": "Для мемоизации значений / Маанилерди мемоизациялоо үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1669",
    "question": "",
    "options": [
      "useState<string>() / useState<string>()",
      "useState(\"text\") / useState(\"text\")",
      "Оба варианта / Эки вариант тең туура",
      "Нельзя / Болбойт"
    ],
    "answer": "useState(\"text\") / useState(\"text\")",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1666",
    "question": "Что делает HTML5 validation? / HTML5 текшерүү (validation) эмне кылат?",
    "options": [
      "Проверяет CSS / CSSти текшерет",
      "Проверяет JS / JSти текшерет",
      "Проверяет данные формы / Форманын маалыматтарын текшерет",
      "Отправляет форму / Форманы жөнөтөт"
    ],
    "answer": "Проверяет данные формы / Форманын маалыматтарын текшерет",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1665",
    "question": "Где типизируются props? / Props кайда типтелет?",
    "options": [
      "В useEffect / useEffectте",
      "В аргументах компонента / Компоненттин аргументтеринде",
      "В JSX / JSXте",
      "В CSS / CSSте"
    ],
    "answer": "В аргументах компонента / Компоненттин аргументтеринде",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1664",
    "question": "Когда НЕ рекомендуется использовать Context API? / Context API качан колдонулбайт?",
    "options": [
      "Для темы / Тема үчүн",
      "Для локального состояния / Локалдык state үчүн",
      "Для редко меняющихся данных / Аз өзгөрүлүүчү маалымат үчүн",
      "Для авторизации / Авторизация үчүн"
    ],
    "answer": "Для локального состояния / Локалдык state үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1631",
    "question": "Какой тип предпочтительнее использовать? / Кайсы типти колдонуу артыкчылыкка ээ?",
    "options": [
      "any / any",
      "unknown / unknown",
      "var / var",
      "null / null"
    ],
    "answer": "unknown / unknown",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa164f",
    "question": "Как получить длину массива? / Массивдин узундугун кантип алуу керек?",
    "options": [
      "size / size",
      "count / count",
      "length / length",
      "items / items"
    ],
    "answer": "length / length",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1632",
    "question": "Какой тег предназначен для основной части страницы? / Барактын негизги бөлүгү үчүн кайсы тег колдонулат?",
    "options": [
      "<section> / <section>",
      "<main> / <main>",
      "<body> / <body>",
      "<article> / <article>"
    ],
    "answer": "<main> / <main>",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1635",
    "question": "Что такое union тип? / Union тип деген эмне?",
    "options": [
      "Объединение типов через & / & аркылуу типтерди бириктирүү",
      "Один тип / Бир тип",
      "Объединение типов через | / | аркылуу типтерди бириктирүү",
      "Наследование / Мураска алуу"
    ],
    "answer": "Объединение типов через | / | аркылуу типтерди бириктирүү",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1638",
    "question": "Как правильно назвать компонент? / Компонентти кантип туура аташат?",
    "options": [
      "header / header",
      "myComponent / myComponent",
      "Header / Header",
      "component / component"
    ],
    "answer": "Header / Header",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1639",
    "question": "Что означает тип string | number? / string | number типи эмне билдирет?",
    "options": [
      "Только string / Факты string",
      "Только number / Факты number",
      "string И number / string жана number",
      "string ИЛИ number / string же number"
    ],
    "answer": "string ИЛИ number / string же number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa163b",
    "question": "Что вернёт typeof null? / typeof null эмне кайтарат?",
    "options": [
      "null / null",
      "object / object",
      "undefined / undefined",
      "number / number"
    ],
    "answer": "object / object",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1642",
    "question": "Какой тег используется для изображения? / Сүрөт үчүн кайсы тег колдонулат?",
    "options": [
      "<image> / <image>",
      "<img> / <img>",
      "<picture> / <picture>",
      "<src> / <src>"
    ],
    "answer": "<img> / <img>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1646",
    "question": "Какой атрибут обязателен для доступности изображения? / Сүрөттүн жеткиликтүүлүгү үчүн кайсы атрибут милдеттүү?",
    "options": [
      "src / src",
      "title / title",
      "alt / alt",
      "id / id"
    ],
    "answer": "alt / alt",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa164c",
    "question": "Что произойдет, если не указать массив зависимостей? / Эгер useEffectке зависимосттор массивин көрсөтпөсө эмне болот?",
    "options": [
      "Ошибка / Ката",
      "useEffect выполнится один раз / useEffect бир жолу иштейт",
      "useEffect выполнится при каждом рендере / useEffect ар бир рендерде иштейт",
      "useEffect не выполнится / useEffect иштебейт"
    ],
    "answer": "useEffect выполнится при каждом рендере / useEffect ар бир рендерде иштейт",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa166d",
    "question": "Как типизировать событие input? / Input окуясын кантип типтөө керек?",
    "options": [
      "Event / Event",
      "MouseEvent / MouseEvent",
      "ChangeEvent<HTMLInputElement> / ChangeEvent<HTMLInputElement>",
      "InputEvent / InputEvent"
    ],
    "answer": "ChangeEvent<HTMLInputElement> / ChangeEvent<HTMLInputElement>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa166b",
    "question": "Чем отличается append от prepend? / append менен prepend эмнеге айырмаланат?",
    "options": [
      "Ничем / Эч нерседен айырмаланбайт",
      "append — в начало / append — башына",
      "prepend — в начало / prepend — башына",
      "prepend удаляет / prepend өчүрөт"
    ],
    "answer": "prepend — в начало / prepend — башына",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa162f",
    "question": "Какое окно позволяет вводить текст? / Кайсы терезе текст киргизүүгө мүмкүндүк берет?",
    "options": [
      "alert / alert",
      "confirm / confirm",
      "prompt / prompt",
      "message / message"
    ],
    "answer": "prompt / prompt",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1633",
    "question": "Как объявить переменную (ES6)? / Өзгөрмөнү жарыялоо (ES6) кантип жасалат?",
    "options": [
      "var / var",
      "let / let",
      "const / const",
      "B и C / B жана C"
    ],
    "answer": "B и C / B жана C",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa163d",
    "question": "Что такое intersection тип? / Intersection тип деген эмне?",
    "options": [
      "| / |",
      "& / &",
      "? / ?",
      "=> / =>"
    ],
    "answer": "& / &",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa163f",
    "question": "Какой оператор сравнивает по значению и типу? / Кайсы оператор маанисине жана типине карап салыштырат?",
    "options": [
      "== / ==",
      "= / =",
      "=== / ===",
      "!= / !="
    ],
    "answer": "=== / ===",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1644",
    "question": "Можно ли изменять props внутри компонента? / Компоненттин ичинде propsту өзгөртүүгө болобу?",
    "options": [
      "Да / Ооба",
      "Нет / Жок",
      "Только через useEffect / Факты useEffect аркылуу",
      "Иногда / Кээде"
    ],
    "answer": "Нет / Жок",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1648",
    "question": "Что такое state? / State деген эмне?",
    "options": [
      "Внешние данные / Сырткы маалымат",
      "Локальное состояние компонента / Компоненттин локалдык абалы",
      "Props / Props",
      "Глобальное хранилище / Глобалдык сактоочу жай"
    ],
    "answer": "Локальное состояние компонента / Компоненттин локалдык абалы",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa164a",
    "question": "Какой тег используется для видео? / Видео үчүн кайсы тег колдонулат?",
    "options": [
      "<media> / <media>",
      "<video> / <video>",
      "<movie> / <movie>",
      "<iframe> / <iframe>"
    ],
    "answer": "<video> / <video>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1672",
    "question": "Что входит в box model? / Box model кандай элементтерден турат?",
    "options": [
      "margin, padding, border, content / margin, padding, border, content",
      "width, height / width, height",
      "color, font / color, font",
      "position, display / position, display"
    ],
    "answer": "margin, padding, border, content / margin, padding, border, content",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa164e",
    "question": "Как встроить PDF на страницу? / PDFти баракка кантип кошсо болот?",
    "options": [
      "<pdf> / <pdf>",
      "<embed> / <embed>",
      "<iframe> / <iframe>",
      "B и C / B жана C"
    ],
    "answer": "B и C / B жана C",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1656",
    "question": "Какой тег создаёт таблицу? / Кайсы тег таблица түзөт?",
    "options": [
      "<table> / <table>",
      "<tr> / <tr>",
      "<td> / <td>",
      "<thead> / <thead>"
    ],
    "answer": "<table> / <table>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa165e",
    "question": "Какой input используется для email? / Email киргизүү үчүн кайсы input колдонулат?",
    "options": [
      "text / text",
      "mail / mail",
      "email / email",
      "input-email / input-email"
    ],
    "answer": "email / email",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1663",
    "question": "Что делает classList.add()? / classList.add() эмне кылат?",
    "options": [
      "Удаляет класс / Классты өчүрөт",
      "Добавляет класс / Классты кошот",
      "Переключает класс / Классты которот",
      "Проверяет класс / Классты текшерет"
    ],
    "answer": "Добавляет класс / Классты кошот",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1667",
    "question": "Как создать HTML элемент через JS? / JS аркылуу HTML элемент кантип түзүлөт?",
    "options": [
      "new Element() / new Element()",
      "document.createElement() / document.createElement()",
      "document.addElement() / document.addElement()",
      "create.element() / create.element()"
    ],
    "answer": "document.createElement() / document.createElement()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1668",
    "question": "Что такое custom hook? / Custom hook деген эмне?",
    "options": [
      "Компонент / Компонент",
      "Обычная функция / Кадимки функция",
      "Функция с хуками / Хук менен функция",
      "Redux middleware / Redux middleware"
    ],
    "answer": "Функция с хуками / Хук менен функция",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1670",
    "question": "Когда useCallback наиболее полезен? / useCallback качан эң пайдалуу?",
    "options": [
      "При работе с формами / Формалар менен иштөөдө",
      "При передаче функций в дочерние компоненты / Функцияларды балалык компоненттерге өткөрүүдө",
      "Для роутинга / Роутинг үчүн",
      "Для стилей / Стилдер үчүн"
    ],
    "answer": "При передаче функций в дочерние компоненты / Функцияларды балалык компоненттерге өткөрүүдө",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1674",
    "question": "Что будет без useMemo / useCallback? / useMemo / useCallback жок болсо эмне болот?",
    "options": [
      "Ошибка / Ката",
      "Повышенная нагрузка / Жогорку жүктөм",
      "Ничего не изменится / Эч нерсе өзгөрбөйт",
      "Приложение не запустится / Тиркеме иштебейт"
    ],
    "answer": "Повышенная нагрузка / Жогорку жүктөм",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa165a",
    "question": "Какой тег используется для строки таблицы? / Таблицанын катарын түзүү үчүн кайсы тег колдонулат?",
    "options": [
      "<td> / <td>",
      "<th> / <th>",
      "<tr> / <tr>",
      "<row> / <row>"
    ],
    "answer": "<tr> / <tr>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1643",
    "question": "Какое условие используется чаще всего? / Эң көп колдонулган шарт оператору кайсы?",
    "options": [
      "switch / switch",
      "if / else / if / else",
      "for / for",
      "while / while"
    ],
    "answer": "if / else / if / else",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1641",
    "question": "В чем отличие interface от type? / Interface менен type эмнеге айырмаланат?",
    "options": [
      "Нет отличий / Айырмасы жок",
      "interface можно расширять / Interface кеңейтилүүчү",
      "type нельзя использовать с объектами / Type объект менен колдонулбайт",
      "interface устарел / Interface эскирген"
    ],
    "answer": "interface можно расширять / Interface кеңейтилүүчү",
    "category": "typescript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1640",
    "question": "Для чего используются props? / Props эмне үчүн колдонулат?",
    "options": [
      "Для хранения состояния / State сактоо үчүн",
      "Для передачи данных / Маалыматты өткөрүү үчүн",
      "Для работы с DOM / DOM менен иштөө үчүн",
      "Для навигации / Навигация үчүн"
    ],
    "answer": "Для передачи данных / Маалыматты өткөрүү үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa163e",
    "question": "Какой тег обычно используют для подвала сайта? / Сайттын төмөнкү бөлүгү (footer) үчүн кайсы тег колдонулат?",
    "options": [
      "<bottom> / <bottom>",
      "<footer> / <footer>",
      "<end> / <end>",
      "<aside> / <aside>"
    ],
    "answer": "<footer> / <footer>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1636",
    "question": "Какой тег используется для навигации? / Навигация үчүн кайсы тег колдонулат?",
    "options": [
      "<menu> / <menu>",
      "<aside> / <aside>",
      "<nav> / <nav>",
      "<ul> / <ul>"
    ],
    "answer": "<nav> / <nav>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1654",
    "question": "Как перейти без перезагрузки страницы? / Баракты кайра жүктөлбөстөн кантип которулат?",
    "options": [
      "<a> / <a>",
      "window.location / window.location",
      "<Link> / <Link>",
      "redirect() / redirect()"
    ],
    "answer": "<Link> / <Link>",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1657",
    "question": "Что делает оператор spread? / Spread оператор эмне кылат?",
    "options": [
      "Удаляет элементы / Элементтерди өчүрөт",
      "Расширяет элементы / Элементтерди кеңейтет",
      "Копирует массив/объект / Массивди/объектти көчүрөт",
      "Создает функцию / Функция түзөт"
    ],
    "answer": "Копирует массив/объект / Массивди/объектти көчүрөт",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1659",
    "question": "Что такое enum? / Enum деген эмне?",
    "options": [
      "Функция / Функция",
      "Класс / Класс",
      "Набор именованных значений / Аты бар маанилер топтому",
      "Тип массива / Массивдин типи"
    ],
    "answer": "Набор именованных значений / Аты бар маанилер топтому",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa164d",
    "question": "Что такое generics? / Generics деген эмне?",
    "options": [
      "Тип по умолчанию / Default тип",
      "Универсальные типы / Универсалдуу типтер",
      "Типы только для массивов / Факты массив үчүн типтер",
      "Только для классов / Факты класстар үчүн"
    ],
    "answer": "Универсальные типы / Универсалдуу типтер",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa165b",
    "question": "Как выглядит rest параметр? / Rest параметр кандай жазылат?",
    "options": [
      "...args / ...args",
      "args... / args...",
      "rest(args) / rest(args)",
      "[args] / [args]"
    ],
    "answer": "...args / ...args",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa165c",
    "question": "Как правильно хранить компоненты? / Компоненттерди кантип туура сактоо керек?",
    "options": [
      "В одном файле / Бир файлда",
      "Без структуры / Структурасыз",
      "По папкам (pages, components) / Папкаларда (pages, components)",
      "Только в App.jsx / Факты App.jsxте"
    ],
    "answer": "По папкам (pages, components) / Папкаларда (pages, components)",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa165d",
    "question": "Когда лучше использовать enum? / Enum качан колдонууга ылайыктуу?",
    "options": [
      "Для случайных значений / Кокустан маанилер үчүн",
      "Для фиксированных значений / Туруктуу (фиксирленген) маанилер үчүн",
      "Для API / API үчүн",
      "Для форм / Формалар үчүн"
    ],
    "answer": "Для фиксированных значений / Туруктуу (фиксирленген) маанилер үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1652",
    "question": "Какой тег используется для встраивания сторонних сайтов? / Башка сайттарды киргизүү үчүн кайсы тег колдонулат?",
    "options": [
      "<object> / <object>",
      "<frame> / <frame>",
      "<iframe> / <iframe>",
      "<embed> / <embed>"
    ],
    "answer": "<iframe> / <iframe>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1655",
    "question": "Где чаще всего используют generics? / Generics көбүнчө кайда колдонулат?",
    "options": [
      "В CSS / CSSте",
      "В функциях и хуках / Функциялар жана хуктарда",
      "В HTML / HTMLде",
      "В роутинге / Роутингде"
    ],
    "answer": "В функциях и хуках / Функциялар жана хуктарда",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1660",
    "question": "Для чего используется Context API? / Context API эмне үчүн колдонулат?",
    "options": [
      "Для роутинга / Роутинг үчүн",
      "Для глобального состояния / Глобалдык state үчүн",
      "Для стилей / Стилдер үчүн",
      "Для API запросов / API чакыруулар үчүн"
    ],
    "answer": "Для глобального состояния / Глобалдык state үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1673",
    "question": "Какое событие срабатывает при отправке формы? / Форма жөнөтүлгөндө кайсы окуя иштейт?",
    "options": [
      "click / click",
      "send / send",
      "submit / submit",
      "input / input"
    ],
    "answer": "submit / submit",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.174Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa160b",
    "question": "43. Что такое ModelForm? / ModelForm деген эмне?",
    "options": [
      "HTML",
      "Форма на основе модели",
      "API",
      "URL"
    ],
    "answer": "Форма на основе модели",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1607",
    "question": "Нужен ли this в функциональном компоненте? / Functional componentте this керекпи?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Нужен для state / State үчүн керек",
      "Нужен для useEffect / useEffect үчүн керек"
    ],
    "answer": "Нет / Жок",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1605",
    "question": "#header эмнени тандайт? / Что выбирает #header?",
    "options": [
      "тег / тег",
      "id / id",
      "class / класс",
      "атрибут / атрибут"
    ],
    "answer": "id / id",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa160a",
    "question": "43. Можно ли вложить функцию в функцию? / Функция ичине функция жазса болобу?",
    "options": [
      "Нет",
      "Да",
      "Только lambda",
      "Только в классе"
    ],
    "answer": "Да",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa160c",
    "question": "div p эмнени билдирет? / Что означает селектор div p?",
    "options": [
      "div же p / div или p",
      "div ичиндеги p / p внутри div",
      "p ичиндеги div / div внутри p",
      "бардык p / все p"
    ],
    "answer": "div ичиндеги p / p внутри div",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa160e",
    "question": "Можно ли использовать хуки в class-компоненте? / Class компонентке hooks колдонсо болобу?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только useState / Факты useState гана",
      "Все хуки / Бардык hooks колдонулат"
    ],
    "answer": "Нет / Жок",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1614",
    "question": "Когда this относится к глобальному объекту? / this кайсы учурда глобалдык объектке таандык?",
    "options": [
      "Внутри функции без “strict mode” / Функциянын ичинде “strict mode” жок болсо",
      "Внутри класса / Класстын ичинде",
      "В стрелочной функции / Arrow функциясында",
      "Всегда / Ар дайым"
    ],
    "answer": "Внутри функции без “strict mode” / Функциянын ичинде “strict mode” жок болсо",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1615",
    "question": "В чём основное отличие class и functional компонентов? / Class vs Functional component айырмасы эмнеде негизги?",
    "options": [
      "В class-компоненте есть lifecycle methods и this, functional-компонент пишется с хуками / Class компонентте lifecycle methods жана this бар, functional component hook менен жазылат",
      "Functional-компонент не может хранить state / Functional компонент state сактай албайт",
      "В class-компоненте нельзя писать JSX / Class компонентте JSX жазылбайт",
      "У functional-компонента нет props / Functional компонентте props жок"
    ],
    "answer": "В class-компоненте есть lifecycle methods и this, functional-компонент пишется с хуками / Class компонентте lifecycle methods жана this бар, functional component hook менен жазылат",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1617",
    "question": "45. Как завершить программу вручную? / Программаны кантип токтотобуз?",
    "options": [
      "stop",
      "exit()",
      "close",
      "break"
    ],
    "answer": "exit()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa161f",
    "question": "Как JavaScript работает в браузере? / JavaScript браузерде кантип иштейт?",
    "options": [
      "Выполняется на сервере / Серверде иштейт",
      "Компилируется заранее / Алдын ала компиляцияланат",
      "Выполняется движком браузера / Браузердин движогу аркылуу иштейт",
      "Работает только с HTML / Факты HTML менен гана иштейт"
    ],
    "answer": "Выполняется движком браузера / Браузердин движогу аркылуу иштейт",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1623",
    "question": "Что делает метод Array.push()? / Array.push() методу эмне кылат?",
    "options": [
      "Удаляет последний элемент / Акыркы элементти өчүрөт",
      "Добавляет элемент в конец массива / Массивдин аягына элемент кошот",
      "Сортирует массив / Массивди сорттойт",
      "Создает новый массив / Жаңы массив түзөт"
    ],
    "answer": "Добавляет элемент в конец массива / Массивдин аягына элемент кошот",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1627",
    "question": "Какое окно показывает сообщение без ввода? / Кайсы терезе маалымат көрсөтөт, бирок киргизүүнү талап кылбайт?",
    "options": [
      "prompt / prompt",
      "alert / alert",
      "confirm / confirm",
      "modal / modal"
    ],
    "answer": "alert / alert",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1629",
    "question": "Как указать тип number? / number типин кантип көрсөтүү керек?",
    "options": [
      "let a = number / let a = number",
      "let a: number / let a: number",
      "number a / number a",
      "let number = a / let number = a"
    ],
    "answer": "let a: number / let a: number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1608",
    "question": "Какой тип в TypeScript используется для “функции, которая никогда не возвращает значение”? / TypeScriptте кайсы тип менен “эч качан кайтарылбай турган функция” көрсөтүлөт?",
    "options": [
      "void / void",
      "never / never",
      "any / any",
      "unknown / unknown"
    ],
    "answer": "never / never",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1610",
    "question": "44. Что делает clear()? / clear() эмне кылат?",
    "options": [
      "Добавляет элемент",
      "Удаляет последний",
      "Очищает коллекцию",
      "Сортирует"
    ],
    "answer": "Очищает коллекцию",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1612",
    "question": "44. Что такое CSRF? / CSRF деген эмне?",
    "options": [
      "Ошибка",
      "Защита формы",
      "БД",
      "Статика"
    ],
    "answer": "Защита формы",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1616",
    "question": "Для чего используется literal type в TypeScript? / TypeScriptте literal type эмнеге колдонулат?",
    "options": [
      "Чтобы принимать только определённое значение / Белгилүү бир маанини гана кабыл алуу үчүн",
      "Для хранения любых значений / Ар кандай маанини сактоо үчүн",
      "Чтобы сделать массив immutable / Массивди immutable кылуу үчүн",
      "Всё неверно / Бардыгы туура эмес"
    ],
    "answer": "Чтобы принимать только определённое значение / Белгилүү бир маанини гана кабыл алуу үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa161a",
    "question": "Какой тег используется для указания типа HTML-документа? / HTML документтин түрүн көрсөтүү үчүн кайсы тег колдонулат?",
    "options": [
      "<html> / <html>",
      "<head> / <head>",
      "<!DOCTYPE html> / <!DOCTYPE html>",
      "<meta> / <meta>"
    ],
    "answer": "<!DOCTYPE html> / <!DOCTYPE html>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa161b",
    "question": "Что такое JavaScript? / JavaScript деген эмне?",
    "options": [
      "Язык разметки / Белгилөө тили",
      "Язык стилей / Стиль тили",
      "Язык программирования / Программалоо тили",
      "База данных / Маалымат базасы"
    ],
    "answer": "Язык программирования / Программалоо тили",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa161e",
    "question": "Какой тег является корневым элементом HTML-документа? / HTML документтеги тамыр элемент кайсы тег?",
    "options": [
      "<body> / <body>",
      "<head> / <head>",
      "<html> / <html>",
      "<main> / <main>"
    ],
    "answer": "<html> / <html>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1620",
    "question": "Кто разработал React? / Reactти ким иштеп чыккан?",
    "options": [
      "Google / Google",
      "Microsoft / Microsoft",
      "Facebook (Meta) / Facebook (Meta)",
      "Amazon / Amazon"
    ],
    "answer": "Facebook (Meta) / Facebook (Meta)",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1625",
    "question": "Что происходит с TypeScript кодом? / TypeScript коду менен эмне болот?",
    "options": [
      "Выполняется напрямую в браузере / Браузерде түздөн-түз иштейт",
      "Компилируется в JavaScript / JavaScriptке компиляцияланат",
      "Запускается на сервере / Серверде иштейт",
      "Удаляется / Өчүрүлөт"
    ],
    "answer": "Компилируется в JavaScript / JavaScriptке компиляцияланат",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa162e",
    "question": "Какой тег используется для шапки сайта? / Сайттын башын (header) түзүү үчүн кайсы тег колдонулат?",
    "options": [
      "<top> / <top>",
      "<header> / <header>",
      "<head> / <head>",
      "<nav> / <nav>"
    ],
    "answer": "<header> / <header>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1609",
    "question": "43. Как удалить последний элемент списка? / Акыркы элементти кантип өчүрөбүз?",
    "options": [
      "remove()",
      "pop()",
      "delete()",
      "cut()"
    ],
    "answer": "pop()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa162d",
    "question": "Чем отличается unknown от any? / unknown менен any эмнеге айырмаланат?",
    "options": [
      "Ничем / Эч нерседен айырмаланбайт",
      "unknown безопаснее / unknown коопсузураак",
      "any строже / any катуураак",
      "unknown нельзя использовать / unknown колдонулбайт"
    ],
    "answer": "unknown безопаснее / unknown коопсузураак",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa162c",
    "question": "Что JSX компилируется в итоге? / JSX акырында эмне болот?",
    "options": [
      "HTML / HTML",
      "CSS / CSS",
      "JavaScript / JavaScript",
      "JSON / JSON"
    ],
    "answer": "JavaScript / JavaScript",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa162a",
    "question": "Какой атрибут указывает путь к изображению? / Сүрөттүн жолун көрсөтүүчү атрибут кайсы?",
    "options": [
      "href / href",
      "src / src",
      "alt / alt",
      "link / link"
    ],
    "answer": "src / src",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1626",
    "question": "Где правильно указывать атрибут? / Атрибутту кайда туура жазуу керек?",
    "options": [
      "Внутри содержимого / Контенттин ичинде",
      "Внутри открывающего тега / Ачыла турган тегдин ичинде",
      "В закрывающем теге / Жабылуучу тегдин ичинде",
      "В CSS-файле / CSS файлына жазуу"
    ],
    "answer": "Внутри открывающего тега / Ачыла турган тегдин ичинде",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1624",
    "question": "Что такое SPA? / SPA деген эмне?",
    "options": [
      "Многостраничный сайт / Көп беттүү сайт",
      "Сайт без JavaScript / JavaScriptсиз сайт",
      "Приложение без перезагрузки страниц / Барактарды кайра жүктөбөгөн тиркеме",
      "Только мобильное приложение / Факты мобилдик тиркеме"
    ],
    "answer": "Приложение без перезагрузки страниц / Барактарды кайра жүктөбөгөн тиркеме",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1622",
    "question": "Что такое HTML-тег? / HTML-тег деген эмне?",
    "options": [
      "Стиль оформления / Стиль оформления",
      "Команда браузеру / Браузерге буйрук",
      "Элемент разметки / Элемент разметки",
      "Язык программирования / Программалоо тили"
    ],
    "answer": "Элемент разметки / Элемент разметки",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1621",
    "question": "Основная цель TypeScript? / TypeScriptтин негизги максаты эмнеде?",
    "options": [
      "Ускорить код / Кодду ылдамдатуу",
      "Добавить типизацию / Типизация кошуу",
      "Уменьшить размер бандла / Бандлдын көлөмүн азайтуу",
      "Убрать баги полностью / Каталарды толугу менен жок кылуу"
    ],
    "answer": "Добавить типизацию / Типизация кошуу",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1619",
    "question": "45. Для чего Django используют чаще всего? / Django көбүнчө эмне үчүн колдонулат?",
    "options": [
      "Игры",
      "Веб-сайты и сервисы",
      "Драйверы",
      "ОС"
    ],
    "answer": "Веб-сайты и сервисы",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1618",
    "question": "45. Что такое глобальная переменная? / Глобалдык өзгөрмө деген эмне?",
    "options": [
      "Внутри функции",
      "Доступна везде",
      "Только в классе",
      "Только в цикле"
    ],
    "answer": "Доступна везде",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa160d",
    "question": "Какой оператор в JavaScript выполняет инкремент (увеличение)? / Кайсы оператор JavaScriptте көбөйтүүнү (increment) жасайт?",
    "options": [
      "– / –",
      "/",
      "= / =",
      "** / **"
    ],
    "answer": "= / =",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1606",
    "question": "Какой синтаксис создаёт async-функцию? / Кайсы синтаксис async функция түзөт?",
    "options": [
      "function async myFunc() {} / function async myFunc() {}",
      "async function myFunc() {} / async function myFunc() {}",
      "myFunc async function() {} / myFunc async function() {}",
      "function myFunc() async {} / function myFunc() async {}"
    ],
    "answer": "async function myFunc() {} / async function myFunc() {}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1604",
    "question": "42. Что такое forms.py? / forms.py эмне үчүн керек?",
    "options": [
      "Для URL",
      "Для форм",
      "Для моделей",
      "Для шаблонов"
    ],
    "answer": "Для форм",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1603",
    "question": "42. Что делает isinstance()? / isinstance() эмне кылат?",
    "options": [
      "Преобразует тип",
      "Проверяет тип",
      "Удаляет объект",
      "Создаёт класс"
    ],
    "answer": "Проверяет тип",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1602",
    "question": "42. Как скопировать список? / Тизмени кантип көчүрөбүз?",
    "options": [
      "a = b",
      "a.copy()",
      "clone(a)",
      "new a"
    ],
    "answer": "a.copy()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa160f",
    "question": "Какое расширение файла используется в TypeScript? / TypeScriptте кайсы файл кеңейтүүсү колдонулат?",
    "options": [
      ".js / .js",
      ".ts / .ts",
      ".jsx / .jsx",
      ".tsx / .tsx"
    ],
    "answer": ".ts / .ts",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1611",
    "question": "44. Что такое область видимости? / Область видимости деген эмне?",
    "options": [
      "Ошибка",
      "Где доступна переменная",
      "Тип данных",
      "Модуль"
    ],
    "answer": "Где доступна переменная",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1613",
    "question": ":hover качан иштейт? / Когда срабатывает :hover?",
    "options": [
      "басканда / при нажатии",
      "курсор үстүнө келгенде / когда курсор наведён",
      "фокуста / при фокусе",
      "жүктөлгөндө / при загрузке страницы"
    ],
    "answer": "курсор үстүнө келгенде / когда курсор наведён",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa161c",
    "question": "Что такое React? / React деген эмне?",
    "options": [
      "Язык программирования / Программалоо тили",
      "Backend-фреймворк / Backend фреймворк",
      "JavaScript библиотека для UI / UI түзүү үчүн JavaScript китепкана",
      "CMS система / CMS система"
    ],
    "answer": "JavaScript библиотека для UI / UI түзүү үчүн JavaScript китепкана",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa161d",
    "question": "Что такое TypeScript? / TypeScript деген эмне?",
    "options": [
      "Новый язык вместо JavaScript / JavaScriptтин ордуна жаңы тил",
      "Надстройка над JavaScript с типизацией / JavaScript үстүндө типизация кошулган кошумча",
      "Backend язык / Backend тили",
      "Фреймворк / Фреймворк"
    ],
    "answer": "Надстройка над JavaScript с типизацией / JavaScript үстүндө типизация кошулган кошумча",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1628",
    "question": "Что такое JSX? / JSX деген эмне?",
    "options": [
      "Отдельный язык / Өзүнчө тил",
      "HTML файл / HTML файлы",
      "Расширение синтаксиса JavaScript / JavaScript синтаксисинин кеңейтилген түрү",
      "CSS препроцессор / CSS препроцессору"
    ],
    "answer": "Расширение синтаксиса JavaScript / JavaScript синтаксисинин кеңейтилген түрү",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa162b",
    "question": "Какое окно возвращает true или false? / Кайсы терезе true же false кайтарат?",
    "options": [
      "alert / alert",
      "prompt / prompt",
      "confirm / confirm",
      "input / input"
    ],
    "answer": "confirm / confirm",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.173Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c3",
    "question": "33. Что делает input()? / input() эмне кылат?",
    "options": [
      "Выводит текст",
      "Получает данные пользователя",
      "Считает числа",
      "Завершает программу"
    ],
    "answer": "Получает данные пользователя",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ec",
    "question": "Какой синтаксис создаёт класс в TypeScript? / TypeScriptте кайсы синтаксис менен класс түзүлөт?",
    "options": [
      "class Person { name: string; constructor(name: string) { this.name = name; } } / class Person { name: string; constructor(name: string) { this.name = name; } }",
      "let Person = class {} / let Person = class {}",
      "class Person(name) { this.name = name; } / class Person(name) { this.name = name; }",
      "A и B / A жана B"
    ],
    "answer": "A и B / A жана B",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e3",
    "question": "Что выведет console.log(typeof NaN)? / console.log(typeof NaN) кантип чыгарат?",
    "options": [
      "\"number\" / \"number\"",
      "\"NaN\" / \"NaN\"",
      "\"undefined\" / \"undefined\"",
      "\"object\" / \"object\""
    ],
    "answer": "\"number\" / \"number\"",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e2",
    "question": "Видео автоматтык ойношу үчүн эмне колдонулат? / Как сделать, чтобы видео воспроизводилось автоматически?",
    "options": [
      "auto / auto",
      "play / play",
      "start / start",
      "autoplay / autoplay"
    ],
    "answer": "autoplay / autoplay",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15df",
    "question": "37. Как создать пустую функцию? / Бош функция кантип түзүлөт?",
    "options": [
      "def f(): stop",
      "def f(): None",
      "def f(): pass",
      "f()"
    ],
    "answer": "def f(): pass",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15db",
    "question": "Сүрөт жүктөлбөсө, текстти кайсы атрибут көрсөтөт? / Какой атрибут показывает текст, если изображение не загрузилось?",
    "options": [
      "<link> / <link>",
      "alt / alt",
      "<href> / <href>",
      "<img> / <img>"
    ],
    "answer": "alt / alt",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15da",
    "question": "36. Что делает collectstatic? / collectstatic эмне кылат?",
    "options": [
      "Удаляет файлы",
      "Собирает статику",
      "Делает миграции",
      "Запускает сервер"
    ],
    "answer": "Собирает статику",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d7",
    "question": "Каким оператором в TypeScript создаётся union type? / TypeScriptте кайсы оператор менен union type түзүлөт?",
    "options": [
      "| / |",
      "& / &",
      "? / ?",
      ": / :"
    ],
    "answer": "| / |",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d3",
    "question": "35. Что такое media? / media деген эмне?",
    "options": [
      "Видео",
      "Пользовательские файлы",
      "CSS",
      "URL"
    ],
    "answer": "Пользовательские файлы",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d2",
    "question": "35. Как импортировать модуль math? / math модулун кантип импорттойбуз?",
    "options": [
      "include math",
      "import math",
      "using math",
      "load math"
    ],
    "answer": "import math",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c5",
    "question": "33. Что такое static? / static деген эмне?",
    "options": [
      "HTML",
      "CSS, JS, изображения",
      "БД",
      "View"
    ],
    "answer": "CSS, JS, изображения",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ed",
    "question": "39. Как проверить, что список пуст? / Тизме бош экенин кантип текшеребиз?",
    "options": [
      "len(a) == 0",
      "a = None",
      "a.empty()",
      "size(a)"
    ],
    "answer": "len(a) == 0",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c4",
    "question": "33. Как создать lambda? / Lambda кантип жазылат?",
    "options": [
      "lambda x: x1",
      "def lambda(x)",
      "new lambda",
      "lambda(x){}"
    ],
    "answer": "lambda x: x1",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1601",
    "question": "Какой оператор в TypeScript указывает возвращаемый тип функции? / Кайсы оператор TypeScriptте функциянын кайтаруучу типин көрсөтөт?",
    "options": [
      ": / :",
      "=> / =>",
      "= / =",
      "as / as"
    ],
    "answer": ": / :",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ee",
    "question": "39. Что такое исключение? / Исключение деген эмне?",
    "options": [
      "Цикл",
      "Ошибка во время выполнения",
      "Метод",
      "Переменная"
    ],
    "answer": "Ошибка во время выполнения",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c2",
    "question": "Какое расширение файла нужно для использования TypeScript в React? / Reactте TypeScriptти колдонуу үчүн файл кеңейтүүсү кандай болушу керек?",
    "options": [
      ".js / .js",
      ".ts / .ts",
      ".jsx / .jsx",
      ".tsx / .tsx"
    ],
    "answer": ".tsx / .tsx",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c6",
    "question": "Видео кошуу үчүн кайсыл тег колдонулат? / Какой тег используется для добавления видео?",
    "options": [
      "<mp4> / <mp4>",
      "<video> / <video>",
      "<media> / <media>",
      "<movie> / <movie>"
    ],
    "answer": "<video> / <video>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c7",
    "question": "Серверден маалымат алуу үчүн кайсы метод колдонулат? / Какой метод используется для получения данных с сервера?",
    "options": [
      "GET / GET",
      "POST / POST",
      "DELETE / DELETE",
      "PUT / PUT"
    ],
    "answer": "GET / GET",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c8",
    "question": "Как в React компоненте читать Redux state? / React компонентинде Redux stateти кантип окуйт?",
    "options": [
      "Через useState / useState менен",
      "Через хук useSelector / useSelector hook менен",
      "Только через Props / Props аркылуу гана",
      "Прямо из DOM / DOMдан түз окуйт"
    ],
    "answer": "Через хук useSelector / useSelector hook менен",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ca",
    "question": "34. Как преобразовать строку в float? / Строканы floatка айлантуу?",
    "options": [
      "int()",
      "str()",
      "float()",
      "bool()"
    ],
    "answer": "float()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15cc",
    "question": "34. Где хранятся статические файлы? / Статика кайда?",
    "options": [
      "templates",
      "media",
      "static",
      "views"
    ],
    "answer": "static",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ce",
    "question": "API деген эмне? / Что такое API?",
    "options": [
      "Обмен данными между клиентом и сервером / Клиент менен сервер ортосунда маалымат алмашуу",
      "Место для хранения файлов / Файл сактоочу жер",
      "HTML элемент / HTML элемент",
      "Хранилище / Хранилище"
    ],
    "answer": "Обмен данными между клиентом и сервером / Клиент менен сервер ортосунда маалымат алмашуу",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15dc",
    "question": "Какой оператор в JavaScript проверяет строгое неравенство? / Кандай оператор JavaScriptте бирдей эмес экенин текшерет?",
    "options": [
      "= / =",
      "== / ==",
      "!= / !=",
      "!== / !=="
    ],
    "answer": "!== / !==",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e1",
    "question": "37. Что такое ORM? / ORM деген эмне?",
    "options": [
      "API",
      "Работа с БД через Python",
      "Шаблон",
      "Сервер"
    ],
    "answer": "Работа с БД через Python",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e9",
    "question": "Кайсы тег inline элемент? / Какой тег является inline элементом?",
    "options": [
      "<span> / <span>",
      "<div> / <div>",
      "<button> / <button>",
      "<p> / <p>"
    ],
    "answer": "<span> / <span>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15cb",
    "question": "34. Что такое модуль? / Модуль деген эмне?",
    "options": [
      "Папка",
      ".py файл",
      "Таблица",
      "Сервер"
    ],
    "answer": ".py файл",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15fd",
    "question": "41. Что такое QuerySet? / QuerySet деген эмне?",
    "options": [
      "HTML",
      "Набор объектов",
      "Файл",
      "URL"
    ],
    "answer": "Набор объектов",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ff",
    "question": "Какой оператор является логическим “или”? / Кайсы оператор “же” логикалык оператору?",
    "options": [
      "&& / &&",
      "|| / ||",
      "! / !",
      "== / =="
    ],
    "answer": "|| / ||",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15fc",
    "question": "41. Как проверить тип переменной? / Өзгөрмөнүн тибин кантип текшеребиз?",
    "options": [
      "check()",
      "type()",
      "typeof()",
      "getType()"
    ],
    "answer": "type()",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15fb",
    "question": "41. Можно ли хранить разные типы в списке? / Тизмеде ар түрдүү типтер болобу?",
    "options": [
      "Нет",
      "Да",
      "Только числа",
      "Только строки"
    ],
    "answer": "Да",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15fa",
    "question": "Какой оператор в TypeScript используется для null и undefined? / TypeScriptте кайсы оператор null жана undefined үчүн колдонулат?",
    "options": [
      "?? / ??",
      "|| / ||",
      "&& / &&",
      "! / !"
    ],
    "answer": "?? / ??",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f8",
    "question": "setTimeout функциясы эмне үчүн колдонулат? / Для чего используется функция setTimeout?",
    "options": [
      "Вызывать функцию сразу / Функцияны дароо чакыруу үчүн",
      "Вызывать функцию через определённое время / Функцияны белгилүү убакыттан кийин чакыруу үчүн",
      "Вызывать функцию повторно / Функцияны кайра чакыруу үчүн",
      "Получать элементы DOM / DOM элементтерин алып келүү үчүн"
    ],
    "answer": "Вызывать функцию через определённое время / Функцияны белгилүү убакыттан кийин чакыруу үчүн",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f7",
    "question": "display: inline-block өзгөчөлүгү? / Какое свойство имеет display: inline-block?",
    "options": [
      "width иштебейт / width не работает",
      "height иштебейт / height не работает",
      "width height иштейт / width и height работают",
      "margin иштебейт / margin не работает"
    ],
    "answer": "width height иштейт / width и height работают",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f1",
    "question": "Какая функция переносит элементы массива в новый массив? / Кайсы функция массивдин элементтерин жаңы массивке өткөрөт?",
    "options": [
      "map() / map()",
      "filter() / filter()",
      "forEach() / forEach()",
      "reduce() / reduce()"
    ],
    "answer": "map() / map()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f0",
    "question": "CSS Specificity туура ирети кайсы? / Какой правильный порядок специфичности CSS?",
    "options": [
      "element => class => id / элемент => класс => id",
      "id => class => element / id => класс => элемент",
      "class => element => id / класс => элемент => id",
      "inline => element => div / inline => элемент => div"
    ],
    "answer": "element => class => id / элемент => класс => id",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c9",
    "question": "Какая компания разработала TypeScript? / TypeScript кайсы компания тарабынан иштелип чыккан?",
    "options": [
      "Google / Google",
      "Microsoft / Microsoft",
      "Facebook / Facebook",
      "Apple / Apple"
    ],
    "answer": "Microsoft / Microsoft",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ef",
    "question": "39. Как создать объект модели? / Модель объектисин түзүү?",
    "options": [
      "Model.add()",
      "Model.create()",
      "Model.objects.create()",
      "new Model()"
    ],
    "answer": "Model.objects.create()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ea",
    "question": "Можно ли изменить переменную, объявленную через const? / const менен белгиленген өзгөрмөнү өзгөртүүгө болобу?",
    "options": [
      "Да, всегда / Ооба, ар дайым",
      "Нет, никогда / Жок, эч качан",
      "Можно изменять внутренние свойства объекта, но нельзя переназначить саму переменную / Объекттин ички мүчөлөрүн өзгөртүүгө болот, бирок өзүн толугу менен өзгөртүүгө болбойт",
      "Нельзя, и для массивов тоже / Болбойт, бирок массивтерге болбойт"
    ],
    "answer": "Можно изменять внутренние свойства объекта, но нельзя переназначить саму переменную / Объекттин ички мүчөлөрүн өзгөртүүгө болот, бирок өзүн толугу менен өзгөртүүгө болбойт",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e8",
    "question": "38. Как получить все объекты модели? / Бардык объекттерди алуу?",
    "options": [
      "Model.all()",
      "Model.objects.get()",
      "Model.objects.all()",
      "Model.list()"
    ],
    "answer": "Model.objects.all()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e7",
    "question": "38. Что делает try/except? / try/except эмне кылат?",
    "options": [
      "Создаёт цикл",
      "Обрабатывает ошибки",
      "Импортирует",
      "Завершает код"
    ],
    "answer": "Обрабатывает ошибки",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e4",
    "question": "Как в JSX использовать inline style? / JSXте style inline кантип колдонулат?",
    "options": [
      "<div style={{ color: 'red', fontSize: '16px' }}>Text</div> / <div style={{ color: 'red', fontSize: '16px' }}>Text</div>",
      "<div style=\"color: red; font-size:16px;\">Text</div> / <div style=\"color: red; font-size:16px;\">Text</div>",
      "<div style={ color: 'red' }>Text</div> / <div style={ color: 'red' }>Text</div>",
      "<div style=color:red>Text</div> / <div style=color:red>Text</div>"
    ],
    "answer": "<div style={{ color: 'red', fontSize: '16px' }}>Text</div> / <div style={{ color: 'red', fontSize: '16px' }}>Text</div>",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15dd",
    "question": "Какова основная цель React? / Reactтин негизги максаты эмнеде?",
    "options": [
      "Построение backend сервера / Backend сервер куруу",
      "Создание frontend интерфейса декларативно и на основе компонентов / Frontend интерфейсин декларативдүү жана компоненттик негизде түзүү",
      "Управление базой данных / Database башкаруу",
      "Оптимизация CSS стилей / CSS стили оптималдаштыруу"
    ],
    "answer": "Создание frontend интерфейса декларативно и на основе компонентов / Frontend интерфейсин декларативдүү жана компоненттик негизде түзүү",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d6",
    "question": "Для чего используется хук useState? / useState hook эмнеге колдонулат?",
    "options": [
      "Предотвращение rerender компонента / Component rerender алдын алуу",
      "Хранение внутреннего состояния компонента / Компоненттин internal state сактоо",
      "Получение DOM reference / DOM reference алуу",
      "Управление асинхронными операциями / Async операция башкаруу"
    ],
    "answer": "Хранение внутреннего состояния компонента / Компоненттин internal state сактоо",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d5",
    "question": "Какая команда создаёт локальный репозиторий? / Локалдык репозиторийди кайсы команда түзөт?",
    "options": [
      "git commit / git commit",
      "git init / git init",
      "git add / git add",
      "git push / git push"
    ],
    "answer": "git init / git init",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f2",
    "question": "Что произойдёт, если функция не возвращает значение? / Function return жок болсо, эмне болот?",
    "options": [
      "Вернётся undefined / undefined кайтарылат",
      "Возникнет ошибка / Error чыгат",
      "JSX отрендерится автоматически / JSX автоматтык render болот",
      "Вернётся Boolean / Boolean кайтарылат"
    ],
    "answer": "Вернётся undefined / undefined кайтарылат",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f4",
    "question": "40. Как создать set? / set кантип түзүлөт?",
    "options": [
      "[]",
      "()",
      "{}",
      "set()"
    ],
    "answer": "set()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f6",
    "question": "40. Как удалить объект? / Объектти кантип өчүрөбүз?",
    "options": [
      "remove()",
      "del",
      "delete()",
      "clear()"
    ],
    "answer": "delete()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f9",
    "question": "Как создаётся class-компонент в React? / Reactте class компонент кантип түзүлөт?",
    "options": [
      "class MyComponent extends React.Component { render() { return <h1>Hello</h1>; } } / class MyComponent extends React.Component {render(){return <h1>Hello</h1>}}",
      "function MyComponent() { return <h1>Hello</h1> } / function MyComponent() { return <h1>Hello</h1> }",
      "component MyComponent { return <h1>Hello</h1> } / component MyComponent { return <h1>Hello</h1> }",
      "const MyComponent = () => <h1>Hello</h1> / const MyComponent = () => <h1>Hello</h1>"
    ],
    "answer": "class MyComponent extends React.Component { render() { return <h1>Hello</h1>; } } / class MyComponent extends React.Component {render(){return <h1>Hello</h1>}}",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1600",
    "question": "Как создаётся state в class-компоненте? / Class компонентте state кантип түзүлөт?",
    "options": [
      "this.state = { count: 0 } / this.state = { count: 0 }",
      "const [count, setCount] = useState(0) / const [count, setCount] = useState(0)",
      "state = useState(0) / state = useState(0)",
      "let state = {count:0} / let state = {count:0}"
    ],
    "answer": "this.state = { count: 0 } / this.state = { count: 0 }",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15fe",
    "question": "top: 20px качан иштейт? / Когда работает top: 20px?",
    "options": [
      "ар дайым / всегда",
      "position бар болгондо / только если задано свойство position",
      "width бар болсо / если задан width",
      "display block болгондо / если display: block"
    ],
    "answer": "position бар болгондо / только если задано свойство position",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d0",
    "question": "Когда появился TypeScript? / TypeScript качан пайда болгон?",
    "options": [
      "2010 / 2010",
      "2012 / 2012",
      "2015 / 2015",
      "2018 / 2018"
    ],
    "answer": "2012 / 2012",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f3",
    "question": "Для чего используется оператор keyof в TypeScript? / TypeScriptте keyof оператору эмне үчүн колдонулат?",
    "options": [
      "Берёт все ключи объекта как тип / Объекттин бардык ачкычтарын тип катары алат",
      "Берёт все значения объекта / Объекттин бардык маанисин алат",
      "Берёт длину массива / Массивдин узундугун алат",
      "Такой функции нет / Бул функция жок"
    ],
    "answer": "Берёт все ключи объекта как тип / Объекттин бардык ачкычтарын тип катары алат",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15cd",
    "question": "HTML файлды браузерде ачуу үчүн эмне керек? / Что нужно, чтобы открыть HTML-файл в браузере?",
    "options": [
      "Сервер / Сервер",
      "Интернет / Интернет",
      "Браузер / Браузер",
      "Ноутбук / Ноутбук"
    ],
    "answer": "Браузер / Браузер",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15cf",
    "question": "Для чего нужен initialState внутри slice в Redux Toolkit? / Redux Toolkit slice ичиндеги initialState эмне үчүн керек?",
    "options": [
      "Задать default state для работы логики reducer / Reducer логикасы иштеши үчүн default stateти берүү",
      "Для генерации action / Action генерациялоо үчүн",
      "Для работы middleware / Middleware иштөө үчүн",
      "Для вызова AsyncThunk / AsyncThunk чакыруу үчүн"
    ],
    "answer": "Задать default state для работы логики reducer / Reducer логикасы иштеши үчүн default stateти берүү",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d1",
    "question": "35. Какой логический оператор НЕ? / Логикалык НЕ оператору кайсы?",
    "options": [
      "!",
      "not",
      "no",
      "!="
    ],
    "answer": "not",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d4",
    "question": "Бир нече сап текст киргизүү? / Как сделать поле для ввода многострочного текста?",
    "options": [
      "<input> / <input>",
      "<textarea> / <textarea>",
      "<textbox> / <textbox>",
      "<input> / <input>"
    ],
    "answer": "<textarea> / <textarea>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15d9",
    "question": "36. Как импортировать конкретную функцию? / Белгилүү функцияны кантип импорттойбуз?",
    "options": [
      "import sqrt",
      "from math import sqrt",
      "math->sqrt",
      "include sqrt"
    ],
    "answer": "from math import sqrt",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15de",
    "question": "Какие типы есть в TypeScript? / TypeScriptте кандай типтер бар?",
    "options": [
      "number, string, boolean / number, string, boolean",
      "any, void, unknown / any, void, unknown",
      "tuple, enum / tuple, enum",
      "Всё перечисленное / Бардыгы туура"
    ],
    "answer": "Всё перечисленное / Бардыгы туура",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e0",
    "question": "37. Где хранятся установленные библиотеки? / Орнотулган китепканалар кайда сакталат?",
    "options": [
      "static",
      "templates",
      "site-packages",
      "GitHub"
    ],
    "answer": "site-packages",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e5",
    "question": "Какой оператор в TypeScript используется для проверки типа? / Кайсы оператор TypeScriptте тип текшерүүсү үчүн колдонулат?",
    "options": [
      "= / =",
      "typeof / typeof",
      "instanceof / instanceof",
      "B и C / B жана C"
    ],
    "answer": "B и C / B жана C",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15e6",
    "question": "38. Что делает pass? / pass эмне кылат?",
    "options": [
      "Завершает",
      "Пропускает код",
      "Ломает программу",
      "Вызывает ошибку"
    ],
    "answer": "Пропускает код",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15eb",
    "question": "Как в JSX пишется fragment? / JSXте fragment кантип жазылат?",
    "options": [
      "<React.Fragment>...</React.Fragment> или <>...</> / <React.Fragment>...</React.Fragment> же <>...</>",
      "<Fragment>...</Fragment> / <Fragment>...</Fragment>",
      "Только <>...</> / <></> гана",
      "В JSX нет fragment / JSXте fragment жок"
    ],
    "answer": "<React.Fragment>...</React.Fragment> или <>...</> / <React.Fragment>...</React.Fragment> же <>...</>",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15f5",
    "question": "40. Можно ли создать свой модуль? / Өз модулубузду түзсө болобу?",
    "options": [
      "Нет",
      "Да",
      "Только через pip",
      "Только в Django"
    ],
    "answer": "Да",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.172Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b8",
    "question": "Төмөнкү кайсы код туура жазылган? / Какой из приведённых кодов написан правильно?",
    "options": [
      "<a link=\"https://site.com\">Сайт</a> / <a link=\"https://site.com\">Сайт</a>",
      "<a href=\"https://site.com\">Сайт</a> / <a href=\"https://site.com\">Сайт</a>",
      "<a src=\"https://site.com\">Сайт</a> / <a src=\"https://site.com\">Сайт</a>",
      "<link href=\"https://site.com\">Сайт</link> / <link href=\"https://site.com\">Сайт</link>"
    ],
    "answer": "<a href=\"https://site.com\">Сайт</a> / <a href=\"https://site.com\">Сайт</a>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15bc",
    "question": "32. Как получить длину строки? / Саптын узундугун кантип алабыз?",
    "options": [
      "size()",
      "count()",
      "len()",
      "long()"
    ],
    "answer": "len()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15bf",
    "question": "Пароль киргизүү? / Как сделать поле для ввода пароля?",
    "options": [
      "<input type=\"text\"> / <input type=\"text\">",
      "<input type=\"password\"> / <input type=\"password\">",
      "<input type=\"hidden\"> / <input type=\"hidden\">",
      "<password> / <password>"
    ],
    "answer": "<input type=\"password\"> / <input type=\"password\">",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ac",
    "question": "Какая функция используется для создания Slice? / Slice түзүү үчүн кайсы функция колдонулат?",
    "options": [
      "createSlice() / createSlice()",
      "createReducer() / createReducer()",
      "createStore() / createStore()",
      "createAction() / createAction()"
    ],
    "answer": "createSlice() / createSlice()",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15bb",
    "question": "Какой тип в TypeScript относится к примитивным? / TypeScriptте кайсы тип primitive типке кирет?",
    "options": [
      "number / number",
      "string / string",
      "boolean / boolean",
      "Все перечисленные / Бардыгы туура"
    ],
    "answer": "Все перечисленные / Бардыгы туура",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b6",
    "question": "31. Что такое lambda-функция? / Lambda функция деген эмне?",
    "options": [
      "Класс",
      "Короткая функция",
      "Модуль",
      "Цикл"
    ],
    "answer": "Короткая функция",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15be",
    "question": "32. Как связать URL и view? / URL менен view кантип байланыштырабыз?",
    "options": [
      "Через model",
      "Через path()",
      "Через admin",
      "Через settings"
    ],
    "answer": "Через path()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ab",
    "question": "let number = [1, 2, 3, 4, 5]; number.splice(2, 2) кандай натыйжа берет? / Какой результат будет после number.splice(2, 2)?",
    "options": [
      "[1, 2, 5] / [1, 2, 5]",
      "[1, 4] / [1, 4]",
      "[1, 4, 5] / [1, 4, 5]",
      "[1, 5] / [1, 5]"
    ],
    "answer": "[1, 2, 5] / [1, 2, 5]",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15af",
    "question": "30. Что такое значение по умолчанию? / Демейки маани деген эмне?",
    "options": [
      "Ошибка",
      "Значение, если аргумент не передан",
      "Тип данных",
      "Модуль"
    ],
    "answer": "Значение, если аргумент не передан",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b0",
    "question": "30. Где настраиваются URL приложения? / App URL кайда?",
    "options": [
      "models.py",
      "views.py",
      "app/urls.py",
      "admin.py"
    ],
    "answer": "app/urls.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b1",
    "question": "<div> тэгинин негизги максаты эмне? / Какова основная цель тега <div>?",
    "options": [
      "Тизмелерди түзүү / Создавать списки",
      "Сүрөт киргизүү / Вставлять изображения",
      "Веб-баракта бөлүктөрдү топтоо жана структура түзүү / Группировать части веб-страницы и создавать структуру",
      "Шрифт өзгөртүү / Изменять шрифт"
    ],
    "answer": "Веб-баракта бөлүктөрдү топтоо жана структура түзүү / Группировать части веб-страницы и создавать структуру",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b2",
    "question": "Что делает JSON.stringify()? / JSON.stringify() эмне кылат?",
    "options": [
      "Преобразует JSON в объект / JSON’ду объектке айлантат",
      "Преобразует объект в текст / Объектти текстке айлантат",
      "Преобразует текст в изображение / Текстти сүрөткө айлантат",
      "Сохраняет в хранилище / Хранилищеге сактайт"
    ],
    "answer": "Преобразует объект в текст / Объектти текстке айлантат",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c0",
    "question": "В чём отличие цикла do...while? / do...while циклинин айырмасы?",
    "options": [
      "Никогда не выполняется / Эч качан иштебейт",
      "Выполняется минимум один раз без предварительной проверки условия / Шартты текшербей туруп жок дегенде бир жолу иштейт",
      "Всегда выполняется бесконечно / Ар дайым чексиз иштейт",
      "Останавливает цикл / Цикл токтотот"
    ],
    "answer": "Выполняется минимум один раз без предварительной проверки условия / Шартты текшербей туруп жок дегенде бир жолу иштейт",
    "category": "javascript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15c1",
    "question": "Что такое Slice? / Slice деген эмне?",
    "options": [
      "Компонент / Компонент",
      "Часть state с объединёнными reducers и actions / Stateтин кичинекей бөлүгү, reducers жана actions менен бириккен объект",
      "Middleware / Middleware",
      "AsyncThunk / AsyncThunk"
    ],
    "answer": "Часть state с объединёнными reducers и actions / Stateтин кичинекей бөлүгү, reducers жана actions менен бириккен объект",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ba",
    "question": "Как создаётся store в Redux/Toolkit? / Redux/Toolkitте store кантип түзүлөт?",
    "options": [
      "createStore(reducer) / createStore(reducer)",
      "configureStore({ reducer }) / configureStore({ reducer })",
      "new Store(reducer) / new Store(reducer)",
      "Redux.createStore(reducer) / Redux.createStore(reducer)"
    ],
    "answer": "configureStore({ reducer }) / configureStore({ reducer })",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b7",
    "question": "31. Что делает path()? / path() эмне кылат?",
    "options": [
      "Создаёт модель",
      "Настраивает URL",
      "Запускает сервер",
      "Делает миграцию"
    ],
    "answer": "Настраивает URL",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ae",
    "question": "30. Как создать бесконечный цикл? / Чексиз цикл кантип түзүлөт?",
    "options": [
      "for i in list",
      "while True:",
      "loop forever",
      "repeat"
    ],
    "answer": "while True:",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15ad",
    "question": "В каких случаях появляется тип never? / Кайсы учурда never чыгат?",
    "options": [
      "Если функция никогда не возвращает значение / Функция эч качан return кылбаса",
      "В функции с void / void функцияда",
      "При возвращении null / null кайтарганда",
      "При возвращении undefined / undefined кайтарганда"
    ],
    "answer": "Если функция никогда не возвращает значение / Функция эч качан return кылбаса",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b3",
    "question": "В чем основное отличие хуков useSelector и useDispatch в React? / Reactте useSelector жана useDispatch hookторунун негизги айырмасы эмнеде?",
    "options": [
      "useSelector читает state, useDispatch отправляет action / useSelector stateти окуйт, useDispatch action жиберет",
      "useSelector отправляет action, useDispatch читает state / useSelector action жиберет, useDispatch stateти окуйт",
      "Оба изменяют state / Экиси тең stateти өзгөртөт",
      "Оба получают reference на DOM / Экиси тең DOMго reference алат"
    ],
    "answer": "useSelector читает state, useDispatch отправляет action / useSelector stateти окуйт, useDispatch action жиберет",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b4",
    "question": "Что означает any? / any эмнени билдирет?",
    "options": [
      "Неопределённый тип, TypeScript не проверяет / Белгисиз тип, TypeScript текшербейт",
      "string / string",
      "number / number",
      "boolean / boolean"
    ],
    "answer": "Неопределённый тип, TypeScript не проверяет / Белгисиз тип, TypeScript текшербейт",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15b9",
    "question": "Какие виды циклов есть в JavaScript? / JavaScript’те цикл түрлөрү кайсылар?",
    "options": [
      "for, while, do…while / for, while, do…while",
      "if, else, switch / if, else, switch",
      "map, filter / map, filter",
      "let, var, const / let, var, const"
    ],
    "answer": "for, while, do…while / for, while, do…while",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15bd",
    "question": "32. Сколько строк может быть в lambda? / Lambdaда канча сап болот?",
    "options": [
      "Несколько",
      "Одна",
      "Две",
      "Любое"
    ],
    "answer": "Одна",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.171Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15aa",
    "question": "Кайсы тег таблица түзөт? / Какой тег создаёт таблицу?",
    "options": [
      "<table> / <table>",
      "<ul> / <ul>",
      "<input> / <input>",
      "<option> / <option>"
    ],
    "answer": "<table> / <table>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a9",
    "question": "29. Как войти в админку? / Админкага кантип киребиз?",
    "options": [
      "/login",
      "/admin",
      "/manage",
      "/panel"
    ],
    "answer": "/admin",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa159b",
    "question": "27. Команда создания суперпользователя? / Суперколдонуучу түзүү?",
    "options": [
      "makeadmin",
      "adduser",
      "createsuperuser",
      "superuser"
    ],
    "answer": "createsuperuser",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1593",
    "question": "26. Что такое аргумент? / Аргумент деген эмне?",
    "options": [
      "Значение при вызове функции",
      "Имя функции",
      "Метод",
      "Класс"
    ],
    "answer": "Значение при вызове функции",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a7",
    "question": "29. Как удалить ключ из словаря? / Dictтен ключту кантип өчүрөбүз?",
    "options": [
      "remove",
      "delete",
      "pop(key)",
      "clear"
    ],
    "answer": "pop(key)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a6",
    "question": "Что делает mapped type в TypeScript? / TS’те mapped type эмне кылат?",
    "options": [
      "Применяет изменения ко всем полям / Бардык field’дерге өзгөртүүлөр кылат",
      "Делает optional / Optional кылат",
      "Создаёт union / Union кылат",
      "Удаляет поля / Delete кылат"
    ],
    "answer": "Применяет изменения ко всем полям / Бардык field’дерге өзгөртүүлөр кылат",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a5",
    "question": "Какой пакет нужен для установки React Router в ViteReact? / ViteReact да React Router орнотуу үчүн кайсы пакет керек?",
    "options": [
      "react-router-dom / react-router-dom",
      "vite-router / vite-router",
      "router-react / router-react",
      "router / router"
    ],
    "answer": "react-router-dom / react-router-dom",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a1",
    "question": "**28. Что такое **kwargs? / kwargs деген эмне?",
    "options": [
      "list",
      "tuple",
      "dict",
      "set"
    ],
    "answer": "dict",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa158b",
    "question": "25. Как проверить тип переменной x? / x өзгөрмөсүнүн тибин кантип текшеребиз?",
    "options": [
      "typeof(x)",
      "check(x)",
      "type(x)",
      "isinstance"
    ],
    "answer": "type(x)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1590",
    "question": "Как в JSX пишется атрибут class? / JSXте class атрибуту кантип жазылат?",
    "options": [
      "class=\"my-class\" / class=\"my-class\"",
      "className=\"my-class\" / className=\"my-class\"",
      "className={my-class} / className={my-class}",
      "cls=\"my-class\" / cls=\"my-class\""
    ],
    "answer": "className=\"my-class\" / className=\"my-class\"",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa159c",
    "question": "CSS’те id кантип жазылат? / Как в CSS указывается id?",
    "options": [
      ".id / .id",
      "*id / *id",
      "#id / #id",
      ":id / :id"
    ],
    "answer": "#id / #id",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1598",
    "question": "В чём разница между null и undefined? / null менен undefined айырмасы?",
    "options": [
      "Разницы нет / Айырмасы жок",
      "null задаётся явно / null атайын берилет",
      "undefined — это number / undefined number",
      "null — это boolean / null boolean"
    ],
    "answer": "null задаётся явно / null атайын берилет",
    "category": "typescript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1599",
    "question": "27. Можно ли изменить кортеж? / Кортежди өзгөртсө болобу?",
    "options": [
      "Да",
      "Иногда",
      "Нет",
      "Только первый"
    ],
    "answer": "Нет",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa159a",
    "question": "**27. Что такое args? / args деген эмне?",
    "options": [
      "dict",
      "tuple",
      "list",
      "str"
    ],
    "answer": "tuple",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa158a",
    "question": "Одно из отличий type и interface? / type менен interface ортосундагы айырманын бири?",
    "options": [
      "Интерфейс merge боло алат / Interface merge боло алат",
      "Type колдонулбайт / Type колдонулбайт",
      "Интерфейс union түзбөйт / Interface union түзбөйт",
      "Type object жазбайт / Type object жазбайт"
    ],
    "answer": "Интерфейс merge боло алат / Interface merge боло алат",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa158f",
    "question": "Массив туура түзүлгөнүн танда? / Как правильно создать массив?",
    "options": [
      "let arr = (1, 2, 3); / let arr = (1, 2, 3);",
      "let arr = [1, 2, 3]; / let arr = [1, 2, 3];",
      "let arr = {1, 2, 3}; / let arr = {1, 2, 3};",
      "let arr = 1, 2, 3; / let arr = 1, 2, 3;"
    ],
    "answer": "let arr = [1, 2, 3]; / let arr = [1, 2, 3];",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1595",
    "question": "Padding эмне? / Что такое padding?",
    "options": [
      "Тышкы аралык / Внешний отступ",
      "Граница / Граница",
      "Ички аралык / Внутренний отступ",
      "Ссылка иштетуу / Ссылка"
    ],
    "answer": "Ички аралык / Внутренний отступ",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1596",
    "question": "NaN эмнени билдирет? / Что означает NaN?",
    "options": [
      "No available number / No available number",
      "Not a Number / Not a Number",
      "New and Null / New and Null",
      "Number Null NaN / Number Null NaN"
    ],
    "answer": "Not a Number / Not a Number",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1597",
    "question": "Как импортировать image файлы в проекте ViteReact? / ViteReact проектинде image файлдарын кантип импорттойт?",
    "options": [
      "import logo from './logo.png' / import logo from './logo.png'",
      "<img src=\"./logo.png\" /> / <img src=\"./logo.png\" />",
      "require('./logo.png') / require('./logo.png')",
      "load './logo.png' / load './logo.png'"
    ],
    "answer": "import logo from './logo.png' / import logo from './logo.png'",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa159d",
    "question": "8 != 8 результаты кандай болот? / Какой результат выражения 8 != 8?",
    "options": [
      "true / true",
      "false / false",
      "boolean / boolean",
      "null / null"
    ],
    "answer": "false / false",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1591",
    "question": "Как записывается optional property? / Optional property кандай жазылат?",
    "options": [
      "age: number? / age: number?",
      "age?: number / age?: number",
      "?age: number / ?age: number",
      "age = number? / age = number?"
    ],
    "answer": "age?: number / age?: number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa159e",
    "question": "Как импортировать CSS файл в ViteReact? / ViteReact да CSS файлын кантип импорттойбуз?",
    "options": [
      "import './style.css' / import './style.css'",
      "<link rel=\"stylesheet\" href=\"./style.css\" /> / <link rel=\"stylesheet\" href=\"./style.css\" />",
      "require('./style.css') / require('./style.css')",
      "load './style.css' / load './style.css'"
    ],
    "answer": "import './style.css' / import './style.css'",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a3",
    "question": "Фонго сүрөт коюу? / Как задать изображение фона?",
    "options": [
      "background-img / background-img",
      "bg-image / bg-image",
      "background-image / background-image",
      "img / img"
    ],
    "answer": "background-image / background-image",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a0",
    "question": "28. Как проверить наличие ключа в dict? / Dict ичинде ключ барбы текшерүү?",
    "options": [
      "has key",
      "key in dict",
      "dict.has()",
      "exist(key)"
    ],
    "answer": "key in dict",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a2",
    "question": "28. Что такое админка? / Django admin деген эмне?",
    "options": [
      "Терминал",
      "Панель управления",
      "БД",
      "API"
    ],
    "answer": "Панель управления",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a4",
    "question": "Массивди тескери кылуу үчүн кайсы метод колдонулат? / Какой метод используется для разворота массива?",
    "options": [
      "reverse() / reverse()",
      "sort() / sort()",
      "map() / map()",
      "push() / push()"
    ],
    "answer": "reverse() / reverse()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa15a8",
    "question": "29. Можно ли не указывать аргументы? / Аргумент бербесе болобу?",
    "options": [
      "Нет",
      "Да, если есть значение по умолчанию",
      "Только в цикле",
      "Только с lambda"
    ],
    "answer": "Да, если есть значение по умолчанию",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa158c",
    "question": "25. Что такое параметр функции? / Функция параметри деген эмне?",
    "options": [
      "Модуль",
      "Входное значение",
      "Класс",
      "Команда"
    ],
    "answer": "Входное значение",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa158d",
    "question": "25. Что такое миграции? / Миграциялар деген эмне?",
    "options": [
      "HTML файлы",
      "Изменения БД",
      "Статика",
      "URL"
    ],
    "answer": "Изменения БД",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa158e",
    "question": "Текстти жоон (bold) кылуу? / Как сделать текст жирным (bold)?",
    "options": [
      "font-weight / font-weight",
      "font-bold / font-bold",
      "font-size / font-size",
      "font-family / font-family"
    ],
    "answer": "font-weight / font-weight",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa159f",
    "question": "let x = 10; x = \"hello\";",
    "options": [
      "Да / Ооба",
      "В TypeScript выдаст ошибку / TypeScriptте ката чыгат",
      "Ошибка во время выполнения / Runtime error",
      "boolean / boolean"
    ],
    "answer": "В TypeScript выдаст ошибку / TypeScriptте ката чыгат",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1592",
    "question": "26. Как создать кортеж из чисел? / Сандардан турган кортеж?",
    "options": [
      "[1,2,3]",
      "{1,2,3}",
      "(1,2,3)",
      "<1,2,3>"
    ],
    "answer": "(1,2,3)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1594",
    "question": "26. Для чего admin.py? / admin.py эмне үчүн керек?",
    "options": [
      "Для шаблонов",
      "Для регистрации моделей",
      "Для URL",
      "Для сервера"
    ],
    "answer": "Для регистрации моделей",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.170Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1588",
    "question": "Тернардык оператордун туура жазылышын танда? / Как правильно записывается тернарный оператор?",
    "options": [
      "let result = (a > b) ? a : b / let result = (a > b) ? a : b",
      "let result = (a > b) if a else b / let result = (a > b) if a else b",
      "let result = a ? b : c : d / let result = a ? b : c : d",
      "let result = a : b : c : d / let result = a : b : c : d"
    ],
    "answer": "let result = (a > b) ? a : b / let result = (a > b) ? a : b",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa157f",
    "question": "23. Команда создания миграций? / Миграция түзүү?",
    "options": [
      "migrate",
      "makemigrations",
      "syncdb",
      "createdb"
    ],
    "answer": "makemigrations",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1582",
    "question": "Как использовать хук useState в React компоненте? / React компонентинде useState hook кантип колдонулат?",
    "options": [
      "const [state, setState] = useState(initialValue) / const [state, setState] = useState(initialValue)",
      "let state = useState(initialValue) / let state = useState(initialValue)",
      "state = useState(initialValue) / state = useState(initialValue)",
      "useState(state, setState) / useState(state, setState)"
    ],
    "answer": "const [state, setState] = useState(initialValue) / const [state, setState] = useState(initialValue)",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1583",
    "question": "Что такое TypeScript? / TypeScript деген эмне?",
    "options": [
      "Язык для backend / Backend тили",
      "Расширение JavaScript с типами / JavaScript’ке кошумча типтер",
      "Браузер / Браузер",
      "Фреймворк / Фреймворк"
    ],
    "answer": "Расширение JavaScript с типами / JavaScript’ке кошумча типтер",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1584",
    "question": "24. Что вернёт функция без return? / return жок функция эмне кайтарат?",
    "options": [
      "0",
      "False",
      "None",
      "\"\""
    ],
    "answer": "None",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1580",
    "question": "Жаңы сапка түшүрүүчү тег? / Какой тег переносит текст на новую строку?",
    "options": [
      "<br> / <br>",
      "<p> / <p>",
      "<hr> / <hr>",
      "<h1> / <h1>"
    ],
    "answer": "<br> / <br>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1589",
    "question": "Какая команда используется для запуска Vite dev сервера? / Vite dev серверин баштоо үчүн кайсы команда колдонулат?",
    "options": [
      "npm run build / npm run build",
      "npm run dev / npm run dev",
      "npm server / npm server",
      "vite start / vite start"
    ],
    "answer": "npm run dev / npm run dev",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1586",
    "question": "24. Где хранится БД по умолчанию? / Демейки БД кайда?",
    "options": [
      "db.sql",
      "database.py",
      "db.sqlite3",
      "base.db"
    ],
    "answer": "db.sqlite3",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1585",
    "question": "24. Функция может вернуть несколько значений? / Функция бир нече маанини кайтара алабы?",
    "options": [
      "Нет",
      "Да, через tuple",
      "Только list",
      "Только dict"
    ],
    "answer": "Да, через tuple",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1581",
    "question": "JS’те typeof null эмне чыгарат? / Что выдаёт typeof null в JavaScript?",
    "options": [
      "null / null",
      "object / object",
      "undefined / undefined",
      "string / string"
    ],
    "answer": "object / object",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1587",
    "question": "Кайсы CSS синтаксиси туура? / Какой синтаксис CSS правильный?",
    "options": [
      "color = red; / color = red;",
      "color: red; / color: red;",
      "color -> red; / color -> red;",
      "color: { red } / color: { red }"
    ],
    "answer": "color: red; / color: red;",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.169Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1568",
    "question": "20. Как остановить выполнение цикла полностью? / Циклди толук токтотуу?",
    "options": [
      "stop",
      "end",
      "break",
      "exit"
    ],
    "answer": "break",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1575",
    "question": "Чем TypeScript отличается от JavaScript? / TypeScript JavaScriptтен эмнеси менен айырмаланат?",
    "options": [
      "Работает быстрее / Ылдамыраак иштейт",
      "Проверяет типы / Типтерди текшерет",
      "Не работает в браузере / Браузерде иштебейт",
      "Требует HTML / HTML талап кылат"
    ],
    "answer": "Проверяет типы / Типтерди текшерет",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa156e",
    "question": "Чтобы код TypeScript работал в браузере, что нужно? / TypeScript код браузерде иштеши үчүн эмне керек?",
    "options": [
      "Открыть напрямую / Түз ачуу",
      "Только Node.js / Node.js гана",
      "Компиляция в JavaScript / JavaScriptке компиляция",
      "React / React"
    ],
    "answer": "Компиляция в JavaScript / JavaScriptке компиляция",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa156d",
    "question": "Какой тип файлов чаще всего используется в React? / React кайсы файл түрүн көп колдонот?",
    "options": [
      ".exe / .exe",
      ".tsx & .jsx / .tsx & .jsx",
      ".css / .css",
      ".mp4 / .mp4"
    ],
    "answer": ".tsx & .jsx / .tsx & .jsx",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa156b",
    "question": "Блок элемент кайсы? / Какой элемент является блочным?",
    "options": [
      "<div> / <div>",
      "<span> / <span>",
      "<meta> / <meta>",
      "<href> / <href>"
    ],
    "answer": "<div> / <div>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa155b",
    "question": "18. Как вызвать метод объекта? / Объекттин методун кантип чакырабыз?",
    "options": [
      "obj-method",
      "obj.method()",
      "method(obj)",
      "obj[method]"
    ],
    "answer": "obj.method()",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1558",
    "question": "Какие компоненты есть в React? / Reactте кандай компоненттер бар?",
    "options": [
      "Файловые и папочные компоненты / Файл жана папка компоненттери",
      "Функциональные и классовые компоненты / Функциялык жана класстык компоненттер",
      "BIOS компоненты / BIOS компоненттери",
      "HTML компоненты / HTML компоненттер"
    ],
    "answer": "Функциональные и классовые компоненты / Функциялык жана класстык компоненттер",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1557",
    "question": "Функция маани кайтарбаса кандай результат берет? / Что возвращает функция, если не указано return?",
    "options": [
      "undefined / undefined",
      "return / return",
      "null / null",
      "error / ошибка"
    ],
    "answer": "undefined / undefined",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1552",
    "question": "Для чего используется union type? / Union type эмне үчүн колдонулат?",
    "options": [
      "Для ускорения выполнения кода / Кодду тез иштетиш үчүн",
      "Чтобы переменная могла иметь несколько типов / Өзгөрмө бир нече типте болушу үчүн",
      "Чтобы вызвать ошибку / Ката чыгарыш үчүн",
      "Для работы с HTML / HTML менен иштөө үчүн"
    ],
    "answer": "Чтобы переменная могла иметь несколько типов / Өзгөрмө бир нече типте болушу үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1550",
    "question": "Кайсы маалымат туру примитивдуу эмес? / Какой тип данных не является примитивным?",
    "options": [
      "object / object",
      "number / number",
      "null / null",
      "bigInt / bigInt"
    ],
    "answer": "object / object",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa154f",
    "question": "Атрибут деген эмне? / Что такое атрибут?",
    "options": [
      "Тегге кошумча маани берет / Атрибут дает дополнительное значение тегу",
      "Атрибут бул одинарный тег / Атрибут — это одинарный тег",
      "Текстин размерин чонойтот / Увеличивает размер текста",
      "Шилтеме иштетет / Активирует ссылку"
    ],
    "answer": "Тегге кошумча маани берет / Атрибут дает дополнительное значение тегу",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1545",
    "question": "15. Какой результат 7 % 2? / 7 % 2 натыйжасы кандай?",
    "options": [
      "0",
      "1",
      "2",
      "3"
    ],
    "answer": "1",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa157d",
    "question": "23. Как вернуть значение из функции? / Функциядан маани кайтаруу?",
    "options": [
      "back",
      "send",
      "return",
      "print"
    ],
    "answer": "return",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1551",
    "question": "Что такое JSX? / JSX деген эмне?",
    "options": [
      "Синтаксис CSS / CSS синтаксиси",
      "Синтаксис, в котором смешаны HTML и JavaScript / HTML менен JavaScript аралаш жазылуучу синтаксис",
      "Язык SQL / SQL тили",
      "Компонент / Компонент"
    ],
    "answer": "Синтаксис, в котором смешаны HTML и JavaScript / HTML менен JavaScript аралаш жазылуучу синтаксис",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1553",
    "question": "17. Какой оператор больше или равно? / Чоң же барабар оператору кайсы?",
    "options": [
      "=>",
      ">=",
      "=>=",
      ">>"
    ],
    "answer": ">=",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa155a",
    "question": "18. Как написать цикл с 3 повторениями? / 3 жолу кайталануучу цикл?",
    "options": [
      "for i in range(3):",
      "loop 3",
      "while 3",
      "repeat(3"
    ],
    "answer": "for i in range(3):",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa155c",
    "question": "18. Где хранятся HTML-шаблоны? / HTML шаблондор кайда сакталат?",
    "options": [
      "static",
      "templates",
      "media",
      "views"
    ],
    "answer": "templates",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa155e",
    "question": "console.log(2 \"2\") результат кандай чыгат? / Какой результат будет у console.log(2 \"2\")?",
    "options": [
      "NaN / NaN",
      "22 / 22",
      "4 / 4",
      "string / string"
    ],
    "answer": "22 / 22",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1564",
    "question": "Тексти ортого жылдыруу? / Как выровнять текст по центру?",
    "options": [
      "text-center / text-center",
      "text-align: center / text-align: center",
      "align: center / align: center",
      "margin: auto / margin: auto"
    ],
    "answer": "text-align: center / text-align: center",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa156a",
    "question": "20. Для чего models.py? / models.py эмне үчүн керек?",
    "options": [
      "Для URL",
      "Для БД моделей",
      "Для шаблонов",
      "Для статики"
    ],
    "answer": "Для БД моделей",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1570",
    "question": "21. Как объявить функцию? / Функцияны кантип жазабыз?",
    "options": [
      "function f()",
      "def f():",
      "func f",
      "create f"
    ],
    "answer": "def f():",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1571",
    "question": "21. Что такое модель? / Модель деген эмне?",
    "options": [
      "HTML файл",
      "Таблица БД",
      "View",
      "URL"
    ],
    "answer": "Таблица БД",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1576",
    "question": "22. Как передать аргумент в функцию? / Функцияга аргумент кантип беребиз?",
    "options": [
      "func = x",
      "func(x)",
      "func[x]",
      "func<x>"
    ],
    "answer": "func(x)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1578",
    "question": "22. Как применить изменения моделей? / Модель өзгөртүүлөрүн кантип колдонобуз?",
    "options": [
      "runserver",
      "migrate",
      "install",
      "sync"
    ],
    "answer": "migrate",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1548",
    "question": "CSS созунун расшифровкасы кандай? / Что расшифровывается как CSS?",
    "options": [
      "Cascading Style Sheets / Cascading Style Sheets",
      "Cascading Size Shorts / Cascading Size Shorts",
      "Cascading Sheets / Cascading Sheets",
      "Style / Style"
    ],
    "answer": "Cascading Style Sheets / Cascading Style Sheets",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1563",
    "question": "19. Какой шаблонизатор используется в Django? / Django шаблондору?",
    "options": [
      "Blade",
      "Twig",
      "Django Template Language",
      "Jinja"
    ],
    "answer": "Django Template Language",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1549",
    "question": "Программалоо тили кайсыл? / Какой язык является языком программирования?",
    "options": [
      "HTML / HTML",
      "CSS / CSS",
      "JAVASCRIPT / JAVASCRIPT",
      "REACT / REACT"
    ],
    "answer": "JAVASCRIPT / JAVASCRIPT",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1547",
    "question": "15. Как вернуть текст из view? / Viewден текст кайтаруу?",
    "options": [
      "return text",
      "print()",
      "HttpResponse(\"Hi\")",
      "render()"
    ],
    "answer": "HttpResponse(\"Hi\")",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1546",
    "question": "15. Приватный атрибут начинается с… / Приват атрибут эмне менен башталат?",
    "options": [
      "#",
      "__",
      "@",
      "$"
    ],
    "answer": "__",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa154b",
    "question": "Какова основная цель TypeScript? / TypeScript негизги максаты эмне?",
    "options": [
      "Замедлить выполнение JavaScript / JavaScriptти жай иштетүү",
      "Сделать код безопасным с помощью типов / Кодду типтер менен коопсуз кылуу",
      "Писать HTML / HTML жазуу",
      "Заменить CSS / CSSти алмаштыруу"
    ],
    "answer": "Сделать код безопасным с помощью типов / Кодду типтер менен коопсуз кылуу",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa154c",
    "question": "16. Как создать условие else? / else шартын кантип жазабыз?",
    "options": [
      "if x > 5",
      "else x > 5",
      "else:",
      "elif x"
    ],
    "answer": "else:",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1555",
    "question": "17. Что делает render()? / render() эмне кылат?",
    "options": [
      "Создаёт модель",
      "Показывает HTML",
      "Запускает сервер",
      "Делает миграции"
    ],
    "answer": "Показывает HTML",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1559",
    "question": "Какой тип boolean? / Кайсы тип boolean?",
    "options": [
      "\"true\" / \"true\"",
      "1 / 1",
      "true / true",
      "\"false\" / \"false\""
    ],
    "answer": "true / true",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa155f",
    "question": "Как вывести компонент на экран? / Компонентти кантип экранга чыгарабыз?",
    "options": [
      "Через alert() / alert() менен",
      "Через render() или return с возвратом JSX / render() же return аркылуу JSX кайтаруу менен",
      "Через console.log / console.log менен",
      "Через App.jsx / App.jsx менен"
    ],
    "answer": "Через render() или return с возвратом JSX / render() же return аркылуу JSX кайтаруу менен",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1561",
    "question": "19. Что делает continue? / continue эмне кылат?",
    "options": [
      "Останавливает цикл",
      "Выходит из программы",
      "Пропускает итерацию",
      "Завершает функцию"
    ],
    "answer": "Пропускает итерацию",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa154a",
    "question": "Что такое React? / React деген эмне?",
    "options": [
      "JavaScript библиотека для создания фронтенд UI / Frontend UI түзүү үчүн JavaScript китепкана",
      "База данных / Маалымат базасы",
      "Язык программирования / Программалоо тили",
      "Элемент DOM / DOM элемент"
    ],
    "answer": "JavaScript библиотека для создания фронтенд UI / Frontend UI түзүү үчүн JavaScript китепкана",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1567",
    "question": "Какой вариант правильного типа массива в TypeScript? / Кайсысы туура массив типи?",
    "options": [
      "let arr: number = [] / let arr: number = []",
      "let arr: number[] = [1,2,3] / let arr: number[] = [1,2,3]",
      "let arr: array<number> / let arr: array<number>",
      "let arr = number[] / let arr = number[]"
    ],
    "answer": "let arr: number[] = [1,2,3] / let arr: number[] = [1,2,3]",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa156c",
    "question": "Маалымат страница обновления болгондо деле очуп кетпеш үчүн эмне колдонулат? / Что используется, чтобы данные не пропадали при обновлении страницы?",
    "options": [
      "spread оператор / оператор spread",
      "localStorage / localStorage",
      "append / append",
      "const / const"
    ],
    "answer": "localStorage / localStorage",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa156f",
    "question": "21. Как создать функцию без параметров? / Параметрсиз функция кантип түзүлөт?",
    "options": [
      "def func[]",
      "function func()",
      "def func():",
      "func =>"
    ],
    "answer": "def func():",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1572",
    "question": "Margin эмне? / Что такое margin?",
    "options": [
      "Ички аралык / Внутренний отступ",
      "Тышкы аралык / Внешний отступ",
      "Арткы фон / Фон",
      "Граница / Граница"
    ],
    "answer": "Тышкы аралык / Внешний отступ",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1574",
    "question": "Основное применение useEffect? / useEffectтин негизги колдонулушу?",
    "options": [
      "Асинхронные действия, например вызов API / Асинхрон иш-аракеттер, мисалы API чакыруу",
      "Загрузка файлов / Файл жүктөө",
      "Нагрузка на сервер / Сервер кубаттоо",
      "Добавление CSS / css кошуу"
    ],
    "answer": "Асинхронные действия, например вызов API / Асинхрон иш-аракеттер, мисалы API чакыруу",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1577",
    "question": "22. Можно ли передавать функцию как аргумент? / Функцияны аргумент катары берсе болобу?",
    "options": [
      "Нет",
      "Да",
      "Только lambda",
      "Только встроенные"
    ],
    "answer": "Да",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa157e",
    "question": "23. Что делает return? / return эмне кылат?",
    "options": [
      "Печатает",
      "Возвращает значение",
      "Удаляет переменную",
      "Завершает программу"
    ],
    "answer": "Возвращает значение",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa157c",
    "question": "В каких случаях используется readonly? / Кайсы учурда readonly колдонулат?",
    "options": [
      "Для удаления значения / Маанини өчүрүүдө",
      "Чтобы значение не изменялось / Маанини өзгөртпөш үчүн",
      "Для изменения типа / Типти алмаштыруу үчүн",
      "Для остановки функции / Function токтотуу үчүн"
    ],
    "answer": "Чтобы значение не изменялось / Маанини өзгөртпөш үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1569",
    "question": "20. Что возвращает метод str? / str методу эмне кайтарат?",
    "options": [
      "Число",
      "Список",
      "Строку",
      "Класс"
    ],
    "answer": "Строку",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa157b",
    "question": "Что такое Axios? / Axios деген эмне?",
    "options": [
      "Компонент React / React компонент",
      "Библиотека для отправки HTTP-запросов / HTTP сурамдарын жөнөтүүчү китепкана",
      "База данных / Маалымат базасы",
      "Название компонента / Компонент аты"
    ],
    "answer": "Библиотека для отправки HTTP-запросов / HTTP сурамдарын жөнөтүүчү китепкана",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa157a",
    "question": "Кайсы команда менен жаны веткага өтөт? / Какая команда используется для перехода на другую ветку?",
    "options": [
      "git add / git add",
      "git checkout [name branch] / git checkout [name branch]",
      "git push / git push",
      "git init / git init"
    ],
    "answer": "git checkout [name branch] / git checkout [name branch]",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1579",
    "question": "Баракчада көрүнгөн контент кайсы тегде болот? / В каком теге находится видимое содержимое страницы?",
    "options": [
      "<head> / <head>",
      "<body> / <body>",
      "<meta> / <meta>",
      "<link> / <link>"
    ],
    "answer": "<body> / <body>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1573",
    "question": "Сап турундогу маалыматтарды кантип санга айландырат? / Как преобразовать строку в число?",
    "options": [
      "String() / String()",
      "Number() / Number()",
      "Boolean() / Boolean()",
      "Infinity() / Infinity()"
    ],
    "answer": "Number() / Number()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa154d",
    "question": "16. Что такое полиморфизм? / Полиморфизм деген эмне?",
    "options": [
      "Один класс",
      "Разные файлы",
      "Один метод — разное поведение",
      "Ошибка"
    ],
    "answer": "Один метод — разное поведение",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1566",
    "question": "Как в React вызвать функцию при нажатии кнопки? / Reactте кнопканы басканда функцияны кантип чакырабыз?",
    "options": [
      "onclick=\"function()\" / onclick=\"function( )\"",
      "onClick={ function } / onClick={ function }",
      "click() / click()",
      "event() / event()"
    ],
    "answer": "onClick={ function } / onClick={ function }",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1565",
    "question": "Логический тип? / Какой тип данных логический?",
    "options": [
      "boolean / boolean",
      "string / string",
      "number / number",
      "null / null"
    ],
    "answer": "boolean / boolean",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1562",
    "question": "19. Можно ли переопределить метод? / Методту өзгөртсө болобу?",
    "options": [
      "Нет",
      "Да",
      "Только в Django",
      "Только private"
    ],
    "answer": "Да",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1560",
    "question": "Для чего используется interface? / interface эмне үчүн колдонулат?",
    "options": [
      "Для выполнения функции / Функция иштетүү үчүн",
      "Для описания типа / Типти сүрөттөө үчүн",
      "Для создания цикла / Цикл түзүү үчүн",
      "Для вызова API / API чакыруу үчүн"
    ],
    "answer": "Для описания типа / Типти сүрөттөө үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa155d",
    "question": "Баракчанын атын (title) кайсы тегде жазабыз? / В каком теге указывается название страницы (title)?",
    "options": [
      "<body> / <body>",
      "<title> / <title>",
      "<meta> / <meta>",
      "<link> / <link>"
    ],
    "answer": "<title> / <title>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1554",
    "question": "17. Что такое метод? / Метод деген эмне?",
    "options": [
      "Переменная",
      "Функция внутри класса",
      "Файл",
      "Модуль"
    ],
    "answer": "Функция внутри класса",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa154e",
    "question": "16. Где пишется логика сайта? / Сайт логикасы кайда жазылат?",
    "options": [
      "templates",
      "views.py",
      "static",
      "admin.py"
    ],
    "answer": "views.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.080Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1533",
    "question": "Что лучше для масштабирования проекта? / Проекти масштабдоо үчүн эмнени колдонуу жакшыраак?",
    "options": [
      "Минимум типов / Минимум типтер",
      "Типизированная архитектура / Типтештирилген архитектура",
      "JS без TS / JS гана, TS жок",
      "Один файл / Бир файл"
    ],
    "answer": "Типизированная архитектура / Типтештирилген архитектура",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa153c",
    "question": "13. Что делает super()? / super() эмне кылат?",
    "options": [
      "Создаёт объект",
      "Вызывает родительский класс",
      "Удаляет атрибут",
      "Останавливает код"
    ],
    "answer": "Вызывает родительский класс",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1530",
    "question": "Как скрыть элемент полностью (без места)? / Элементти толугу менен жашыруу (орун калтырбай) үчүн кайсы касиет колдонулат?",
    "options": [
      "visibility: hidden",
      "opacity: 0",
      "display: none",
      "z-index: -1"
    ],
    "answer": "display: none",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1532",
    "question": "Что улучшает производительность React? / React’тин ылдамдыгын эмнелер жакшыртат?",
    "options": [
      "Большие компоненты / Чоң компоненттер",
      "Мемоизация и разделение компонентов / Мемоизация жана компоненттерди бөлүү",
      "Inline функции / Inline функциялар",
      "Частые setState / Көп setState колдонуу"
    ],
    "answer": "Мемоизация и разделение компонентов / Мемоизация жана компоненттерди бөлүү",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1534",
    "question": "12. Как получить все ключи словаря? / Dict ичиндеги бардык ключтарды кантип алабыз?",
    "options": [
      "dict.values()",
      "dict.items()",
      "dict.keys()",
      "dict.all()"
    ],
    "answer": "dict.keys()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1535",
    "question": "12. Как объявить наследование? / Мурас алуучу класс кантип жазылат?",
    "options": [
      "class B <- A",
      "class B(A):",
      "class B = A",
      "inherit B A"
    ],
    "answer": "class B(A):",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa153d",
    "question": "13. Где описываются URL? / URL маршруттар кайда жазылат?",
    "options": [
      "views.py",
      "urls.py",
      "settings.py",
      "admin.py"
    ],
    "answer": "urls.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1542",
    "question": "14. Как проверить равенство? / Теңдикти кантип текшеребиз?",
    "options": [
      "=",
      ":=",
      "==",
      "==="
    ],
    "answer": "==",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1544",
    "question": "14. Что такое view? / View деген эмне?",
    "options": [
      "HTML файл",
      "Функция обработки запроса",
      "Статика",
      "Модель"
    ],
    "answer": "Функция обработки запроса",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1537",
    "question": "Как выровнять текст по центру? / Текстти борборго кантип тууралайбыз?",
    "options": [
      "align: center",
      "text-align: center",
      "center-text: true",
      "font-align: center"
    ],
    "answer": "text-align: center",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa153a",
    "question": "Что показывает хороший уровень junior TS? / Junior TypeScript үчүн жакшы деңгээлди эмнелер көрсөтөт?",
    "options": [
      "Знание синтаксиса / Синтаксис билүү",
      "Умение типизировать state, props, API / State, props жана API’ни типтештире билүү",
      "Использование any / Any колдонуу",
      "Знание CSS / CSS билүү"
    ],
    "answer": "Умение типизировать state, props, API / State, props жана API’ни типтештире билүү",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa153b",
    "question": "13. Какой оператор используется для деления? / Бөлүү үчүн кайсы оператор колдонулат?",
    "options": [
      "*",
      "//",
      "/",
      "%"
    ],
    "answer": "/",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa153f",
    "question": "Что важнее для будущего JS? / JSтин келечеги үчүн эмнеге көңүл буруу керек?",
    "options": [
      "jQuery / jQuery",
      "ES6 и async / ES6 жана async",
      "Понимание основ и event loop / Негиздерди жана event loopту түшүнүү",
      "Магия / Сыйкыр"
    ],
    "answer": "Понимание основ и event loop / Негиздерди жана event loopту түшүнүү",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1540",
    "question": "Что важнее всего для React-разработчика? / React разработчик үчүн эң маанилүүсү эмнеде?",
    "options": [
      "Знать все хуки / Бардык хуктарды билүү",
      "Понимать state, props и архитектуру / State, props жана архитектураны түшүнүү",
      "Знать CSS / CSS билүү",
      "Использовать Redux везде / Бардык жерде Redux колдонуу"
    ],
    "answer": "Понимать state, props и архитектуру / State, props жана архитектураны түшүнүү",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1541",
    "question": "Зачем TypeScript в React? / React’те TypeScript эмне үчүн керек?",
    "options": [
      "Для скорости / Ылдамдык үчүн",
      "Для автокомплита и безопасности типов / Автокомплит жана типтердин коопсуздугу үчүн",
      "Для SSR / SSR үчүн",
      "Для Redux / Redux үчүн"
    ],
    "answer": "Для автокомплита и безопасности типов / Автокомплит жана типтердин коопсуздугу үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1531",
    "question": "Что такое side effect? / Side effect деген эмне?",
    "options": [
      "Ошибка / Ката",
      "Изменение внешнего состояния / Сырттагы абалды өзгөртүү",
      "Promise / Promise",
      "Callback / Callback"
    ],
    "answer": "Изменение внешнего состояния / Сырттагы абалды өзгөртүү",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1536",
    "question": "12. Для чего settings.py? / settings.py эмне үчүн керек?",
    "options": [
      "Для HTML",
      "Для логики",
      "Для настроек проекта",
      "Для моделей"
    ],
    "answer": "Для настроек проекта",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1543",
    "question": "14. Что такое инкапсуляция? / Инкапсуляция деген эмне?",
    "options": [
      "Разделение файлов",
      "Сокрытие деталей",
      "Импорт",
      "Ошибка"
    ],
    "answer": "Сокрытие деталей",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1538",
    "question": "Что делает use strict? / use strict эмне кылат?",
    "options": [
      "Ускоряет JS / JS ылдамдайт",
      "Включает строгий режим / Катуу режимди иштетет",
      "Убирает ошибки / Каталарды өчүрөт",
      "Делает код async / Кодду async кылат"
    ],
    "answer": "Включает строгий режим / Катуу режимди иштетет",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1539",
    "question": "Много маленьких компонентов или один большой? / Көп кичинекей компоненттерби же бир чоң компонентпи?",
    "options": [
      "Один большой / Бир чоң",
      "Много маленьких / Көп кичинекей",
      "Без разницы / Айырмасы жок",
      "Только class / Фактан class"
    ],
    "answer": "Много маленьких / Көп кичинекей",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa153e",
    "question": "Какое значение display делает элементы в строку? / Элементтерди бир сапка жайгаштыруу үчүн кайсы display мааниси колдонулат?",
    "options": [
      "block",
      "inline",
      "flex",
      "grid"
    ],
    "answer": "inline",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.079Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1500",
    "question": "Что такое замыкание (closure)? / Closure деген эмне?",
    "options": [
      "Ошибка памяти / Эстутук катасы",
      "Доступ к внешней области видимости / Сырткы көрүү чөйрөсүнө жетүү",
      "Класс / Класс",
      "Promise / Promise"
    ],
    "answer": "Доступ к внешней области видимости / Сырткы көрүү чөйрөсүнө жетүү",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1519",
    "question": "8. Какой метод вызывается при создании объекта? / Объект түзүлгөндө кайсы метод иштейт?",
    "options": [
      "start",
      "create",
      "init",
      "main"
    ],
    "answer": "init",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1521",
    "question": "9. Что такое приложение (app)? / Django app деген эмне?",
    "options": [
      "Проект",
      "Независимая часть проекта",
      "Сервер",
      "БД"
    ],
    "answer": "Независимая часть проекта",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1503",
    "question": "5. Как объявить переменную name? / name өзгөрмөсүн кантип жарыялайбыз?",
    "options": [
      "var name",
      "name == \"Ali\"",
      "name = \"Ali\"",
      "string name"
    ],
    "answer": "name = \"Ali\"",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1506",
    "question": "Какой тег используется для группировки контента без логического смысла?",
    "options": [
      "<section>",
      "<article>",
      "<div>",
      "<main>"
    ],
    "answer": "<div>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1508",
    "question": "Как отправить action? / Action’ти кантип жиберебиз?",
    "options": [
      "dispatch(action) / dispatch(action)",
      "send(action) / send(action)",
      "emit(action) / emit(action)",
      "call(action) / call(action)"
    ],
    "answer": "dispatch(action) / dispatch(action)",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1509",
    "question": "Зачем нужен AppDispatch? / AppDispatch эмне үчүн керек?",
    "options": [
      "Для CSS / CSS үчүн",
      "Для типизированного dispatch / Типтештирилген dispatch үчүн",
      "Для reducer / Reducer үчүн",
      "Для API / API үчүн"
    ],
    "answer": "Для типизированного dispatch / Типтештирилген dispatch үчүн",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa150c",
    "question": "6. Как называется главный файл управления проектом? / Негизги башкаруу файлы кайсы?",
    "options": [
      "settings.py",
      "urls.py",
      "manage.py",
      "views.py"
    ],
    "answer": "manage.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1512",
    "question": "7. Как объявить метод? / Метод кантип жарыяланат?",
    "options": [
      "def method():",
      "def method(self):",
      "func method",
      "method =>"
    ],
    "answer": "def method(self):",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1515",
    "question": "Что такое prototype? / Prototype деген эмне?",
    "options": [
      "Копия объекта / Объекттин көчүрмөсү",
      "Механизм наследования / Мураскерлик механизми",
      "Тип данных / Маанинин типи",
      "Метод массива / Массив методу"
    ],
    "answer": "Механизм наследования / Мураскерлик механизми",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1501",
    "question": "Как получить данные из Redux store? / Redux store’дон маалыматты кантип алууга болот?",
    "options": [
      "useState / useState",
      "useSelector / useSelector",
      "useEffect / useEffect",
      "getStore / getStore"
    ],
    "answer": "useSelector / useSelector",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa151d",
    "question": "Для чего используется redux-thunk? / Redux-thunk эмнеге колдонулат?",
    "options": [
      "Для CSS / CSS үчүн",
      "Для асинхронных actions / Асинхрондук action’дер үчүн",
      "Для роутинга / Роутинг үчүн",
      "Для memo / Memo үчүн"
    ],
    "answer": "Для асинхронных actions / Асинхрондук action’дер үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa152d",
    "question": "11. Как создать пустой словарь? / Бош dict кантип түзүлөт?",
    "options": [
      "[]",
      "()",
      "{}",
      "<>"
    ],
    "answer": "{}",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa152c",
    "question": "Что НЕ рекомендуется в TS? / TypeScript’те эмнени колдонбоо сунушталат?",
    "options": [
      "strict mode / strict режим",
      "generics / generics",
      "частое использование any / Any’ни көп колдонуу",
      "union types / union типтери"
    ],
    "answer": "частое использование any / Any’ни көп колдонуу",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa152b",
    "question": "Что такое presentational component? / Presentational component деген эмне?",
    "options": [
      "Работает с API / API менен иштейт",
      "Отвечает только за UI / Фактан UI үчүн жооп берет",
      "Использует Redux / Redux колдонуу",
      "Хранит state / State сактайт"
    ],
    "answer": "Отвечает только за UI / Фактан UI үчүн жооп берет",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1527",
    "question": "10. Как создать пустой класс? / Бош класс кантип түзүлөт?",
    "options": [
      "class A(): stop",
      "class A(): None",
      "class A(): pass",
      "class A(): exit"
    ],
    "answer": "class A(): pass",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1525",
    "question": "Что делает код более поддерживаемым? / Кодду колдоого ылайыктуу кылган эмнелер?",
    "options": [
      "any / any",
      "Явные типы и интерфейсы / Ачык типтер жана интерфейстер",
      "console.log / console.log",
      "var / var"
    ],
    "answer": "Явные типы и интерфейсы / Ачык типтер жана интерфейстер",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1520",
    "question": "9. Можно ли создать класс без методов? / Методсуз класс түзсө болобу?",
    "options": [
      "Нет",
      "Да",
      "Только с init",
      "Только в Django"
    ],
    "answer": "Да",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f9",
    "question": "Как правильно ловить ошибку в async/await? / async/await менен катаны кантип туура кармайбыз?",
    "options": [
      ".catch() / .catch()",
      "try / catch / try / catch",
      "if error / if error",
      "throw() / throw()"
    ],
    "answer": "try / catch / try / catch",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14fc",
    "question": "4. Как вывести число 10 в консоль? / Консолго 10 санын кантип чыгаруу керек?",
    "options": [
      "echo 10",
      "print(10)",
      "show(10)",
      "console(10)"
    ],
    "answer": "print(10)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14fd",
    "question": "4. Как создать объект класса User? / User классынын объектин кантип түзөбүз?",
    "options": [
      "User[]",
      "new User",
      "User()",
      "create User"
    ],
    "answer": "User()",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ff",
    "question": "Какой тег используется для выделения важного текста курсивом (семантически)? / Маңызды текстти курсив менен көрсөтүүчү семантикалык тег кайсы?",
    "options": [
      "<i>",
      "<em>",
      "<italic>",
      "<mark>"
    ],
    "answer": "<em>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa152e",
    "question": "11. Что такое наследование? / Мурас алуу деген эмне?",
    "options": [
      "Копирование файлов",
      "Передача свойств от родителя",
      "Удаление классов",
      "Импорт модуля"
    ],
    "answer": "Передача свойств от родителя",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1505",
    "question": "5. Что создаёт django-admin startproject? / startproject эмне түзөт?",
    "options": [
      "Приложение",
      "Проект",
      "Модель",
      "БД"
    ],
    "answer": "Проект",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa150b",
    "question": "6. Для чего нужен self? / self эмне үчүн керек?",
    "options": [
      "Для импорта",
      "Для ссылки на объект",
      "Для цикла",
      "Для return"
    ],
    "answer": "Для ссылки на объект",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa150e",
    "question": "Что делает Object.freeze()? / Object.freeze() эмне кылат?",
    "options": [
      "Клонирует объект / Объектти көчүрөт",
      "Делает неизменяемым / Өзгөртүүгө мүмкүн болбос кылат",
      "Удаляет свойства / Касиеттерди өчүрөт",
      "Блокирует prototype / Прототипти блоктойт"
    ],
    "answer": "Делает неизменяемым / Өзгөртүүгө мүмкүн болбос кылат",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa150f",
    "question": "Где подключается Provider? / Provider кайда кошулат?",
    "options": [
      "В каждом компоненте / Ар бир компонентте",
      "В корне приложения / Колдонмонун түпүндө",
      "В reducer / Reducer’де",
      "В store / Store’до"
    ],
    "answer": "В корне приложения / Колдонмонун түпүндө",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1510",
    "question": "Что возвращает useSelector с типами? / useSelector типтер менен эмне кайтарат?",
    "options": [
      "any / any",
      "RootState часть / RootState бөлүгү",
      "Promise / Promise",
      "Dispatch / Dispatch"
    ],
    "answer": "RootState часть / RootState бөлүгү",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1513",
    "question": "7. Команда запуска сервера? / Серверди иштетүү буйругу?",
    "options": [
      "django start",
      "python server.py",
      "python manage.py runserver",
      "django run"
    ],
    "answer": "python manage.py runserver",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1517",
    "question": "Как типизировать thunk? / Thunk’ту кантип типтештиребиз?",
    "options": [
      "any / any",
      "createAsyncThunk с generic / createAsyncThunk’ту generic менен",
      "useEffect / useEffect",
      "middleware / middleware"
    ],
    "answer": "createAsyncThunk с generic / createAsyncThunk’ту generic менен",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa151a",
    "question": "8. Какой порт по умолчанию? / Демейки порт кайсы?",
    "options": [
      "3000",
      "5000",
      "8000",
      "8080"
    ],
    "answer": "8000",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1522",
    "question": "Какое свойство отвечает за внешний отступ? / Сырткы аралыкты (margin) кайсы касиет берет?",
    "options": [
      "padding",
      "border",
      "margin",
      "gap"
    ],
    "answer": "margin",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1523",
    "question": "Что делает ?? (nullish coalescing)? / ?? (nullish coalescing) эмне кылат?",
    "options": [
      "Проверяет false / false текшерет",
      "Проверяет null и undefined / null жана undefined текшерет",
      "Проверяет 0 / 0 текшерет",
      "Проверяет NaN / NaN текшерет"
    ],
    "answer": "Проверяет null и undefined / null жана undefined текшерет",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1526",
    "question": "10. Как добавить элемент в начало списка? / Тизмени башына элемент кошуу?",
    "options": [
      "add()",
      "insert(0, x)",
      "append()",
      "push()"
    ],
    "answer": "insert(0, x)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1504",
    "question": "5. Что такое атрибут класса? / Класстын атрибуту деген эмне?",
    "options": [
      "Метод",
      "Переменная объекта",
      "Файл",
      "Комментарий"
    ],
    "answer": "Переменная объекта",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f8",
    "question": "Что такое адаптивная верстка? / Адаптивдүү верстка деген эмне?",
    "options": [
      "Один размер экрана",
      "Верстка только под телефон",
      "Подстраивается под разные экраны",
      "Использует только flex"
    ],
    "answer": "Подстраивается под разные экраны",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14fa",
    "question": "Зачем используют Redux Toolkit? / Redux Toolkit эмнеге колдонулат?",
    "options": [
      "Для верстки / Верстка үчүн",
      "Чтобы писать меньше сложного кода Redux / Redux коду аз жана жөнөкөй жазуу үчүн",
      "Для CSS / CSS үчүн",
      "Для маршрутов (Router) / Маршрутизация (Router) үчүн"
    ],
    "answer": "Чтобы писать меньше сложного кода Redux / Redux коду аз жана жөнөкөй жазуу үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1502",
    "question": "Где лучше типизировать state? / State’ти кайда типтештирүү жакшыраак?",
    "options": [
      "В компоненте / Компонентте",
      "В slice/state interface / Slice же state интерфейсинде",
      "В JSX / JSX ичинде",
      "В useEffect / useEffect ичинде"
    ],
    "answer": "В slice/state interface / Slice же state интерфейсинде",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1511",
    "question": "7. Как создать список из строк? / Саптардан турган тизме кантип түзүлөт?",
    "options": [
      "(\"a\", \"b\")",
      "{\"a\", \"b\"}",
      "[\"a\", \"b\"]",
      "<\"a\",\"b\">"
    ],
    "answer": "[\"a\", \"b\"]",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1516",
    "question": "Что такое middleware? / Middleware деген эмне?",
    "options": [
      "UI слой / UI катмар",
      "Прослойка для логики (async, логирование) / Логика үчүн катмар (async, логирлөө)",
      "Reducer / Reducer",
      "Component / Компонент"
    ],
    "answer": "Прослойка для логики (async, логирование) / Логика үчүн катмар (async, логирлөө)",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1518",
    "question": "8. Как получить последний элемент списка a? / a тизмесинин акыркы элементин кантип алабыз?",
    "options": [
      "a.last()",
      "a[-1]",
      "a[len]",
      "a(end)"
    ],
    "answer": "a[-1]",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa151b",
    "question": "Как сделать комментарий в HTML? / HTMLде комментарий кантип жазылат?",
    "options": [
      "// comment",
      "/* comment */",
      "<!-- comment -->",
      "# comment"
    ],
    "answer": "<!-- comment -->",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa151c",
    "question": "Как проверить, что переменная — это массив? / Переменная массив экенин кантип текшеребиз?",
    "options": [
      "typeof arr / typeof arr",
      "arr instanceof Array / arr instanceof Array",
      "Array.isArray(arr) / Array.isArray(arr)",
      "isArray(arr) / isArray(arr)"
    ],
    "answer": "Array.isArray(arr) / Array.isArray(arr)",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa152f",
    "question": "11. Где регистрируется приложение? / App кайда катталат?",
    "options": [
      "urls.py",
      "admin.py",
      "settings.py → INSTALLED_APPS",
      "views.py"
    ],
    "answer": "settings.py → INSTALLED_APPS",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1529",
    "question": "Как изменить шрифт текста? / Тексттин шрифтин кантип өзгөртсөк болот?",
    "options": [
      "text-style",
      "font-family",
      "font-text",
      "font-change"
    ],
    "answer": "font-family",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14fb",
    "question": "Что лучше для enum в React? / React’те enum үчүн эмнени колдонуу жакшыраак?",
    "options": [
      "number enum / number enum",
      "string enum / string enum",
      "any / any",
      "const enum всегда / const enum ар дайым"
    ],
    "answer": "string enum / string enum",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14fe",
    "question": "4. Как проверить версию Django? / Django версиясын кантип текшеребиз?",
    "options": [
      "django check",
      "django version",
      "django-admin --version",
      "python django"
    ],
    "answer": "django-admin --version",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1507",
    "question": "Какая переменная выйдет за пределы блока {}? / Блоктон тышка кайсы переменная чыгат?",
    "options": [
      "let / let",
      "const / const",
      "var / var",
      "Все / Бардыгы"
    ],
    "answer": "var / var",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa150a",
    "question": "6. Какой тип данных у [ ]? / [ ] кайсы типке кирет?",
    "options": [
      "tuple",
      "dict",
      "list",
      "set"
    ],
    "answer": "list",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa150d",
    "question": "Какой атрибут у <a> задаёт адрес ссылки? / <a> тегинде шилтеменин дарегин кайсы атрибут көрсөтөт?",
    "options": [
      "src",
      "link",
      "href",
      "path"
    ],
    "answer": "href",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1514",
    "question": "Какой HTML-тег используется для кнопки? / Кнопка үчүн кайсы HTML тег колдонулат?",
    "options": [
      "<input>",
      "<btn>",
      "<button>",
      "<click>"
    ],
    "answer": "<button>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa151e",
    "question": "Что лучше использовать для async в Redux Toolkit? / Redux Toolkit’те async үчүн эмнени колдонуу жакшыраак?",
    "options": [
      "useEffect / useEffect",
      "thunk вручную / Кол менен thunk",
      "createAsyncThunk / createAsyncThunk",
      "saga / saga"
    ],
    "answer": "createAsyncThunk / createAsyncThunk",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa151f",
    "question": "9. Как узнать количество элементов? / Элементтердин санын кантип билебиз?",
    "options": [
      "count()",
      "size()",
      "len()",
      "length"
    ],
    "answer": "len()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1524",
    "question": "Почему несколько setState подряд могут не изменить значение сразу? / Неге бир нече setState чын эле дароо маанини өзгөртпөйт?",
    "options": [
      "Ошибка синтаксиса / Синтаксистик ката",
      "Асинхронно / Асинхрондуу",
      "Только числа / Фактан сандар",
      "Нужно var / Var колдонуу керек"
    ],
    "answer": "Асинхронно / Асинхрондуу",
    "category": "react",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1528",
    "question": "10. Команда создания приложения? / App түзүү буйругу?",
    "options": [
      "django new app",
      "python manage.py startapp blog",
      "django create",
      "start app"
    ],
    "answer": "python manage.py startapp blog",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa152a",
    "question": "x = \"\". Что вернёт? x || \"def\" и x ?? \"def\" / x = \"\". x || \"def\" жана x ?? \"def\" эмне кайтарат?",
    "options": [
      "\"def\" и \"def\" / \"def\" жана \"def\"",
      "\"def\" и \"\" / \"def\" жана \"\"",
      "\"\" и \"def\" / \"\" жана \"def\"",
      "\"\" и \"\" / \"\" жана \"\""
    ],
    "answer": "\"def\" и \"\" / \"def\" жана \"\"",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.078Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e8",
    "question": "1. Что такое класс в Python? / Python'догу класс деген эмне?",
    "options": [
      "Переменная",
      "Шаблон для объектов",
      "Цикл",
      "Модуль"
    ],
    "answer": "Шаблон для объектов",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e9",
    "question": "1. Что такое Django? / Django деген эмне?",
    "options": [
      "Язык программирования",
      "Фреймворк для веб-разработки",
      "База данных",
      "Операционная система"
    ],
    "answer": "Фреймворк для веб-разработки",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ed",
    "question": "Как типизировать обработчик кнопки? / Түймөнү иштетүүчү функцияны кантип типтештиребиз?",
    "options": [
      "Event / Event",
      "MouseEvent / MouseEvent",
      "React.MouseEvent<HTMLButtonElement> / React.MouseEvent<HTMLButtonElement>",
      "ClickEvent / ClickEvent"
    ],
    "answer": "React.MouseEvent<HTMLButtonElement> / React.MouseEvent<HTMLButtonElement>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ef",
    "question": "2. Как создать класс? / Классты кантип түзөбүз?",
    "options": [
      "create MyClass",
      "class MyClass:",
      "new MyClass",
      "def MyClass"
    ],
    "answer": "class MyClass:",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14db",
    "question": "Как выбрать все элементы на странице? / Барактагы бардык элементтерди кантип тандайбыз?",
    "options": [
      "#all",
      ".",
      "*",
      "html"
    ],
    "answer": "*",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ec",
    "question": "Что делает reducer? / Reducer эмнени аткарат?",
    "options": [
      "Делает запрос / Суроо жиберет",
      "Изменяет state на основе action / Action негизинде state’ти өзгөртөт",
      "Рендерит UI / UI’ди чыгарат",
      "Хранит данные / Маалыматты сактайт"
    ],
    "answer": "Изменяет state на основе action / Action негизинде state’ти өзгөртөт",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14eb",
    "question": "Что делает finally()? / finally() эмне кылат?",
    "options": [
      "Ловит ошибку / Ката кармайт",
      "Выполняется всегда / Ар дайым иштейт",
      "Только при успехе / Жеңиш учурда гана",
      "Останавливает Promise / Promise токтотот"
    ],
    "answer": "Выполняется всегда / Ар дайым иштейт",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e4",
    "question": "Что выполнится быстрее? / Эмне тезирээк аткарылат?",
    "options": [
      "setTimeout(fn, 0) / setTimeout(fn, 0)",
      "Promise.then() / Promise.then()",
      "fetch() / fetch()",
      "setInterval() / setInterval()"
    ],
    "answer": "Promise.then() / Promise.then()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f3",
    "question": "Можно ли мутировать state в reducer? / Reducer ичинде state’ти өзгөртүүгө болобу?",
    "options": [
      "Да / Ооба",
      "Нет / Жок",
      "Иногда / Кээде",
      "Только в Redux Toolkit / Фактан Redux Toolkit’те гана"
    ],
    "answer": "Нет / Жок",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f1",
    "question": "Какое свойство отвечает за тень? / Элементке көлөкөнү кайсы касиет берет?",
    "options": [
      "shadow",
      "box-shadow",
      "text-shadow",
      "depth"
    ],
    "answer": "box-shadow",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d9",
    "question": "45. Для чего нужен requirements.txt? / requirements.txt эмне үчүн керек?",
    "options": [
      "Для HTML / HTML үчүн",
      "Для статики / Статика үчүн",
      "Для списка библиотек проекта / Долбоор китепканаларын сактоо үчүн",
      "Для Git / Git үчүн"
    ],
    "answer": "Для списка библиотек проекта / Долбоор китепканаларын сактоо үчүн",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f5",
    "question": "3. Какой тип данных у значения True? / True маанисинин тиби кайсы?",
    "options": [
      "int",
      "str",
      "bool",
      "float"
    ],
    "answer": "bool",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14cd",
    "question": "Как скрыть элемент, но оставить место в layout? / Элементти жашырып, бирок орун калтыруу үчүн кайсы касиет колдонулат?",
    "options": [
      "display: none",
      "opacity: 0",
      "visibility: hidden",
      "z-index: -1"
    ],
    "answer": "visibility: hidden",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ca",
    "question": "43. Как удалить элемент? / Элементти кантип өчүрүү керек?",
    "options": [
      "remove() / remove()",
      "delete() / delete()",
      "pop() / pop()",
      "A и C / A жана C"
    ],
    "answer": "A и C / A жана C",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c6",
    "question": "<span> тегине бийиктик берүү мүмкүнбү? / Можно ли задать высоту для тега <span>?",
    "options": [
      "Да, height работает всегда / Ооба, height ар дайым иштейт",
      "Да, если использовать px / Ооба, px менен",
      "Нет, потому что <span> — строчный элемент / Жок, анткени <span> — inline элемент",
      "Да, если указать % / Ооба, % менен"
    ],
    "answer": "Нет, потому что <span> — строчный элемент / Жок, анткени <span> — inline элемент",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c0",
    "question": "Как проверить, есть ли ключ в объекте? / Объектте ачкыч бар экенин кантип текшеребиз?",
    "options": [
      "obj.has(key) / obj.has(key)",
      "key in obj / key in obj",
      "obj[key] !== null / obj[key] !== null",
      "obj.includes(key) / obj.includes(key)"
    ],
    "answer": "key in obj / key in obj",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b6",
    "question": "40. Где хранятся сторонние библиотеки? / Боштон тышкары китепканалар кайда турат?",
    "options": [
      "В templates / templates ичинде",
      "В site-packages / site-packages ичинде",
      "В static / static ичинде",
      "В GitHub / GitHub'да"
    ],
    "answer": "В site-packages / site-packages ичинде",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14bb",
    "question": "Какой тип у null в строгом режиме? / Катуу режимде null’дун типи кандай?",
    "options": [
      "null / null",
      "any / any",
      "null | undefined / null | undefined",
      "отдельный null тип / Өзүнчө null тип"
    ],
    "answer": "отдельный null тип / Өзүнчө null тип",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d6",
    "question": "Что такое Redux? / Redux деген эмне?",
    "options": [
      "UI библиотека / UI китепканасы",
      "Глобальное хранилище состояния / Глобалдык стейт сактоочу",
      "Router / Маршрутизатор",
      "HTTP клиент / HTTP кардар"
    ],
    "answer": "Глобальное хранилище состояния / Глобалдык стейт сактоочу",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d5",
    "question": "Что вернёт функция без return? / return жок функция эмне кайтарат?",
    "options": [
      "null / null",
      "false / false",
      "0 / 0",
      "undefined / undefined"
    ],
    "answer": "undefined / undefined",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d4",
    "question": "Какое свойство меняет размер шрифта? / Шрифттин өлчөмүн өзгөртүүчү касиет кайсы?",
    "options": [
      "font-weight",
      "text-size",
      "font-size",
      "size"
    ],
    "answer": "font-size",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b7",
    "question": "40. Клиент-серверная архитектура? / Клиент-сервер архитектурасы?",
    "options": [
      "Два сервера / Эки сервер",
      "Сервер отправляет запросы / Сервер сурайт",
      "Клиент отправляет, сервер жооп берет / Клиент сурайт, сервер жооп берет",
      "Без запросов / Суранычсыз"
    ],
    "answer": "Клиент отправляет, сервер жооп берет / Клиент сурайт, сервер жооп берет",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14bd",
    "question": "41. Можно ли создать свой модуль? / Өз модулубузду түзө алабызбы?",
    "options": [
      "Нет / Жок",
      "Да, любой .py файл / Ооба, ар кандай .py файл",
      "Только через pip / pip менен гана",
      "Только через класс / класс менен гана"
    ],
    "answer": "Да, любой .py файл / Ооба, ар кандай .py файл",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14be",
    "question": "41. Что такое REST API? / REST API деген эмне?",
    "options": [
      "HTML / HTML",
      "Интерфейс обмена данными через HTTP / HTTP аркылуу маалымат алмашуу интерфейси",
      "SQL-запрос / SQL сураныч",
      "Статика / Статика"
    ],
    "answer": "Интерфейс обмена данными через HTTP / HTTP аркылуу маалымат алмашуу интерфейси",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14bf",
    "question": "Как задать цвет текста? / Тексттин түсүн кантип өзгөртүүгө болот?",
    "options": [
      "background-color",
      "font-color",
      "color",
      "text-color"
    ],
    "answer": "color",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c2",
    "question": "Как типизировать возвращаемое значение функции? / Функциянын кайтарган маанисин кантип типтештиребиз?",
    "options": [
      "После имени / Атынан кийин",
      "После аргументов через : / Аргументтерден кийин : аркылуу",
      "Через return / return аркылуу",
      "Нельзя / Болбойт"
    ],
    "answer": "После аргументов через : / Аргументтерден кийин : аркылуу",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c7",
    "question": "Что делает Object.keys(obj)? / Object.keys(obj) эмне кылат?",
    "options": [
      "значения / маанилер",
      "пары / жуптар",
      "массив ключей / ачкычтар массиви",
      "объект / объект"
    ],
    "answer": "массив ключей / ачкычтар массиви",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c8",
    "question": "Что такое lifting state up? / Lifting state up деген эмне?",
    "options": [
      "Удаление state / State өчүрүү",
      "Перенос state в родителя / State’ти ата-энеге өткөрүү",
      "Использование Redux / Redux колдонуу",
      "useEffect / useEffect колдонуу"
    ],
    "answer": "Перенос state в родителя / State’ти ата-энеге өткөрүү",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14cc",
    "question": "43. Где регистрировать DRF? / DRF кайда катталат?",
    "options": [
      "admin.py / admin.py",
      "views.py / views.py",
      "settings.py → INSTALLED_APPS / settings.py → INSTALLED_APPS",
      "urls.py / urls.py"
    ],
    "answer": "settings.py → INSTALLED_APPS / settings.py → INSTALLED_APPS",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14cf",
    "question": "Что лучше передавать в props? / Props аркылуу эмнени берүү жакшыраак?",
    "options": [
      "Логику / Логиканы",
      "UI / UI элементтерин",
      "Минимально необходимые данные / Азыркы учурда эң керектүү маалымат",
      "Всё подряд / Баарын кезексиз"
    ],
    "answer": "Минимально необходимые данные / Азыркы учурда эң керектүү маалымат",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b8",
    "question": "Какой тег связывает текст с input? / Текстти input менен байланыштыруу үчүн кайсы тег колдонулат?",
    "options": [
      "<span>",
      "<p>",
      "<label>",
      "<legend>"
    ],
    "answer": "<label>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e5",
    "question": "Что такое action? / Action деген эмне?",
    "options": [
      "Функция / Функция",
      "Объект с type и payload / Type жана payload бар объект",
      "Компонент / Компонент",
      "Хук / Хук"
    ],
    "answer": "Объект с type и payload / Type жана payload бар объект",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c1",
    "question": "Что такое controlled component? / Controlled component деген эмне?",
    "options": [
      "Компонент без state / State жок компонент",
      "Форма, управляемая через state / State аркылуу башкарылган форма",
      "Redux компонент / Redux компонент",
      "Компонент без props / Props жок компонент"
    ],
    "answer": "Форма, управляемая через state / State аркылуу башкарылган форма",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c3",
    "question": "42. Пустой словарь? / Бош dict кантип түзүлөт?",
    "options": [
      "{} / {}",
      "[] / []",
      "() / ()",
      "dict[] / dict[]"
    ],
    "answer": "{} / {}",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c4",
    "question": "42. Что такое пакет? / Пакет деген эмне?",
    "options": [
      "Папка с модулями init.py / Модулдар салынган папка init.py",
      "ZIP архив / ZIP архив",
      "Фото / Сүрөт",
      "Коммит / Коммит"
    ],
    "answer": "Папка с модулями init.py / Модулдар салынган папка init.py",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14cb",
    "question": "43. Как посмотреть установленные пакеты? / Орнотулган китепканаларды кантип көрөбүз?",
    "options": [
      "pip showall / pip showall",
      "pip check / pip check",
      "pip list / pip list",
      "pip load / pip load"
    ],
    "answer": "pip list / pip list",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ce",
    "question": "Как удалить свойство объекта? / Объекттин касиетин кантип өчүрөбүз?",
    "options": [
      "remove obj.key / remove obj.key",
      "delete obj.key / delete obj.key",
      "obj.key = null / obj.key = null",
      "clear obj.key / clear obj.key"
    ],
    "answer": "delete obj.key / delete obj.key",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d0",
    "question": "Что лучше использовать вместо any? / Any ордуна эмнени колдонуу жакшыраак?",
    "options": [
      "var / var",
      "unknown / unknown",
      "null / null",
      "never / never"
    ],
    "answer": "unknown / unknown",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d1",
    "question": "43. Как удалить элемент? / Элементти кантип өчүрүү керек?",
    "options": [
      "remove() / remove()",
      "delete() / delete()",
      "pop() / pop()",
      "A и C / A жана C"
    ],
    "answer": "A и C / A жана C",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d2",
    "question": "44. Что делает pip uninstall? / pip uninstall эмне кылат?",
    "options": [
      "Обновляет / Жаңыртат",
      "Показывает версии / Версияларды көрсөтөт",
      "Удаляет пакет / Пакетти өчүрөт",
      "Устанавливает пакет / Орнотот"
    ],
    "answer": "Удаляет пакет / Пакетти өчүрөт",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14bc",
    "question": "41. Пустой список? / Бош тизме кантип түзүлөт?",
    "options": [
      "{} / {}",
      "() / ()",
      "[] / []",
      "<> / <>"
    ],
    "answer": "[] / []",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14da",
    "question": "45. Что делает ViewSet? / ViewSet эмне кылат?",
    "options": [
      "Запускает сервер / Серверди иштетет",
      "Создаёт модели / Модель түзөт",
      "Обрабатывает CRUD-операции / CRUD операцияларын аткарат",
      "Подключает Bootstrap / Bootstrap кошот"
    ],
    "answer": "Обрабатывает CRUD-операции / CRUD операцияларын аткарат",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14dc",
    "question": "Что такое callback? / Callback деген эмне?",
    "options": [
      "Асинхронная ошибка / Асинхрондук ката",
      "Функция как аргумент / Функция аргумент катары берилет",
      "Promise / Promise",
      "Метод массива / Массив методу"
    ],
    "answer": "Функция как аргумент / Функция аргумент катары берилет",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14dd",
    "question": "Из каких частей состоит Redux? / Redux кайсы бөлүктөрдөн турат?",
    "options": [
      "store, reducer, action / store, reducer, action",
      "state, props, hooks / state, props, hooks",
      "component, page / компонент, бет",
      "effect, memo / effect, memo"
    ],
    "answer": "store, reducer, action / store, reducer, action",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e2",
    "question": "Почему React.FC не всегда рекомендуют? / Эмнеге React.FC’ни ар дайым сунушташпайт?",
    "options": [
      "Он устарел / Эскирген",
      "Принудительно добавляет children / Мандаттуу түрдө children кошот",
      "Не работает с хуками / Хуктар менен иштебейт",
      "Не типизируется / Типтештирилбейт"
    ],
    "answer": "Принудительно добавляет children / Мандаттуу түрдө children кошот",
    "category": "typescript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14de",
    "question": "Как правильно типизировать props без React.FC? / React.FC колдонбостон props’ту кантип туура типтештиребиз?",
    "options": [
      "any / any",
      "через interface/type в аргументе / Аргументте interface/type аркылуу",
      "через JSX / JSX аркылуу",
      "нельзя / Болбойт"
    ],
    "answer": "через interface/type в аргументе / Аргументте interface/type аркылуу",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f0",
    "question": "2. На каком языке написан Django? / Django кайсы тилде жазылган?",
    "options": [
      "Java",
      "C",
      "Python",
      "PHP"
    ],
    "answer": "Python",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f7",
    "question": "3. Команда установки Django? / Django орнотуу буйругу кайсы?",
    "options": [
      "install django",
      "pip django",
      "pip install django",
      "django install"
    ],
    "answer": "pip install django",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f2",
    "question": "Что вернёт async-функция? / async-функция эмне кайтарат?",
    "options": [
      "значение / маанини",
      "object / объект",
      "Promise / Promise",
      "undefined / undefined"
    ],
    "answer": "Promise / Promise",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e7",
    "question": "1. Для чего используется Python? / Python эмне үчүн колдонулат?",
    "options": [
      "Только для игр / Оюндар үчүн гана",
      "Для веб, ИИ, автоматизации / Веб, ИИ, автоматташтыруу үчүн",
      "Только для дизайна / Дизайн үчүн",
      "Для ОС / ОС үчүн"
    ],
    "answer": "Для веб, ИИ, автоматизации / Веб, ИИ, автоматташтыруу үчүн",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e6",
    "question": "Как типизировать children? / Children’ди кантип типтештиребиз?",
    "options": [
      "string / string",
      "JSX / JSX",
      "React.ReactNode / React.ReactNode",
      "HTMLElement / HTMLElement"
    ],
    "answer": "React.ReactNode / React.ReactNode",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e3",
    "question": "Какой media query используется для адаптива? / Адаптив үчүн кайсы media query колдонулат?",
    "options": [
      "@screen",
      "@media",
      "@responsive",
      "@mobile"
    ],
    "answer": "@media",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e1",
    "question": "Что такое store? / Store деген эмне?",
    "options": [
      "Компонент / Компонент",
      "Хранилище состояния приложения / Колдонмо стейтин сактоочу",
      "Reducer / Reducer",
      "Middleware / Middleware"
    ],
    "answer": "Хранилище состояния приложения / Колдонмо стейтин сактоочу",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14df",
    "question": "Как задать расстояние между flex-элементами? / Flex элементтеринин ортосундагы аралыкты кантип көрсөтөбүз?",
    "options": [
      "margin",
      "gap",
      "padding",
      "space"
    ],
    "answer": "gap",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ea",
    "question": "Как сделать элемент круглым? / Элементти тегиз тегерек кылуу үчүн кандай касиет колдонулат?",
    "options": [
      "border: round",
      "radius: 50%",
      "border-radius: 50%",
      "shape: circle"
    ],
    "answer": "border-radius: 50%",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f4",
    "question": "Какой тип у setState функции? / setState функциясынын типи кандай?",
    "options": [
      "void / void",
      "Dispatch<SetStateAction<T>> / Dispatch<SetStateAction<T>>",
      "Function / Function",
      "StateUpdater / StateUpdater"
    ],
    "answer": "Dispatch<SetStateAction<T>> / Dispatch<SetStateAction<T>>",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14f6",
    "question": "3. Что такое объект? / Объект деген эмне?",
    "options": [
      "Модуль",
      "Экземпляр класса",
      "Функция",
      "Переменная"
    ],
    "answer": "Экземпляр класса",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d7",
    "question": "Когда используется never? / Never качан колдонулат?",
    "options": [
      "Функция всегда возвращает значение / Функция дайыма маанини кайтарат",
      "Функция никогда не завершается / Функция эч качан бүтпөйт",
      "Тип массива / Массив типи",
      "Тип ошибки / Ката типи"
    ],
    "answer": "Функция никогда не завершается / Функция эч качан бүтпөйт",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d3",
    "question": "44. Что такое сериализатор? / Сериализатор деген эмне?",
    "options": [
      "HTML-файл / HTML файл",
      "Python → JSON конвертер / Python → JSON конвертор",
      "Модель / Модель",
      "SQL-запрос / SQL сураныч"
    ],
    "answer": "Python → JSON конвертер / Python → JSON конвертор",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c9",
    "question": "Что такое overload функций? / Функциялардын overload деген эмне?",
    "options": [
      "Ошибка / Ката",
      "Несколько сигнатур одной функции / Бир функциянын бир нече сигнатурасы",
      "Generic / Generic",
      "Promise / Promise"
    ],
    "answer": "Несколько сигнатур одной функции / Бир функциянын бир нече сигнатурасы",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14c5",
    "question": "42. Как установить DRF? / DRF кантип орнотуу керек?",
    "options": [
      "pip install drf / pip install drf",
      "pip install django-rest / django-rest",
      "pip install djangorestframework / djangorestframework",
      "pip install rest / pip install rest"
    ],
    "answer": "pip install djangorestframework / djangorestframework",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ba",
    "question": "Для чего нужен useCallback? / useCallback эмне үчүн керек?",
    "options": [
      "Кэш JSX / JSX кэштейт",
      "Кэш функции / Функцияны кэштейт",
      "Асинхронность / Асинхрондук иштейт",
      "Работа с DOM / DOM менен иштейт"
    ],
    "answer": "Кэш функции / Функцияны кэштейт",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b9",
    "question": "Что возвращает every()? / every() эмне кайтарат?",
    "options": [
      "массив / массив",
      "число / сан",
      "boolean / boolean",
      "объект / объект"
    ],
    "answer": "boolean / boolean",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14e0",
    "question": "Чем стрелочная функция отличается? / Жебелүү функциянын айырмасы эмнеде?",
    "options": [
      "Нет аргументов / Аргументтери жок",
      "Нет this / this жок",
      "Не может вернуть значение / Маанини кайтара албайт",
      "Всегда async / Ар дайым async"
    ],
    "answer": "Нет this / this жок",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b5",
    "question": "40. len(\"Python\") = ? / len(\"Python\") натыйжасы?",
    "options": [
      "5 / 5",
      "6 / 6",
      "7 / 7",
      "8 / 8"
    ],
    "answer": "6 / 6",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ee",
    "question": "2. Какой символ используется для комментария? / Комментарий үчүн кайсы символ колдонулат?",
    "options": [
      "//",
      "<!-- -->",
      "#",
      "**"
    ],
    "answer": "#",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14d8",
    "question": "45. Какой файл запускается? / Кайсы файл Python менен иштейт?",
    "options": [
      ".java / .java",
      ".exe / .exe",
      ".py / .py",
      ".html / .html"
    ],
    "answer": ".py / .py",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.077Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b0",
    "question": "39. Для чего Django? / Django эмне үчүн керек?",
    "options": [
      "Игровые движки / Оюн кыймылдаткычтары",
      "Веб-приложения / Веб-тиркемелер",
      "Работа с изображениями / Сүрөт иштетүү",
      "Оборудование / Жабдуу"
    ],
    "answer": "Веб-приложения / Веб-тиркемелер",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa148e",
    "question": "Какой тег является строчным (inline)? / Кайсы тег саптык (inline) элемент?",
    "options": [
      "<div>",
      "<section>",
      "<span>",
      "<article>"
    ],
    "answer": "<span>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa148f",
    "question": "Как проверить, что переменная НЕ число? / Переменная сан эместигин кантип текшеребиз?",
    "options": [
      "x === NaN / x === NaN",
      "x == NaN / x == NaN",
      "isNaN(x) / isNaN(x)",
      "typeof x === NaN / typeof x === NaN"
    ],
    "answer": "isNaN(x) / isNaN(x)",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1495",
    "question": "Ссылка жаңы вкладкада ачылышы үчүн кайсы target мааниси колдонулат? / Какое значение атрибута target открывает ссылку в новой вкладке?",
    "options": [
      "href=\"_blank\" / href=\"_blank\"",
      "target=\"_new\" / target=\"_new\"",
      "target=\"_blank\" / target=\"_blank\"",
      "open=\"new\" / open=\"new\""
    ],
    "answer": "target=\"_blank\" / target=\"_blank\"",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1496",
    "question": "Что вернёт [] == false? / [] == false эмне кайтарат?",
    "options": [
      "true / true",
      "false / false",
      "error / каталык",
      "undefined / белгисиз"
    ],
    "answer": "true / true",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1499",
    "question": "36. Для чего input()? / input() эмне үчүн керек?",
    "options": [
      "Для вывода текста / Текст чыгаруу үчүн",
      "Для чтения данных / Колдонуучудан маалымат алуу үчүн",
      "Для файлов / Файлдар үчүн",
      "Для переменных / Өзгөрмөлөр үчүн"
    ],
    "answer": "Для чтения данных / Колдонуучудан маалымат алуу үчүн",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b4",
    "question": "Что означает readonly? / Readonly эмнени билдирет?",
    "options": [
      "Свойство нельзя читать / Property’ни окууга болбойт",
      "Свойство нельзя менять / Property’ни өзгөртүүгө болбойт",
      "Только для классов / Фактан класстар үчүн",
      "Только для массивов / Фактан массивдер үчүн"
    ],
    "answer": "Свойство нельзя менять / Property’ни өзгөртүүгө болбойт",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a4",
    "question": "Как получить последний элемент массива arr? / Массивдин акыркы элементин кантип алабыз?",
    "options": [
      "arr.last() / arr.last()",
      "arr[arr.length - 1] / arr[arr.length - 1]",
      "arr[-1] / arr[-1]",
      "arr.getLast() / arr.getLast()"
    ],
    "answer": "arr[arr.length - 1] / arr[arr.length - 1]",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a7",
    "question": "38. Что делает pass? / pass эмне кылат?",
    "options": [
      "Останавливает / Токтотот",
      "Пропускает код / Кодду өткөрөт",
      "Ничего не делает / Эч нерсе кылбайт",
      "Чыгат / Чыгат"
    ],
    "answer": "Ничего не делает / Эч нерсе кылбайт",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b2",
    "question": "Что вернёт find() если ничего не найдено? / find() эч нерсе таппаса эмне кайтарат?",
    "options": [
      "null / null",
      "false / false",
      "undefined / undefined",
      "-1 / -1"
    ],
    "answer": "undefined / undefined",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b1",
    "question": "Какой атрибут обязателен у input для отправки данных? / input үчүн кайсы атрибут маалымат жөнөтүүдө милдеттүү?",
    "options": [
      "id",
      "class",
      "name",
      "placeholder"
    ],
    "answer": "name",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14aa",
    "question": "Какой тег используется для формы? / Форманы көрсөтүү үчүн кайсы тег колдонулат?",
    "options": [
      "<input>",
      "<form>",
      "<fieldset>",
      "<label>"
    ],
    "answer": "<form>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a8",
    "question": "38. Что такое модуль в Python? / Python модулу деген эмне?",
    "options": [
      "HTML-файл / HTML-файл",
      ".py файл с кодом / Код жазылган .py файл",
      "Фото / Сүрөт",
      "Таблица / Таблица"
    ],
    "answer": ".py файл с кодом / Код жазылган .py файл",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a0",
    "question": "37. Как обработать ошибку? / Катаны кантип иштетүү керек?",
    "options": [
      "try/except / try/except",
      "if/else / if/else",
      "error/handle / error/handle",
      "check / check"
    ],
    "answer": "try/except / try/except",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a9",
    "question": "38. Что такое фреймворк? / Фреймворк деген эмне?",
    "options": [
      "Готовая программа / Даяр программа",
      "Структура для разработки / Өнүктүрүүнү тездеткен структура",
      "БД / БД",
      "ОС / ОС"
    ],
    "answer": "Структура для разработки / Өнүктүрүүнү тездеткен структура",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ac",
    "question": "Где нельзя вызывать хуки? / Хуктарды кайсы жерде чакыра албайбыз?",
    "options": [
      "В компоненте / Компонентте",
      "В кастомном хуке / Кастом хукта",
      "В обычной функции / Адаттагы функцияда",
      "В React / React ичинде"
    ],
    "answer": "В обычной функции / Адаттагы функцияда",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1489",
    "question": "Какой хук используется для хранения состояния? / Абалды сактоо үчүн кайсы хук колдонулат?",
    "options": [
      "useEffect / useEffect",
      "useState / useState",
      "useMemo / useMemo",
      "useCallback / useCallback"
    ],
    "answer": "useState / useState",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1492",
    "question": "35. Как импортировать math? / math модулун кантип импорттоо керек?",
    "options": [
      "include math / include math",
      "import math / import math",
      "using math / using math",
      "require math / require math"
    ],
    "answer": "import math / import math",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1494",
    "question": "35. Что такое URL-маршрут? / URL-маршрут деген эмне?",
    "options": [
      "Страница админки / Админ бет",
      "Путь к view / Viewге алып баруучу жол",
      "Имя модели / Модельдин аты",
      "Тип формы / Форма түрү"
    ],
    "answer": "Путь к view / Viewге алып баруучу жол",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1497",
    "question": "Можно ли использовать хуки в условиях (if)? / Хукдарды if ичинде колдонсо болобу?",
    "options": [
      "Да / Ооба",
      "Нет / Жок",
      "Только useEffect / Факты useEffect гана",
      "Иногда / Кээде"
    ],
    "answer": "Нет / Жок",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa148b",
    "question": "34. Как создать комментарий? / Комментарий кантип жазылат?",
    "options": [
      "// / //",
      "<!-- --> / <!-- -->",
      "# / #",
      "** / **"
    ],
    "answer": "# / #",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa149c",
    "question": "Какой тег используется для списка с маркерами? / Маркерлер менен тизмени кайсы тег жасайт?",
    "options": [
      "<ol>",
      "<list>",
      "<ul>",
      "<li>"
    ],
    "answer": "<ul>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa148a",
    "question": "Какой тип у true? / true’нун типи кандай?",
    "options": [
      "boolean / boolean",
      "Boolean / Boolean",
      "string / string",
      "number / number"
    ],
    "answer": "boolean / boolean",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14b3",
    "question": "Что делает memo()? / memo() эмне кылат?",
    "options": [
      "Кэширует данные / Маанилерди кэштейт",
      "Предотвращает лишние рендеры компонента / Компоненттин керексиз рендерин алдын алат",
      "Хранит state / State сактайт",
      "Работает с API / API менен иштейт"
    ],
    "answer": "Предотвращает лишние рендеры компонента / Компоненттин керексиз рендерин алдын алат",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14af",
    "question": "39. Как установить библиотеку? / Китепкананы кантип орнотобуз?",
    "options": [
      "python install lib / python install lib",
      "pip install lib / pip install lib",
      "get lib / get lib",
      "import lib / import lib"
    ],
    "answer": "pip install lib / pip install lib",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ae",
    "question": "39. Как проверить элемент в списке? / Тизмеде элемент бар-жогун кантип текшерүү?",
    "options": [
      "has / has",
      "in / in",
      "exists / exists",
      "include / include"
    ],
    "answer": "in / in",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a6",
    "question": "Чем отличается type от interface? / Type менен interface эмнеге айырмаланат?",
    "options": [
      "Ничем / Айырмасы жок",
      "type не расширяется через extends / type extends аркылуу кеңейбейт",
      "interface можно расширять и объединять / Interface’ти кеңейтүүгө жана бириктирүүгө болот",
      "type устарел / type эскирген"
    ],
    "answer": "interface можно расширять и объединять / Interface’ти кеңейтүүгө жана бириктирүүгө болот",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a5",
    "question": "Что делает key в списках? / Списоктогу key эмне кылат?",
    "options": [
      "Стилизует элемент / Элементке стиль берет",
      "Ускоряет рендер и идентификацию элементов / Рендерди тездетет жана элементтерди туура тааныйт",
      "Обязателен для CSS / CSS үчүн милдеттүү",
      "Передаёт props / Props өткөрөт"
    ],
    "answer": "Ускоряет рендер и идентификацию элементов / Рендерди тездетет жана элементтерди туура тааныйт",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a3",
    "question": "Какой тег делает текст жирным семантически? / Текстти семантикалык жактан калын кылган тег?",
    "options": [
      "<b>",
      "<strong>",
      "<bold>",
      "<weight>"
    ],
    "answer": "<strong>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a2",
    "question": "37. Что такое db.sqlite3? / db.sqlite3 деген эмне?",
    "options": [
      "Файл настроек / Жөндөөлөр файлы",
      "Файл БД по умолчанию / Демейки БД файлы",
      "Статика / Статика",
      "Шаблон / Шаблон"
    ],
    "answer": "Файл БД по умолчанию / Демейки БД файлы",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa149f",
    "question": "Как описать массив чисел? / Сандык массивди кантип сүрөттөйбүз?",
    "options": [
      "number / number",
      "number[] / number[]",
      "[number] / [number]",
      "Array<string> / Array<string>"
    ],
    "answer": "number[] / number[]",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa149d",
    "question": "Как объединить два массива? / Эки массивди кантип бириктиребиз?",
    "options": [
      "arr1 arr2 / arr1 arr2",
      "arr1.concat(arr2) / arr1.concat(arr2)",
      "merge(arr1, arr2) / merge(arr1, arr2)",
      "arr.push(arr2) / arr.push(arr2)"
    ],
    "answer": "arr1.concat(arr2) / arr1.concat(arr2)",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa149b",
    "question": "36. Что такое CSRF? / CSRF деген эмне?",
    "options": [
      "Тип формы / Форма түрү",
      "Защита от поддельных запросов / Жасалма сурамдардан коргонуу",
      "Таблица / Таблица",
      "API метод / API метод"
    ],
    "answer": "Защита от поддельных запросов / Жасалма сурамдардан коргонуу",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa149a",
    "question": "36. Как импортировать модуль? / Модулду кантип импорттойбуз?",
    "options": [
      "include module / include module",
      "import module / import module",
      "load module / load module",
      "module import / module import"
    ],
    "answer": "import module / import module",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1493",
    "question": "35. Может ли функция вернуть несколько значений? / Функция бир нече маанини кайтара алабы?",
    "options": [
      "Нет / Жок",
      "Да, в виде tuple / Ооба, tuple түрүндө",
      "Да, если list / Ооба, list болсо",
      "Только dict / dict гана"
    ],
    "answer": "Да, в виде tuple / Ооба, tuple түрүндө",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa148d",
    "question": "34. Как выполнить вход? / Кирүү (login) кантип жасалат?",
    "options": [
      "signin() / signin()",
      "login(request, user) / login(request, user)",
      "request.login / request.login",
      "auth.start() / auth.start()"
    ],
    "answer": "login(request, user) / login(request, user)",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa148c",
    "question": "34. Параметр по умолчанию — это… / Демейки параметр деген эмне?",
    "options": [
      "Значение, если аргумент не передан / Аргумент берилбесе колдонулган маани",
      "Ошибка / Ката",
      "Модуль / Модуль",
      "Переменная с None / None менен өзгөрмө"
    ],
    "answer": "Значение, если аргумент не передан / Аргумент берилбесе колдонулган маани",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ab",
    "question": "Какой метод МЕНЯЕТ исходный массив? / Кайсы метод баштапкы массивди өзгөртөт?",
    "options": [
      "map() / map()",
      "filter() / filter()",
      "slice() / slice()",
      "splice() / splice()"
    ],
    "answer": "splice() / splice()",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14a1",
    "question": "37. Как импортировать функцию sqrt из math? / math ичинен sqrt кантип импорттойбуз?",
    "options": [
      "import sqrt / import sqrt",
      "from math import sqrt / from math import sqrt",
      "math->sqrt / math->sqrt",
      "include math.sqrt / include math.sqrt"
    ],
    "answer": "from math import sqrt / from math import sqrt",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa149e",
    "question": "Для чего нужен useRef? / useRef эмне үчүн керек?",
    "options": [
      "Для state / State үчүн",
      "Для DOM и сохранения значения без рендера / DOM жана рендерсиз маанини сактоо үчүн",
      "Для props / Props үчүн",
      "Для роутинга / Роутинг үчүн"
    ],
    "answer": "Для DOM и сохранения значения без рендера / DOM жана рендерсиз маанини сактоо үчүн",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1498",
    "question": "Что вернёт функция с типом void? / Void типтеги функция эмне кайтарат?",
    "options": [
      "null / null",
      "undefined / undefined",
      "false / false",
      "0 / 0"
    ],
    "answer": "undefined / undefined",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1491",
    "question": "Что делает strict: true в tsconfig? / tsconfig’теги strict: true эмнени аткарат?",
    "options": [
      "Ускоряет код / Кодду ылдамдатат",
      "Включает строгую типизацию / Катуу типтөөнү иштетет",
      "Отключает ошибки / Каталарды өчүрөт",
      "Работает только с React / Фактан React менен гана иштейт"
    ],
    "answer": "Включает строгую типизацию / Катуу типтөөнү иштетет",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1490",
    "question": "Что возвращает useState? / useState эмне кайтарат?",
    "options": [
      "Объект / Объект",
      "Значение / Маани",
      "Массив из значения и функции / Мааниден жана функциядан турган массив",
      "Promise / Promise"
    ],
    "answer": "Массив из значения и функции / Мааниден жана функциядан турган массив",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa14ad",
    "question": "Как задать необязательное свойство? / Кандай кылып милдеттүү эмес property түзөбүз?",
    "options": [
      "prop! / prop!",
      "prop? / prop?",
      "optional prop / optional prop",
      "prop?: optional / prop?: optional"
    ],
    "answer": "prop? / prop?",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.076Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1480",
    "question": "CSS файлын кайсы жерде туура туташтыруу керек? / Где правильно подключать CSS-файл?",
    "options": [
      "В <body>",
      "В <footer>",
      "В <head>",
      "В конце HTML без тега / Акырында, тегсиз"
    ],
    "answer": "В <head>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa145b",
    "question": "ID канча жолу колдонулат? Сколько раз можно использовать id?",
    "options": [
      "Көп жолу / Много раз",
      "Бир жолу гана / Один раз",
      "Эки жолу / Два раза",
      "Мааниси жок / Неважно"
    ],
    "answer": "Бир жолу гана / Один раз",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1459",
    "question": "**25. args — это… / args деген эмне?",
    "options": [
      "Словарь / Сөздүк",
      "Список / Тизмек",
      "Набор позиционных аргументов / Позициялык аргументтер",
      "Модуль / Модуль"
    ],
    "answer": "Набор позиционных аргументов / Позициялык аргументтер",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1478",
    "question": "31. Как получить текущего пользователя? / Азыркы колдонуучуну кантип алуу керек?",
    "options": [
      "user.get() / user.get()",
      "request.admin / request.admin",
      "request.user / request.user",
      "auth.user / auth.user"
    ],
    "answer": "request.user / request.user",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1482",
    "question": "Что вызывает повторный рендер компонента? / Компонентти кайра рендер кылган нерсе эмнеде?",
    "options": [
      "Изменение props или state / props же state өзгөргөндө",
      "Любой console.log / Ар бир console.log",
      "useRef / useRef",
      "CSS / CSS"
    ],
    "answer": "Изменение props или state / props же state өзгөргөндө",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa145f",
    "question": "26. Как объявить функцию? / Функцияны кантип жарыялоо керек?",
    "options": [
      "function my(): / function my():",
      "def my(): / def my():",
      "func my(): / func my():",
      "create my(): / create my():"
    ],
    "answer": "def my(): / def my():",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1460",
    "question": "**26. **kwargs — это… / kwargs деген эмне?",
    "options": [
      "tuple / tuple",
      "dict / dict",
      "list / list",
      "set / set"
    ],
    "answer": "dict / dict",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1462",
    "question": "display: inline-block эмнени берет? Что даёт inline-block?",
    "options": [
      "Фак гана саптык элемент / Только строка",
      "Фак гана блок элемент / Только блок",
      "Блок өлчөмдөрү саптык касиет / Размеры строка",
      "Grid элемент / Grid"
    ],
    "answer": "Блок өлчөмдөрү саптык касиет / Размеры строка",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1463",
    "question": "Бул код эмне чыгарат? let obj = {a: 1}; obj.b = 2; delete obj.a; console.log(obj);",
    "options": [
      "{a:1, b:2}",
      "{b:2}",
      "{}",
      "{a:undefined, b:2}"
    ],
    "answer": "{b:2}",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1469",
    "question": "top / left кайсы учурда иштейт? Когда работают top / left?",
    "options": [
      "static",
      "relative / absolute / fixed",
      "inline",
      "block"
    ],
    "answer": "relative / absolute / fixed",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa146c",
    "question": "tsconfig.json эмне үчүн керек? / Для чего нужен tsconfig.json?",
    "options": [
      "HTML сактайт / Хранит HTML",
      "TypeScriptтин настройкалары жана компиляция параметрлери үчүн / Для настроек TypeScript и параметров компиляции",
      "CSS үчүн / Для CSS",
      "React setup үчүн / Для настройки React"
    ],
    "answer": "TypeScriptтин настройкалары жана компиляция параметрлери үчүн / Для настроек TypeScript и параметров компиляции",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa146f",
    "question": "28. Что такое ModelForm? / ModelForm деген эмне?",
    "options": [
      "Шаблон / Шаблон",
      "Админка / Админка",
      "Форма на основе модели / Модельге негизделген форма",
      "API / API"
    ],
    "answer": "Форма на основе модели / Модельге негизделген форма",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1464",
    "question": "Reactте файлдар кандайча аталышы жакшы? / Как лучше называть файлы в React?",
    "options": [
      "app-file / app-file",
      "PascalCase — компоненттер үчүн баш тамга менен жазуу / PascalCase",
      "snake_case / snake_case",
      "Мааниси жок / Без разницы"
    ],
    "answer": "PascalCase — компоненттер үчүн баш тамга менен жазуу / PascalCase",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa147b",
    "question": "Что такое Virtual DOM? / Virtual DOM деген эмне?",
    "options": [
      "Копия HTML / HTML көчүрмөсү",
      "Объект в памяти для оптимизации рендера / Рендерди оптималдаштыруу үчүн эстутуктагы объект",
      "Shadow DOM / Shadow DOM",
      "Реальный DOM браузера / Браузердеги реалдуу DOM"
    ],
    "answer": "Объект в памяти для оптимизации рендера / Рендерди оптималдаштыруу үчүн эстутуктагы объект",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa147d",
    "question": "32. Результат: 5 == \"5\"? / Натыйжа: 5 == \"5\"?",
    "options": [
      "True / True",
      "False / False",
      "Ошибка / Ката",
      "None / None"
    ],
    "answer": "False / False",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa147f",
    "question": "32. Как проверить авторизацию? / Авторизацияны кантип текшерүү керек?",
    "options": [
      "if user.exist / if user.exist",
      "if request.user != None / != None",
      "if request.user.is_authenticated / is_authenticated",
      "if login() / login()"
    ],
    "answer": "if request.user.is_authenticated / is_authenticated",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1481",
    "question": "Boolean(\" \") (боштук менен сап) эмне кайтарат? / Что вернёт Boolean(\" \") (строка с пробелом)?",
    "options": [
      "false",
      "true",
      "null",
      "error"
    ],
    "answer": "true",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1485",
    "question": "33. Можно ли передавать функцию как аргумент? / Функцияны аргумент катары берсе болобу?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только лямбда / Лямбда гана",
      "Только встроенные / Ички гана"
    ],
    "answer": "Да / Ооба",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa147c",
    "question": "Является ли TypeScript строгой надстройкой над JS? / TypeScript JS үстүнө катуу кошумча болуп эсептелеби?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только для React / Фактан React үчүн",
      "Только для backend / Фактан backend үчүн"
    ],
    "answer": "Да / Ооба",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1470",
    "question": "29. Как получить ввод пользователя? / Колдонуучунун киргизүүсүн кантип алуу керек?",
    "options": [
      "get() / get()",
      "input() / input()",
      "read() / read()",
      "scan() / scan()"
    ],
    "answer": "input() / input()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa146d",
    "question": "28. Как вызвать функцию test? / test функциясын кантип чакыруу керек?",
    "options": [
      "call test / call test",
      "test / test",
      "test() / test()",
      "run test / run test"
    ],
    "answer": "test() / test()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa145a",
    "question": "25. Как создать суперпользователя? / Суперколдонуучуну кантип түзүү керек?",
    "options": [
      "python manage.py addadmin / addadmin",
      "python manage.py superuser / superuser",
      "python manage.py createsuperuser / createsuperuser",
      "django admin / django admin"
    ],
    "answer": "python manage.py createsuperuser / createsuperuser",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1483",
    "question": "Можно ли писать обычный JavaScript в TypeScript файле? / TypeScript файлына кадимки JavaScript жазууга болобу?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только с типами / Фактан типтер менен",
      "Только через any / Фактан any аркылуу"
    ],
    "answer": "Да / Ооба",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1484",
    "question": "33. True True = ? / True True эмне болот?",
    "options": [
      "0 / 0",
      "1 / 1",
      "2 / 2",
      "Ошибка / Ката"
    ],
    "answer": "2 / 2",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1486",
    "question": "33. Как выполнить выход? / Чыгуу (logout) кантип жасалат?",
    "options": [
      "logout() / logout()",
      "logout(request) / logout(request)",
      "exit user / exit user",
      "remove user / remove user"
    ],
    "answer": "logout(request) / logout(request)",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1487",
    "question": "Абзац текст үчүн кайсы тег колдонулат? / Какой тег используется для абзаца текста?",
    "options": [
      "<span>",
      "<p>",
      "<div>",
      "<text>"
    ],
    "answer": "<p>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1488",
    "question": "1 \"2\" кандай натыйжа берет? / Какой результат: 1 \"2\"?",
    "options": [
      "3 / 3",
      "\"3\" / \"3\"",
      "\"12\"",
      "error / ошибка"
    ],
    "answer": "\"12\"",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1479",
    "question": "CSS файлын туташтыруу үчүн кайсы тег колдонулат? / Какой тег используется для подключения CSS-файла?",
    "options": [
      "<style>",
      "<css>",
      "<link>",
      "<script>"
    ],
    "answer": "<link>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa147a",
    "question": "typeof undefined эмне кайтарат? / Что вернёт typeof undefined?",
    "options": [
      "null",
      "NaN",
      "object",
      "undefined"
    ],
    "answer": "undefined",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa146a",
    "question": "Бул код эмне чыгарат? console.log(false || \"hello\");",
    "options": [
      "false",
      "\"hello\"",
      "undefined",
      "null"
    ],
    "answer": "\"hello\"",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1468",
    "question": "27. Что такое Form? / Form деген эмне?",
    "options": [
      "База данных / Маалымат базасы",
      "Таблица / Таблица",
      "Python-класс для обработки данных / Маалыматты иштеткен Python классы",
      "HTML-файл / HTML файл"
    ],
    "answer": "Python-класс для обработки данных / Маалыматты иштеткен Python классы",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1467",
    "question": "27. Как записать лямбда-функцию? / Лямбда-функция кантип жазылат?",
    "options": [
      "lambda x: x1 / lambda x: x1",
      "def lambda: / def lambda:",
      "new lambda() / new lambda()",
      "func-lambda / func-lambda"
    ],
    "answer": "lambda x: x1 / lambda x: x1",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1466",
    "question": "27. Как вернуть значение? / Маанини кантип кайтаруу керек?",
    "options": [
      "send / send",
      "output / output",
      "return / return",
      "back / back"
    ],
    "answer": "return / return",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1465",
    "question": "TypeScript ким чыгарган? / Кто разработал TypeScript?",
    "options": [
      "Google / Google",
      "Apple / Apple",
      "Microsoft / Microsoft",
      "Meta / Meta"
    ],
    "answer": "Microsoft / Microsoft",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1461",
    "question": "26. Что такое админ-панель? / Админ-панель деген эмне?",
    "options": [
      "Терминал / Терминал",
      "Панель управления моделями / Моделдерди башкаруу панели",
      "Фронтенд / Фронтенд",
      "База данных / БД"
    ],
    "answer": "Панель управления моделями / Моделдерди башкаруу панели",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa145e",
    "question": "TS файлда CSS жазса болобу? / Можно ли писать CSS в TS файле?",
    "options": [
      "Ооба / Да",
      "Жок, CSS өзүнчө файлда болушу керек / Нет, CSS должен быть в отдельном файле",
      "React гана колдонот / Только React использует",
      "HTML керек / Нужен HTML"
    ],
    "answer": "Жок, CSS өзүнчө файлда болушу керек / Нет, CSS должен быть в отдельном файле",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa147e",
    "question": "**32. Тип **kwargs — это… / kwargs кайсы типте болот?",
    "options": [
      "list / list",
      "tuple / tuple",
      "dict /dict",
      "int / int"
    ],
    "answer": "dict /dict",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1477",
    "question": "**31. Тип args — это… / args кайсы типте болот?",
    "options": [
      "dict / dict",
      "tuple / tuple",
      "list / list",
      "str / str"
    ],
    "answer": "tuple / tuple",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1473",
    "question": "30. Тип данных input()? / input() демейки тиби кайсы?",
    "options": [
      "int / int",
      "float / float",
      "bool / bool",
      "str / str"
    ],
    "answer": "str / str",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1471",
    "question": "29. Как вызвать функцию? / Функцияны кантип чакырабыз?",
    "options": [
      "func{} / func{}",
      "func() / func()",
      "func[] / func[]",
      "call func / call func"
    ],
    "answer": "func() / func()",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa146b",
    "question": "Props менен stateтин айырмасы? / Разница между props и state?",
    "options": [
      "Экөө бирдей / Они одинаковые",
      "Props сыртан берилет, state компоненттин ичинде сакталат / Props передаются снаружи, state хранится внутри компонента",
      "Props ар дайым өзгөрөт / Props изменяются",
      "State өтпөйт / State не передается"
    ],
    "answer": "Props сыртан берилет, state компоненттин ичинде сакталат / Props передаются снаружи, state хранится внутри компонента",
    "category": "react",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1476",
    "question": "31. Как строку превратить в число? / Строканы санга кантип айлантуу?",
    "options": [
      "int(\"5\") / int(\"5\")",
      "number(\"5\") / number(\"5\")",
      "parse(\"5\") / parse(\"5\")",
      "toInt(\"5\") / toInt(\"5\")"
    ],
    "answer": "int(\"5\") / int(\"5\")",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1475",
    "question": "30. Где хранится статика? / Статикалык файлдар кайда сакталат?",
    "options": [
      "/media/ / /media/",
      "/templates/ / /templates/",
      "/static/ / /static/",
      "/user/ / /user/"
    ],
    "answer": "/static/ / /static/",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1474",
    "question": "30. Можно ли вложить функции? / Функция ичине функция жазса болобу?",
    "options": [
      "Нет / Жок",
      "Да / Ооба",
      "Только в JS / JS гана",
      "Только в классе / Класста гана"
    ],
    "answer": "Да / Ооба",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1472",
    "question": "29. За что отвечает manage.py? / manage.py эмне кылат?",
    "options": [
      "Открывает HTML / HTML ачат",
      "Запускает сервер и команды / Серверди жана буйруктарды иштетет",
      "Создаёт БД / БД түзөт",
      "Хранит настройки / Жөндөөлөрдү сактайт"
    ],
    "answer": "Запускает сервер и команды / Серверди жана буйруктарды иштетет",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa146e",
    "question": "28. Лямбда-функция содержит… / Лямбдада эмне болот?",
    "options": [
      "Много строк / Көп сап",
      "Одну команду / Бир гана команда",
      "Класс / Класс",
      "Модуль / Модуль"
    ],
    "answer": "Одну команду / Бир гана команда",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa145d",
    "question": "Компоненттер эмне үчүн бөлүнөт? / Зачем делят на компоненты?",
    "options": [
      "Кодду таза жана кайра колдонууга ыңгайлуу кылуу үчүн / Чтобы код был чистым и переиспользуемым",
      "CSS жазуу үчүн / Для CSS",
      "API чакыруу үчүн / Для API",
      "Ката болбош үчүн / Чтобы не было ошибок"
    ],
    "answer": "Кодду таза жана кайра колдонууга ыңгайлуу кылуу үчүн / Чтобы код был чистым и переиспользуемым",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.075Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa144b",
    "question": "23. Функция без return возвращает… / return жок функция эмне кайтарат?",
    "options": [
      "True / Чын",
      "0 / Нөл",
      "None / None",
      "\"\" / \"\""
    ],
    "answer": "None / None",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1453",
    "question": "24. Где регистрируются приложения? / Тиркемелер кайда катталат?",
    "options": [
      "urls.py / urls.py",
      "INSTALLED_APPS / INSTALLED_APPS",
      "admin.py / admin.py",
      "manage.py / manage.py"
    ],
    "answer": "INSTALLED_APPS / INSTALLED_APPS",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1451",
    "question": "24. Как остановить цикл? / Циклди кантип токтотуу керек?",
    "options": [
      "stop / stop",
      "exit / exit",
      "break / break",
      "end / end"
    ],
    "answer": "break / break",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1436",
    "question": "20. Можно ли создать класс без методов? / Методсуз класс түзүлөбү?",
    "options": [
      "Да / Ооба",
      "Нет / Жок",
      "Только в Python 2 / Python 2 гана",
      "Только с наследованием / Мурас менен гана"
    ],
    "answer": "Да / Ооба",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1456",
    "question": "default export эмне? / Что такое default export?",
    "options": [
      "Бир файлда бир эле негизги компонентти экспорттоо / Экспорт одного главного компонента из файла",
      "10 компонентти экспорттоо / Экспорт 10 компонентов",
      "Props / Props",
      "HTML / HTML"
    ],
    "answer": "Бир файлда бир эле негизги компонентти экспорттоо / Экспорт одного главного компонента из файла",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1452",
    "question": "24. Что такое параметры функции? / Функция параметрлери деген эмне?",
    "options": [
      "Модули / Модулдар",
      "Входные данные / Кирген маалымат",
      "Классы / Класстар",
      "Коммиты / Коммиттер"
    ],
    "answer": "Входные данные / Кирген маалымат",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1450",
    "question": "any көп колдонсо эмне болот? / Что произойдёт, если часто использовать any?",
    "options": [
      "Коопсуз болот / Станет безопасно",
      "Ката азаят / Ошибок меньше",
      "Тип коопсуздугу жоголот, ката көбөйөт / Потеря типобезопасности, ошибок становится больше",
      "Код тез иштейт / Код будет работать быстрее"
    ],
    "answer": "Тип коопсуздугу жоголот, ката көбөйөт / Потеря типобезопасности, ошибок становится больше",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa144c",
    "question": "23. Как удалить запись? / Жазууну кантип өчүрүү керек?",
    "options": [
      "del obj / del obj",
      "obj.remove() / obj.remove()",
      "obj.delete() / obj.delete()",
      "Model.drop() / Model.drop()"
    ],
    "answer": "obj.delete() / obj.delete()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa144a",
    "question": "23. Цикл while? / while цикли кандай жазылат?",
    "options": [
      "while x < 5: / while x < 5:",
      "while (x < 5) {} / {}",
      "loop x < 5 / loop",
      "repeat x < 5 / repeat"
    ],
    "answer": "while x < 5: / while x < 5:",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1446",
    "question": "HTMLде комментарий браузерде көрүнөбү? Отображается ли HTML комментарий в браузере?",
    "options": [
      "Ооба / Да",
      "Кээде / Иногда",
      "Жок / Нет",
      "Только в Chrome / Только в Chrome"
    ],
    "answer": "Жок / Нет",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1440",
    "question": "Hoisting деген эмне? / Что такое hoisting?",
    "options": [
      "Асинхронду иштетүү / Асинхрон",
      "Замыкание / Замыкание",
      "Өзгөрмөлөр жана функциялар декларациясынын жогору көтөрүлүшү / Поднятие переменных и функций",
      "Promise / Promise"
    ],
    "answer": "Өзгөрмөлөр жана функциялар декларациясынын жогору көтөрүлүшү / Поднятие переменных и функций",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa143d",
    "question": "21. Как объявить функцию? / Функцияны кантип түзөбүз?",
    "options": [
      "func name(): / func name():",
      "function name(): / function name():",
      "def name(): / def name():",
      "create function name / create function name"
    ],
    "answer": "def name(): / def name():",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa143c",
    "question": "21. Какой цикл используется для перебора? / Кайталоо үчүн кайсы цикл колдонулат?",
    "options": [
      "while / while",
      "loop / loop",
      "for / for",
      "repeat / repeat"
    ],
    "answer": "for / for",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1438",
    "question": "Box model курамына кирбейт? Что НЕ входит в box model?",
    "options": [
      "margin",
      "padding",
      "border",
      "color"
    ],
    "answer": "color",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1433",
    "question": "React кайсы файлда иштейт? / React работает в каком файле?",
    "options": [
      ".txt",
      ".jsx/.tsx",
      ".docx",
      ".jpg"
    ],
    "answer": ".jsx/.tsx",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1430",
    "question": "19. Что делает render()? / render() эмне кылат?",
    "options": [
      "Запускает сервер / Серверди иштетет",
      "Переводит текст / Текстти которот",
      "Показывает HTML-страницу / HTML бетти көрсөтөт",
      "Создаёт модель / Модель түзөт"
    ],
    "answer": "Показывает HTML-страницу / HTML бетти көрсөтөт",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa142f",
    "question": "19. Приватный атрибут начинается с… / Приват атрибут эмне менен башталат?",
    "options": [
      "! / !",
      "__ / __",
      "@@ / @@",
      "% / %"
    ],
    "answer": "__ / __",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa142e",
    "question": "19. Какой оператор «или»? / «Же» операторы кайсы?",
    "options": [
      "|| / ||",
      "or / or",
      "| / |",
      "?? / ??"
    ],
    "answer": "or / or",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1444",
    "question": "22. Что делает return? / return эмне кылат?",
    "options": [
      "Выводит текст / Текст чыгарат",
      "Возвращает значение / Маани кайтарат",
      "Удаляет переменную / Өзгөрмөнү өчүрөт",
      "Создаёт цикл / Цикл түзөт"
    ],
    "answer": "Возвращает значение / Маани кайтарат",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa142d",
    "question": "Типти туура көрсөтүү: “бул текст” / Как правильно указать тип для “бул текст”?",
    "options": [
      "let a: text / let a: text",
      "let a: string = \"бул текст\" / let a: string = \"бул текст\"",
      "let a = string / let a = string",
      "let a: string() / let a: string()"
    ],
    "answer": "let a: string = \"бул текст\" / let a: string = \"бул текст\"",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa142a",
    "question": "visibility: hidden эмнени кылат? Что делает visibility: hidden?",
    "options": [
      "Элементти толугу менен жок кылат / Убирает элемент полностью",
      "Жашырат, бирок орунду калтырат / Скрывает, но место остаётся",
      "DOMдон чыгарат / Удаляет из DOM",
      "Кичирейтет / Делает маленьким"
    ],
    "answer": "Жашырат, бирок орунду калтырат / Скрывает, но место остаётся",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1432",
    "question": "async функция ичинде await эмне кылат? / Что делает await внутри async функции?",
    "options": [
      "Кодду токтотот / Код останавливает",
      "Promise бүткөнчө күтөт, бирок thread блокталбайт / Ждёт завершения Promise",
      "Thread блоктойт / Блокирует поток",
      "Ката чыгарат / Вызывает ошибку"
    ],
    "answer": "Promise бүткөнчө күтөт, бирок thread блокталбайт / Ждёт завершения Promise",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1434",
    "question": "Кайсы тип \"белгисиз\" дегенди билдирет? / Какой тип обозначает \"неизвестный\"?",
    "options": [
      "any / any",
      "string / string",
      "unknown — белгисиз тип / unknown",
      "boolean / boolean"
    ],
    "answer": "unknown — белгисиз тип / unknown",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1437",
    "question": "20. Как вернуть текст из view? / View ичинен текстти кантип кайтаруу керек?",
    "options": [
      "Return(Home) / Return(Home)",
      "TextResponse() / TextResponse()",
      "HttpResponse(\"text\") / HttpResponse(\"text\")",
      "message() / message()"
    ],
    "answer": "HttpResponse(\"text\") / HttpResponse(\"text\")",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa143a",
    "question": "React Router эмне үчүн керек? / Для чего нужен React Router?",
    "options": [
      "Стилизация үчүн / Для стилизации",
      "Навигация жана багыттоо үчүн / Для навигации и маршрутизации",
      "State сактоо үчүн / Для хранения состояния",
      "HTML түзүү үчүн / Для HTML"
    ],
    "answer": "Навигация жана багыттоо үчүн / Для навигации и маршрутизации",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa143b",
    "question": "Төмөнкүдөй tuple туурабы? / Верна ли следующая запись tuple? let t: [string, number] = [\"hi\", 5];",
    "options": [
      "Ооба, туура / Да, верно",
      "Жок / Нет",
      "Array / Массив",
      "Алмашкан / Поменяно"
    ],
    "answer": "Ооба, туура / Да, верно",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1447",
    "question": "Бул код эмне чыгарат? / Что выведет? let x = 10; function test() { console.log(x); } test();",
    "options": [
      "undefined",
      "error",
      "10",
      "null"
    ],
    "answer": "10",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa144d",
    "question": "CSSте !important эмне кылат? Что делает !important?",
    "options": [
      "Стилди жок кылат / Удаляет стиль",
      "Приоритетти жогорулатат / Повышает приоритет",
      "Ката берет / Ошибка",
      "Комментарий кылат / Комментарий"
    ],
    "answer": "Приоритетти жогорулатат / Повышает приоритет",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa144e",
    "question": "Натыйжа? / Результат? let x = 1; function test() { x = 2; } test(); console.log(x);",
    "options": [
      "1",
      "2",
      "undefined",
      "error"
    ],
    "answer": "2",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa144f",
    "question": "Динамик текст кантип чыгат? / Как вывести динамический текст?",
    "options": [
      "<h1>value</h1>",
      "<h1>{value}</h1>",
      "<h1>${value}</h1>",
      "<h1>(value)</h1>"
    ],
    "answer": "<h1>{value}</h1>",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1454",
    "question": "Бир нече класс берүү туура синтаксис? Правильная запись нескольких классов?",
    "options": [
      "class=\"item,box\"",
      "class=\"itembox\"",
      "class=\"item box\"",
      "class=\"item.box\""
    ],
    "answer": "class=\"item box\"",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1455",
    "question": "Эмне үчүн closure керек? / Зачем нужен closure?",
    "options": [
      "Кодду кыскартуу / Сокращение кода",
      "Асинхрондук иштетүү / Асинхрон",
      "Маалыматты сактоо жана инкапсуляциялоо / Сохранение данных и инкапсуляция",
      "DOM менен иштетүү / Работа с DOM"
    ],
    "answer": "Маалыматты сактоо жана инкапсуляциялоо / Сохранение данных и инкапсуляция",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1429",
    "question": "18. Что такое queryset? / Queryset деген эмне?",
    "options": [
      "SQL-запрос / SQL сураныч",
      "Набор данных из модели / Моделден алынган маалымат топтому",
      "HTML-таблица / HTML таблица",
      "Шаблон / Шаблон"
    ],
    "answer": "Набор данных из модели / Моделден алынган маалымат топтому",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1431",
    "question": "Горизонталдык теңдөө (flex)? Горизонтальное выравнивание?",
    "options": [
      "align-items",
      "justify-content",
      "text-align",
      "flex-align"
    ],
    "answer": "justify-content",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa143f",
    "question": "<meta charset=\"UTF-8\"> эмне үчүн керек? Для чего нужен <meta charset=\"UTF-8\">?",
    "options": [
      "Баш аталыш үчүн / Заголовок",
      "Символдордун кодировкасын белгилөө үчүн / Кодировка символов",
      "CSS туташтыруу үчүн / Подключение CSS",
      "SEO үчүн / SEO"
    ],
    "answer": "Символдордун кодировкасын белгилөө үчүн / Кодировка символов",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1448",
    "question": "Component props кантип кабыл алат? / Как принять props в компоненте?",
    "options": [
      "props() / props()",
      "Функциянын параметри катары props алуу: function C(props) / Передача props через параметр функции",
      "useState(props) / useState(props)",
      "JSON / JSON"
    ],
    "answer": "Функциянын параметри катары props алуу: function C(props) / Передача props через параметр функции",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1443",
    "question": "22. Как вывести числа 0–4? / 0дон 4кө чейин кантип алуу керек?",
    "options": [
      "range(5) / range(5)",
      "range(1,5) / range(1,5)",
      "range(0,4) / range(0,4)",
      "range(5,1) / range(5,1)"
    ],
    "answer": "range(5) / range(5)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1441",
    "question": "API сурам кайда жасалат? / Где делают API запрос?",
    "options": [
      "return ичинде / В return",
      "useEffect ичинде / В useEffect",
      "CSS ичинде / В CSS",
      "props ичинде / В props"
    ],
    "answer": "useEffect ичинде / В useEffect",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1439",
    "question": "await кайсы жерде иштейт? / Где работает await?",
    "options": [
      "Каалаган жерде / В любом месте",
      "Функция ичинде / Внутри функции",
      "async функция ичинде гана / Только внутри async function",
      "Promise ичинде / Внутри Promise"
    ],
    "answer": "async функция ичинде гана / Только внутри async function",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1435",
    "question": "20. Какой оператор «не»? / «Туура эмес» (not) операторы кайсы?",
    "options": [
      "! / !",
      "not / not",
      "!= / !=",
      "no / no"
    ],
    "answer": "not / not",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa142c",
    "question": "Компонентти кантип экспорттойбуз? / Как экспортировать компонент?",
    "options": [
      "export HTML / export HTML",
      "export default Component / export default Component",
      "export jsx / export jsx",
      "useEffect / useEffect"
    ],
    "answer": "export default Component / export default Component",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa142b",
    "question": "Бул код эмне чыгарат? / Что выведет код? console.log(1); setTimeout(() => console.log(2), 0); console.log(3);",
    "options": [
      "1 2 3",
      "1 3 2",
      "2 1 3",
      "3 1 2"
    ],
    "answer": "1 3 2",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1458",
    "question": "25. Как пропустить итерацию? / Итерацияны кантип өткөрүп жиберүү керек?",
    "options": [
      "skip / skip",
      "pass / pass",
      "continue / continue",
      "next / next"
    ],
    "answer": "continue / continue",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1457",
    "question": "Функциянын аргументин типтөө / Как типизировать аргументы функции в TypeScript?",
    "options": [
      "function sum(a,b) / function sum(a,b)",
      "function sum(a: number, b: number) — туура типтөө / function sum(a: number, b: number)",
      "function sum(a:number b:number) / function sum(a:number b:number)",
      "sum:number / sum:number"
    ],
    "answer": "function sum(a: number, b: number) — туура типтөө / function sum(a: number, b: number)",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1449",
    "question": "Объектти типтөө / Как типизировать объект в TypeScript?",
    "options": [
      "let a = {name: string} / let a = {name: string}",
      "let a: {name: string} = { name: \"Ali\" } — туура типтөө / let a: {name: string} = { name: \"Ali\" }",
      "let a(name:string) / let a(name:string)",
      "name=\"Ali\" / name=\"Ali\""
    ],
    "answer": "let a: {name: string} = { name: \"Ali\" } — туура типтөө / let a: {name: string} = { name: \"Ali\" }",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1445",
    "question": "22. Как создать запись? / Жазууну кантип түзсө болот?",
    "options": [
      "Model.insert() / Model.insert()",
      "Model.objects.create() / Model.objects.create()",
      "Model.add() / Model.add()",
      "Model.write() / Model.write()"
    ],
    "answer": "Model.objects.create() / Model.objects.create()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1442",
    "question": "Кайсысы туура interface? / Какой вариант правильный для interface?",
    "options": [
      "interface {name:string} / interface {name:string}",
      "interface User { name: string } — туура жазылыш / interface User { name: string }",
      "interface(User) / interface(User)",
      "interface User() / interface User()"
    ],
    "answer": "interface User { name: string } — туура жазылыш / interface User { name: string }",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa143e",
    "question": "21. Как получить один объект? / Бир объектти кантип алуу керек?",
    "options": [
      "Model.objects.first() / Model.objects.first()",
      "Model.single() / Model.single()",
      "Model.take() / Model.take()",
      "Model.one() / Model.one()"
    ],
    "answer": "Model.objects.first() / Model.objects.first()",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.074Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1418",
    "question": "RootState кайда жазылат? / Где объявляется RootState?",
    "options": [
      "Компонентте / В компоненте",
      "store.ts файлынын ичинде / Внутри файла store.ts",
      "index.css / index.css",
      "App.jsx / App.jsx"
    ],
    "answer": "store.ts файлынын ичинде / Внутри файла store.ts",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1419",
    "question": "16. Как проверить тип переменной? / Өзгөрмөнүн тибин кантип текшерүү керек?",
    "options": [
      "check() / check()",
      "typeof() / typeof()",
      "type() / type()",
      "isinstance() / isinstance()"
    ],
    "answer": "type() / type()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1420",
    "question": "17. Как написать условие? / Шартты кантип жазуу керек?",
    "options": [
      "if x = 5 / if x = 5",
      "if x == 5 / if x == 5",
      "if x === 5 / if x === 5",
      "if (x == 5) {} / if (x == 5) {}"
    ],
    "answer": "if x == 5 / if x == 5",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa141c",
    "question": "z-index эмне үчүн керек? Для чего нужен z-index?",
    "options": [
      "Өлчөмү үчүн / Размер",
      "Түсү үчүн / Цвет",
      "Элементтердин катмарын жөнгө салуу үчүн / Слой элементов",
      "Шрифт үчүн / Шрифт"
    ],
    "answer": "Элементтердин катмарын жөнгө салуу үчүн / Слой элементов",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa141e",
    "question": "State эмне үчүн керек? / Для чего нужен state?",
    "options": [
      "DOM түзүү үчүн / Для создания DOM",
      "Компоненттин ички маанисин сактоо үчүн / Для хранения внутреннего состояния компонента",
      "CSS жазуу үчүн / Для написания CSS",
      "Router үчүн / Для Router"
    ],
    "answer": "Компоненттин ички маанисин сактоо үчүн / Для хранения внутреннего состояния компонента",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13fe",
    "question": "12. Полиморфизм — это… / Полиморфизм — бул…",
    "options": [
      "Разные файлы / Ар түрдүү файлдар",
      "Один метод — разное поведение / Бир метод — ар башка жүрүм-турум",
      "Программа / Программа",
      "Ошибка / Ката"
    ],
    "answer": "Один метод — разное поведение / Бир метод — ар башка жүрүм-турум",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa141b",
    "question": "16. Функция path()? / path() эмне кылат?",
    "options": [
      "Запуск сервера / Серверди иштетет",
      "Настройка URL-маршрутов / URL маршруттарын орнотот",
      "Создание моделей / Модель түзөт",
      "Создание пользователя / Колдонуучу түзөт"
    ],
    "answer": "Настройка URL-маршрутов / URL маршруттарын орнотот",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e2",
    "question": "8. Что такое self? / self деген эмне?",
    "options": [
      "Имя класса / Класстын аты",
      "Ссылка на объект / Объектке шилтеме",
      "Модуль / Модуль",
      "Тип данных / Маалымат түрү"
    ],
    "answer": "Ссылка на объект / Объектке шилтеме",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e3",
    "question": "8. Как применить миграции? / Миграцияларды кантип колдонуу керек?",
    "options": [
      "python manage.py maketable / python manage.py maketable",
      "python manage.py migrate / python manage.py migrate",
      "python manage.py sync / python manage.py sync",
      "python create db / python create db"
    ],
    "answer": "python manage.py migrate / python manage.py migrate",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e5",
    "question": "in оператору эмне кылат? Что делает оператор in?",
    "options": [
      "Типти текшерет / Проверяет тип",
      "Маанини текшерет / Значение",
      "️ Объектте же prototypeте касиет бар экенин текшерет / Проверяет наличие свойства в объекте или prototype",
      "Салыштырат / Сравнив"
    ],
    "answer": "️ Объектте же prototypeте касиет бар экенин текшерет / Проверяет наличие свойства в объекте или prototype",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e6",
    "question": "createBrowserRouter кайдан келет? / Откуда берётся createBrowserRouter?",
    "options": [
      "react-router-dom",
      "React",
      "Vite",
      "Redux"
    ],
    "answer": "react-router-dom",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ee",
    "question": "Interface эмне үчүн керек? / Для чего нужен interface в TypeScript?",
    "options": [
      "Класс түзүү үчүн / Для создания класса",
      "Объекттин формасын сүрөттөө үчүн (типти аныктоо) / Чтобы описать форму объекта (тип)",
      "Import кылуу үчүн / Для импорта",
      "CSS үчүн / Для CSS"
    ],
    "answer": "Объекттин формасын сүрөттөө үчүн (типти аныктоо) / Чтобы описать форму объекта (тип)",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f0",
    "question": "10. Как объявить наследование? / Мурас алуучу класс кантип жазылат?",
    "options": [
      "class B <- A / class B <- A",
      "class B(A) / class B(A)",
      "class B = A / class B = A",
      "class B inherit A / class B inherit A"
    ],
    "answer": "class B(A) / class B(A)",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f4",
    "question": "Vite env өзгөрмө кантип жазылат? / Как объявляется переменная окружения в Vite?",
    "options": [
      "VITE_API_URL / VITE_API_URL",
      "API_URL / API_URL",
      "import.meta.API / import.meta.API",
      "process.env.API / process.env.API"
    ],
    "answer": "VITE_API_URL / VITE_API_URL",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13fd",
    "question": "12. Как создать кортеж? / Кортежди кантип түзүү керек?",
    "options": [
      "[1, 2] / [1, 2]",
      "{1, 2} / {1, 2}",
      "(1, 2) / (1, 2)",
      "<1, 2> / <1, 2>"
    ],
    "answer": "(1, 2) / (1, 2)",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1403",
    "question": "useStateти кантип типтейбиз? / Как типизировать useState в TypeScript?",
    "options": [
      "useState:number / useState:number",
      "useState<number>() — саны сактоо үчүн / useState<number>()",
      "useState[] / useState[]",
      "useState:ts / useState:ts"
    ],
    "answer": "useState<number>() — саны сактоо үчүн / useState<number>()",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1404",
    "question": "13. Можно ли изменить кортеж? / Кортежди өзгөртсө болобу?",
    "options": [
      "Да / Ооба",
      "Нет / Жок",
      "Иногда / Кээде",
      "Только первый элемент / Биринчи эле элементти"
    ],
    "answer": "Нет / Жок",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1413",
    "question": "15. Как вызвать метод объекта? / Объекттин методун кантип чакырабыз?",
    "options": [
      "obj-method / obj-method",
      "obj[method] / obj[method]",
      "obj.method() / obj.method()",
      "method(obj) / method(obj)"
    ],
    "answer": "obj.method() / obj.method()",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1415",
    "question": "Талааны милдеттүү кылуучу атрибут? Атрибут обязательного поля?",
    "options": [
      "required",
      "checked",
      "disabled",
      "placeholder"
    ],
    "answer": "required",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1417",
    "question": "Props өзгөрөбү? / Можно ли менять props?",
    "options": [
      "Ооба / Да",
      "Жок, props immutable / Нет, props неизменяемы",
      "Кээде / Иногда",
      "useEffect менен өзгөртүүгө болот / Можно изменить через useEffect"
    ],
    "answer": "Жок, props immutable / Нет, props неизменяемы",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1412",
    "question": "15. Как получить значение по ключу? / Ключ боюнча маанини кантип алуу керек?",
    "options": [
      "dict.key / dict.key",
      "dict[key] / dict[key]",
      "dict(key) / dict(key)",
      "dict->key / dict->key"
    ],
    "answer": "dict[key] / dict[key]",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1426",
    "question": "TypeScript эмне үчүн керек? / Для чего нужен TypeScript?",
    "options": [
      "Верстка үчүн / Для верстки",
      "Тип коопсуздугу үчүн, каталарды азайтуу жана автокомплитти жакшыртуу үчүн / Для типобезопасности, уменьшения ошибок и улучшения автокомплита",
      "HTML үчүн / Для HTML",
      "JavaScriptти өчүрүү үчүн / Чтобы отключить JavaScript"
    ],
    "answer": "Тип коопсуздугу үчүн, каталарды азайтуу жана автокомплитти жакшыртуу үчүн / Для типобезопасности, уменьшения ошибок и улучшения автокомплита",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e9",
    "question": "9. Наследование — это… / Мурас алуу — бул…",
    "options": [
      "Копирование файлов / Файлдарды көчүрүү",
      "Передача свойств / Касиеттерди өткөрүп берүү",
      "Удаление объектов / Объекттерди өчүрүү",
      "Ошибка / Ката"
    ],
    "answer": "Передача свойств / Касиеттерди өткөрүп берүү",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ed",
    "question": "useNavigate эмне кылат? / Что делает useNavigate?",
    "options": [
      "Программалык навигация жүргүзөт / Программная навигация",
      "props өзгөртөт / Изменяет props",
      "ref менен иштейт / Работает с ref",
      "DOMдан элемент тандайт / Выбирает элемент из DOM"
    ],
    "answer": "Программалык навигация жүргүзөт / Программная навигация",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f5",
    "question": "Type менен interface айырмасы? / Разница между type и interface?",
    "options": [
      "Interface кеңейтсе болот (extends), type менен андай эмес / Interface можно расширять (extends), type — нет",
      "Type кеңейтсе болот / Type можно расширять",
      "Type жакшы / Type лучше",
      "Interface колдонулбайт / Interface не используется"
    ],
    "answer": "Interface кеңейтсе болот (extends), type менен андай эмес / Interface можно расширять (extends), type — нет",
    "category": "typescript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f9",
    "question": "<header> теги эмнени билдирет? Что обозначает тег <header>?",
    "options": [
      "Беттин асткы бөлүгү (подвал страницы) / Подвал страницы",
      "Негизги контент / Основной контент",
      "Беттин башы, шапка / Шапка страницы",
      "Жан тараптагы панель / Боковая панель"
    ],
    "answer": "Беттин башы, шапка / Шапка страницы",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ff",
    "question": "12. Где хранятся HTML-шаблоны? / HTML шаблондор кайда сакталат?",
    "options": [
      "/static/ / /static/",
      "/public/ / /public/",
      "/templates/ / /templates/",
      "/views/ / /views/"
    ],
    "answer": "/templates/ / /templates/",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1400",
    "question": "<footer> теги эмне үчүн? Для чего используется <footer>?",
    "options": [
      "Баш аталыш / Заголовок",
      "Негизги текст / Основной текст",
      "Беттин төмөнкү бөлүгү / Нижняя часть страницы",
      "Сүрөт / Картинка"
    ],
    "answer": "Беттин төмөнкү бөлүгү / Нижняя часть страницы",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1407",
    "question": "<nav> теги кайсы үчүн колдонулат? Для чего используется <nav>?",
    "options": [
      "Сүрөттөр үчүн / Картинки",
      "Навигация үчүн / Навигация",
      "Формалар үчүн / Формы",
      "Жадвалдар үчүн / Таблицы"
    ],
    "answer": "Навигация үчүн / Навигация",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa140b",
    "question": "14. Как создать словарь? / Сөздүк (dict) кантип түзүлөт?",
    "options": [
      "[] / []",
      "() / ()",
      "{} / {}",
      "<> / <>"
    ],
    "answer": "{} / {}",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa140d",
    "question": "14. Для чего models.py? / models.py эмне үчүн керек?",
    "options": [
      "Для CSS / CSS үчүн",
      "Для таблиц БД / Маалымат базасы таблицалары үчүн",
      "Для запуска сервера / Серверди иштетүү үчүн",
      "Для статики / Статика үчүн"
    ],
    "answer": "Для таблиц БД / Маалымат базасы таблицалары үчүн",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa140e",
    "question": "Тизмеден тандоо (dropdown)? Выпадающий список?",
    "options": [
      "Тизме (unordered list) / <ul>",
      "Опция (вариант) / <option>",
      "Тизмеден тандоо (select) / <select>",
      "Киргизүү талаасы (input) / <input>"
    ],
    "answer": "Тизмеден тандоо (select) / <select>",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1411",
    "question": "PayloadAction кайда колдонулат? (Redux) / Где используется PayloadAction в Redux?",
    "options": [
      "UI үчүн / Для UI",
      "Reducer ичинде action.payloadти типтеш үчүн / Для типизации action.payload внутри reducer",
      "Router үчүн / Для Router",
      "State үчүн / Для State"
    ],
    "answer": "Reducer ичинде action.payloadти типтеш үчүн / Для типизации action.payload внутри reducer",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e7",
    "question": "never качан колдонулат? / Когда используется never?",
    "options": [
      "Функция ар дайым return кылганда / Когда функция всегда возвращает",
      "Функция эч качан бүтпөгөндө (мисалы: error чыгарат же цикл түгөнбөйт) / Когда функция никогда не завершится (например, выбрасывает ошибку)",
      "String / string",
      "Boolean / boolean"
    ],
    "answer": "Функция эч качан бүтпөгөндө (мисалы: error чыгарат же цикл түгөнбөйт) / Когда функция никогда не завершится (например, выбрасывает ошибку)",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1424",
    "question": "Бул код эмне чыгарат? / Что выведет? let arr = [1, 2, 3]; console.log(arr.indexOf(5));",
    "options": [
      "5",
      "0",
      "-1",
      "undefined"
    ],
    "answer": "-1",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1423",
    "question": "display: none эмнени кылат? Что делает display: none?",
    "options": [
      "Жашырат, бирок орунду калтырат / Скрывает, но оставляет место",
      "Элементти толугу менен жашырат / Полностью убирает элемент",
      "Ачыктык кылат (прозрачный кылат) / Делает прозрачным",
      "Фиксациялайт / Фиксирует"
    ],
    "answer": "Элементти толугу менен жашырат / Полностью убирает элемент",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa141f",
    "question": "Dispatchти типтөө үчүн эмне колдонулат? / Для типизации dispatch используется:",
    "options": [
      "TypeProps / TypeProps",
      "AppDispatch — storeдан алынган тип / AppDispatch",
      "UseDispatch / useDispatch",
      "ActionType / ActionType"
    ],
    "answer": "AppDispatch — storeдан алынган тип / AppDispatch",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa141a",
    "question": "16. Что такое конструктор? / Конструктор деген эмне?",
    "options": [
      "Метод, создающий объект / Объект түзгөн метод",
      "Переменная / Өзгөрмө",
      "Модуль / Модуль",
      "Лямбда / Лямбда"
    ],
    "answer": "Метод, создающий объект / Объект түзгөн метод",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1416",
    "question": "Бул код эмне чыгарат? / Что выведет? let a; console.log(a);",
    "options": [
      "null",
      "undefined",
      "0",
      "error"
    ],
    "answer": "undefined",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1414",
    "question": "15. Что такое view? / View деген эмне?",
    "options": [
      "Функция обработки запросов / Суроо-талапты иштеткен функция",
      "HTML-файл / HTML файл",
      "Статика / Статика",
      "Админка / Админка"
    ],
    "answer": "Функция обработки запросов / Суроо-талапты иштеткен функция",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa140a",
    "question": "Props кантип типтелет? / Как типизировать props в TypeScript?",
    "options": [
      "Компонент ичинде гана / Только внутри компонента",
      "interface Props {} аркылуу жана компоненттин аргументинде колдонобуз / Через interface Props {} и используем в аргументе компонента",
      "HTML менен / Через HTML",
      "CSS менен / Через CSS"
    ],
    "answer": "interface Props {} аркылуу жана компоненттин аргументинде колдонобуз / Через interface Props {} и используем в аргументе компонента",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1409",
    "question": "JSX эмнеге окшош? / На что похож JSX?",
    "options": [
      "SQL",
      "HTMLге окшош / Похоже на HTML",
      "CSS",
      "JSON"
    ],
    "answer": "HTMLге окшош / Похоже на HTML",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1402",
    "question": "Компонент деген эмне? / Что такое компонент?",
    "options": [
      "HTML файл / HTML файл",
      "Функция же класс JSX кайтарган / Функция или класс, возвращающий JSX",
      "CSS блогу / CSS блок",
      "Браузер / Браузер"
    ],
    "answer": "Функция же класс JSX кайтарган / Функция или класс, возвращающий JSX",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e4",
    "question": "transform: scale эмне кылат? Что делает scale?",
    "options": [
      "Айландырат / Поворачивает",
      "Масштабдайт (чоңойтот/кичирейтет) / Масштабирует",
      "Жылдыртат / Двигает",
      "Жашырат / Скрывает"
    ],
    "answer": "Масштабдайт (чоңойтот/кичирейтет) / Масштабирует",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1422",
    "question": "17. Что такое миграции? / Миграциялар деген эмне?",
    "options": [
      "HTML-страницы / HTML беттер",
      "Обновления БД по моделям / Моделдерге жараша БД өзгөртүүлөрү",
      "Админка / Админка",
      "Статика / Статика"
    ],
    "answer": "Обновления БД по моделям / Моделдерге жараша БД өзгөртүүлөрү",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ea",
    "question": "9. Команда создания миграций? / Миграция түзүү буйругу кайсы?",
    "options": [
      "makedb / makedb",
      "create / create",
      "makemigrations / makemigrations",
      "syncdb / syncdb"
    ],
    "answer": "makemigrations / makemigrations",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ec",
    "question": "async жана await кантип иштейт? Как работают async и await?",
    "options": [
      "async кодду блоктоп коёт / async блокирует код",
      "await синхрондуу / await синхронный",
      "️ await Promise бүткүчө күтөт, жана бул async ичинде гана иштейт / await ждёт завершения Promise внутри async",
      "async undefined кайтарат / async возвращает undefined"
    ],
    "answer": "️ await Promise бүткүчө күтөт, жана бул async ичинде гана иштейт / await ждёт завершения Promise внутри async",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ef",
    "question": "10. Как получить первый элемент списка a? / a тизмесинин биринчи элементин кантип алуу керек?",
    "options": [
      "a(0) / a(0)",
      "a[1] / a[1]",
      "a[0] / a[0]",
      "a.first() / a.first()"
    ],
    "answer": "a[0] / a[0]",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f1",
    "question": "10. Где регистрировать модели в админке? / Моделдерди админкага кайда каттайбыз?",
    "options": [
      "settings.py / settings.py",
      "admin.py / admin.py",
      "urls.py / urls.py",
      "forms.py / forms.py"
    ],
    "answer": "admin.py / admin.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f3",
    "question": "shift() эмне кылат? Что делает shift()?",
    "options": [
      "Элемент кошот / Добавляет элемент",
      "Массивдин биринчи элементин жок кылат / Удаляет первый элемент массива",
      "Акыркы элементти жок кылат / Удаляет последний",
      "Тартипти өзгөртөт / Меняет порядок"
    ],
    "answer": "Массивдин биринчи элементин жок кылат / Удаляет первый элемент массива",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f6",
    "question": "11. Как добавить элемент в список? / Тизмеге элементти кантип кошуу керек?",
    "options": [
      "add() / add()",
      "push() / push()",
      "append() / append()",
      "insert() / insert()"
    ],
    "answer": "append() / append()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f7",
    "question": "11. Что такое инкапсуляция? / Инкапсуляция деген эмне?",
    "options": [
      "Разделение таблиц / Таблицаларды бөлүү",
      "Сокрытие деталей /Деталдарды жашыруу",
      "Импорт библиотеки / Китепкананы импорттоо",
      "Создание бота / Бот түзүү"
    ],
    "answer": "Сокрытие деталей /Деталдарды жашыруу",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13fa",
    "question": "return кайсы жерде колдонулат? Где используется return?",
    "options": [
      "Циклда / Цикл",
      "Функцияда / Функция",
      "Promise ичинде / Promise",
      "DOMдо / DOM"
    ],
    "answer": "Функцияда / Функция",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13fc",
    "question": "Кайсы файл TypeScript? / Какой файл является TypeScript?",
    "options": [
      ".js",
      ".jsx",
      ".ts / .tsx",
      ".json"
    ],
    "answer": ".ts / .tsx",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1401",
    "question": "setTimeout жана setInterval айырмасы? Разница между setTimeout и setInterval?",
    "options": [
      "Айырмасы жок / Нет разницы",
      "setTimeout бир жолу иштейт, setInterval кайталайт / setTimeout один раз, setInterval повторяет",
      "setInterval бир жолу иштейт / setInterval один раз",
      "Promise / Promise"
    ],
    "answer": "setTimeout бир жолу иштейт, setInterval кайталайт / setTimeout один раз, setInterval повторяет",
    "category": "javascript",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1421",
    "question": "17. Можно ли создать пустой класс? / Бош классты түзсө болобу?",
    "options": [
      "Да, через pass / Ооба, pass менен",
      "Нет / Жок",
      "Только с init / faqat init менен",
      "Только через импорт / Импорт менен гана"
    ],
    "answer": "Да, через pass / Ооба, pass менен",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f8",
    "question": "11. Шаблонизатор Django? / Django шаблондор системасы?",
    "options": [
      "Jinja2 / Jinja2",
      "Django Template Language / Django Template Language",
      "Mako / Mako",
      "HTML Engine / HTML Engine"
    ],
    "answer": "Django Template Language / Django Template Language",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13fb",
    "question": "React эмне үчүн колдонулат? / Для чего используют React?",
    "options": [
      "Backend үчүн / Backend",
      "Колдонуучу интерфейс (UI) түзүү үчүн / Для создания UI",
      "Маалымат базасы үчүн / Database",
      "Windows программасы үчүн / Windows-приложение"
    ],
    "answer": "Колдонуучу интерфейс (UI) түзүү үчүн / Для создания UI",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1405",
    "question": "13. Метод str возвращает… / str методу эмне кайтарат?",
    "options": [
      "Список / Тизмек",
      "Число / Сан",
      "Строковое описание объекта / Объекттин тексттик сүрөттөлүшү",
      "Объект / Объект"
    ],
    "answer": "Строковое описание объекта / Объекттин тексттик сүрөттөлүшү",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1406",
    "question": "13. Что такое приложение? / Приложение (app) деген эмне?",
    "options": [
      "Файл стилей / Стиль файлы",
      "Независимый модуль / Көз каранды эмес модуль",
      "Таблица БД / БД таблицасы",
      "Сервер / Сервер"
    ],
    "answer": "Независимый модуль / Көз каранды эмес модуль",
    "category": "Django",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1408",
    "question": "Эмне чыгат? / Что выведет? console.log(0 && \"hello\");",
    "options": [
      "\"hello\"",
      "0",
      "false",
      "null"
    ],
    "answer": "0",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa140c",
    "question": "14. Что такое метод? / Метод деген эмне?",
    "options": [
      "Функция внутри класса / Класс ичиндеги функция",
      "Файл / Файл",
      "Атрибут / Атрибут",
      "Команда Git / Git командасы"
    ],
    "answer": "Функция внутри класса / Класс ичиндеги функция",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1410",
    "question": "Props эмнени билдирет? / Что такое props?",
    "options": [
      "Ички state / Внутренний state",
      "Компонентке берилген маалымат / Данные, переданные в компонент",
      "CSS стили / CSS стили",
      "ID / ID"
    ],
    "answer": "Компонентке берилген маалымат / Данные, переданные в компонент",
    "category": "react",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa141d",
    "question": "Бул код эмне чыгарат? / Что выведет? console.log([1, 2, 3].length);",
    "options": [
      "2",
      "3",
      "4",
      "error"
    ],
    "answer": "3",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1425",
    "question": "useEffect качан иштейт? / Когда выполняется useEffect?",
    "options": [
      "Бир гана жолу / Только один раз",
      "Компонент рендерден кийин иштейт / Выполняется после рендера",
      "Компонент рендерден мурун иштейт / Выполняется до рендера",
      "Эч качан иштебейт / Никогда"
    ],
    "answer": "Компонент рендерден кийин иштейт / Выполняется после рендера",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1428",
    "question": "18. Что такое super()? / super() деген эмне?",
    "options": [
      "Новая библиотека / Жаңы китепкана",
      "Вызов родительского класса / Ата-классты чакыруу",
      "Ошибка / Ката",
      "Переменная / Өзгөрмө"
    ],
    "answer": "Вызов родительского класса / Ата-классты чакыруу",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa1427",
    "question": "18. Какой оператор «и»? / «Жана» операторы кайсы?",
    "options": [
      "&& / &&",
      "and / and",
      "& / &",
      "/"
    ],
    "answer": "/",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e8",
    "question": "9. Индексация в списке начинается с… / Тизмеде индексация эмнеден башталат?",
    "options": [
      "0 / 0",
      "1 / 1",
      "-1 / -1",
      "2 / 2"
    ],
    "answer": "0 / 0",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13eb",
    "question": "font-family эмне үчүн? Для чего font-family?",
    "options": [
      "Өлчөмү / Размер",
      "Шрифтти аныктайт / Шрифт",
      "Түс / Цвет",
      "Калыңдыгы / Толщин"
    ],
    "answer": "Шрифтти аныктайт / Шрифт",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13f2",
    "question": "Семантикалык HTML деген эмне? Что такое семантический HTML?",
    "options": [
      "Div тегдерин гана колдонуу / Использование только div",
      "Тегдерди маанисине жараша колдонуу / Использование тегов по смыслу",
      "CSS колдонуу / Использование CSS",
      "JavaScript колдонуу / Использование JavaScript"
    ],
    "answer": "Тегдерди маанисине жараша колдонуу / Использование тегов по смыслу",
    "category": "html",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.073Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13bb",
    "question": "push() методунун милдети? Что делает push()?",
    "options": [
      "Жок кылат / Удаляет",
      "Массивдин аягына кошот / Добавляет в конец",
      "Массивдин башына кошот / Добавляет в начало",
      "Сорттойт / Сортирует"
    ],
    "answer": "Массивдин аягына кошот / Добавляет в конец",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d8",
    "question": "Local state менен global state айырмасы? Разница между локальным и глобальным состоянием?",
    "options": [
      "Local — компоненттин ичинде гана, global — бардык жерде колдонулат / Local — внутри компонента, global — доступен везде",
      "Экөө бирдей / Одинаковые",
      "Global — props аркылуу / Global через props",
      "Local — Redux аркылуу / Local через Redux"
    ],
    "answer": "Local — компоненттин ичинде гана, global — бардык жерде колдонулат / Local — внутри компонента, global — доступен везде",
    "category": "react",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d6",
    "question": "Максимал туурасын чектөө? Ограничение максимальной ширины?",
    "options": [
      "width",
      "max-width",
      "min-width",
      "size"
    ],
    "answer": "max-width",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d2",
    "question": "Optional property кантип жазылат? / Как объявить optional property в TypeScript?",
    "options": [
      "name:number? / name:number?",
      "name?: number — милдеттүү эмес касиет / name?: number",
      "?name:number / ?name:number",
      "name:optional / name:optional"
    ],
    "answer": "name?: number — милдеттүү эмес касиет / name?: number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ce",
    "question": "5. Как создать приложение? / Тиркемени кантип түзүү керек?",
    "options": [
      "django-admin addapp / django-admin addapp",
      "python app.py / python app.py",
      "python manage.py startapp blog / python manage.py startapp blog",
      "django create app / django create app"
    ],
    "answer": "python manage.py startapp blog / python manage.py startapp blog",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c7",
    "question": "4. Как запустить сервер разработки? / Өнүктүрүү серверин кантип иштетүү керек?",
    "options": [
      "python run.py / python run.py",
      "python manage runserver / python manage runserver",
      "django startserver / django startserver",
      "python manage.py runserver / python manage.py runserver"
    ],
    "answer": "python manage.py runserver / python manage.py runserver",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c3",
    "question": "React Fragment эмне кылат? Что делает React Fragment?",
    "options": [
      "DOMго кошумча тег кошпой бир нече элементти топтоп берет / Группирует элементы без добавления лишнего тега в DOM",
      "CSS кошот / Добавляет CSS",
      "Router иштетет / Работает с Router",
      "Reducer түзөт / Создаёт Reducer"
    ],
    "answer": "DOMго кошумча тег кошпой бир нече элементти топтоп берет / Группирует элементы без добавления лишнего тега в DOM",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13bf",
    "question": "3. Что такое объект? / Объект деген эмне?",
    "options": [
      "Имя функции / Функциянын аты",
      "Копия класса / Класстын көчүрмөсү",
      "Модуль / Модуль",
      "Список / Тизмек"
    ],
    "answer": "Копия класса / Класстын көчүрмөсү",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c5",
    "question": "4. Какой тип данных у 3.14? / 3.14тин тиби кайсы?",
    "options": [
      "int / int",
      "str / str",
      "float / float",
      "bool / bool"
    ],
    "answer": "float / float",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e0",
    "question": "any деген эмне? / Что такое any?",
    "options": [
      "Белгисиз тип, текшерилбейт, сак болуу керек / Неопределённый тип, проверка не выполняется, нужно быть осторожным",
      "boolean / boolean",
      "string / string",
      "tuple / tuple"
    ],
    "answer": "Белгисиз тип, текшерилбейт, сак болуу керек / Неопределённый тип, проверка не выполняется, нужно быть осторожным",
    "category": "typescript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13dd",
    "question": "Button үстүнө барганда өзгөртүү? Эффект при наведении на кнопку?",
    "options": [
      ":active",
      ":focus",
      ":hover",
      ":checked"
    ],
    "answer": ":hover",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13da",
    "question": "7. Как создать список? / Тизмени кантип түзүү керек?",
    "options": [
      "(1, 2, 3) / (1, 2, 3)",
      "{1, 2, 3} / {1, 2, 3}",
      "[1, 2, 3] / [1, 2, 3]",
      "<1, 2, 3> / <1, 2, 3>"
    ],
    "answer": "[1, 2, 3] / [1, 2, 3]",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d1",
    "question": "React DOMду кантип жаңыртат? Как React обновляет DOM?",
    "options": [
      "Virtual DOM салыштыруу аркылуу, андан кийин гана керектүү өзгөртүүлөрдү жасайт / Сравнивает с Virtual DOM и обновляет только необходимые части",
      "Түздөн-түз DOMду өзгөртөт / Прямое изменение DOM",
      "API аркылуу / Через API",
      "CSS менен / Через CSS"
    ],
    "answer": "Virtual DOM салыштыруу аркылуу, андан кийин гана керектүү өзгөртүүлөрдү жасайт / Сравнивает с Virtual DOM и обновляет только необходимые части",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13cd",
    "question": "5. Как создать объект класса? / Класстын объектин кантип түзөбүз?",
    "options": [
      "MyClass[] / MyClass[]",
      "MyClass() / MyClass()",
      "object(MyClass) / object(MyClass)",
      "MyClass.create / MyClass.create"
    ],
    "answer": "MyClass() / MyClass()",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13cb",
    "question": "Ушундай жазылса string | number эмнени билдирет? / Что означает string | number?",
    "options": [
      "Строка гана / Только строка",
      "Сандын бири / Только число",
      "Строка же сан болушу мүмкүн / Может быть строка или число",
      "Белгисиз / Неизвестно"
    ],
    "answer": "Строка же сан болушу мүмкүн / Может быть строка или число",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c9",
    "question": "Кайсы оператор ката ыргытат? Какой оператор выбрасывает ошибку?**",
    "options": [
      "throw",
      "break",
      "continue",
      "default"
    ],
    "answer": "throw",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c8",
    "question": "Асты сызылган текст? Подчёркнутый текст?",
    "options": [
      "font-style: 20px",
      "text-decoration: underline",
      "border-bottom: 2px solid black",
      "outline: none"
    ],
    "answer": "text-decoration: underline",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c0",
    "question": "3. Где хранятся настройки проекта? / Долбоордун жөндөөлөрү кайда сакталат?",
    "options": [
      "manage.py / manage.py",
      "settings.py / settings.py",
      "urls.py / urls.py",
      "views.py / views.py"
    ],
    "answer": "settings.py / settings.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b8",
    "question": "2. Что такое класс? / Класс деген эмне?",
    "options": [
      "Функция / Функция",
      "Шаблон для создания объектов / Объекттерди түзүү үчүн шаблон",
      "Переменная / Өзгөрмө",
      "Таблица / Таблица"
    ],
    "answer": "Шаблон для создания объектов / Объекттерди түзүү үчүн шаблон",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b6",
    "question": "Типти кантип жазабыз? / Как указывать тип в TypeScript?",
    "options": [
      "let a = number / let a = number",
      "let a: number / let a: number",
      "a:number() / a:number()",
      "number a / number a"
    ],
    "answer": "let a: number / let a: number",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b7",
    "question": "2. Как вывести текст в консоль? / Консолго текстти кантип чыгаруу керек?",
    "options": [
      "echo(\"Hi\") / echo(\"Hi\")",
      "print(\"Hi\") / print(\"Hi\")",
      "console.log(\"Hi\") / console.log(\"Hi\")",
      "show(\"Hi\") / show(\"Hi\")"
    ],
    "answer": "print(\"Hi\") / print(\"Hi\")",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ca",
    "question": "React.StrictMode эмнени текшерет? Что проверяет React.StrictMode?",
    "options": [
      "Потенциалдуу каталарды жана туура эмес колдонуу үчүн / Выявляет потенциальные ошибки и неправильное использование",
      "Стили үчүн / Стили",
      "Маршруттар үчүн / Маршруты",
      "Performance текшерүү үчүн / Производительность"
    ],
    "answer": "Потенциалдуу каталарды жана туура эмес колдонуу үчүн / Выявляет потенциальные ошибки и неправильное использование",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13bd",
    "question": "Кайсы тип текст үчүн? / Какой тип для текста?",
    "options": [
      "number / number",
      "boolean / boolean",
      "string / string",
      "array / array"
    ],
    "answer": "string / string",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13bc",
    "question": "Keys эмне үчүн уникалдуу болуш керек? Почему ключи должны быть уникальными?",
    "options": [
      "React элементтерди туура салыштыруу жана кайра рендерди оптималдаштыруу үчүн / Чтобы React правильно сравнивал элементы и оптимизировал повторный рендер",
      "Стиль берүү үчүн / Для стилей",
      "API чакыруу үчүн / Для вызова API",
      "Router иштеши үчүн / Для работы Router"
    ],
    "answer": "React элементтерди туура салыштыруу жана кайра рендерди оптималдаштыруу үчүн / Чтобы React правильно сравнивал элементы и оптимизировал повторный рендер",
    "category": "react",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ba",
    "question": "<label> теги эмне үчүн керек? Для чего <label>?",
    "options": [
      "Баш аталыш (заголовок) / Заголовок",
      "Input менен байланыш түзөт / Связь с input",
      "Баскыч (кнопка) / Кнопка",
      "Контейнер / Контейнер"
    ],
    "answer": "Input менен байланыш түзөт / Связь с input",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13db",
    "question": "7. Что такое атрибут? / Атрибут деген эмне?",
    "options": [
      "Файл / Файл",
      "Переменная объекта / Объекттин өзгөрмөсү",
      "Метод / Метод",
      "Массив / Массив"
    ],
    "answer": "Переменная объекта / Объекттин өзгөрмөсү",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d9",
    "question": "readonly эмнени билдирет? / Что означает readonly?",
    "options": [
      "Өзгөртүүгө болот / Можно изменить",
      "Өзгөртүүгө БОЛБОЙТ — касиет тек гана окууга арналган / Нельзя изменить",
      "Көчүрөт / Копирует",
      "Өчүрөт / Удаляет"
    ],
    "answer": "Өзгөртүүгө БОЛБОЙТ — касиет тек гана окууга арналган / Нельзя изменить",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d7",
    "question": "typeof null жыйынтыгы? Результат typeof null?",
    "options": [
      "null",
      "undefined",
      "️ object",
      "number"
    ],
    "answer": "️ object",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d5",
    "question": "6. Файл маршрутов? / Маршруттар кайсы файлда?",
    "options": [
      "settings.py / settings.py",
      "views.py / views.py",
      "urls.py / urls.py",
      "admin.py / admin.py"
    ],
    "answer": "urls.py / urls.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d4",
    "question": "6. Какой метод вызывается при создании объекта? / Объект түзүлгөндө кайсы метод иштейт?",
    "options": [
      "start / start",
      "create / create",
      "init / init",
      "make / make"
    ],
    "answer": "init / init",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d0",
    "question": "break эмне кылат? Что делает break?",
    "options": [
      "Улантат / Продолжает",
      "Токтотот (циклди же switchти) / Останавливает",
      "Өтүп жиберет / Пропускает",
      "Жок кылат / Удаляет"
    ],
    "answer": "Токтотот (циклди же switchти) / Останавливает",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13cc",
    "question": "5. Как создать переменную? / Өзгөрмө кантип түзүлөт?",
    "options": [
      "var x = 5 / var x = 5",
      "int x = 5 / int x = 5",
      "x = 5 / x = 5",
      "let x = 5 / let x = 5"
    ],
    "answer": "x = 5 / x = 5",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c6",
    "question": "4. Как объявить класс? / Классты кантип түзөбүз?",
    "options": [
      "new class MyClass / new class MyClass",
      "class MyClass: / class MyClass:",
      "create MyClass / create MyClass",
      "def MyClass / def MyClass"
    ],
    "answer": "class MyClass: / class MyClass:",
    "category": "Продвинутый",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c4",
    "question": "Массивди кантип типтейбиз? / Как типизировать массив в TypeScript?",
    "options": [
      "number / number",
      "number[] — массив с числами / number[]",
      "[number] / [number]",
      "list<number> / list<number>"
    ],
    "answer": "number[] — массив с числами / number[]",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c2",
    "question": "undefined качан болот? Когда значение undefined?",
    "options": [
      "Мааниси бар өзгөрмөдө / Переменная со значением",
      "Өзгөрмө жарыяланган, бирок маани берилбегенде / Переменная объявлена, но не задана",
      "nullка барабар болгондо / Равно null",
      "Ката болгондо / Ошибка"
    ],
    "answer": "Өзгөрмө жарыяланган, бирок маани берилбегенде / Переменная объявлена, но не задана",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13be",
    "question": "3. Какой тип данных у 5? / 5тин тиби кайсы?",
    "options": [
      "str / str",
      "float / float",
      "int / int",
      "bool / bool"
    ],
    "answer": "int / int",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b9",
    "question": "2. Как создать новый проект? / Жаңы долбоорду кантип түзүү керек?",
    "options": [
      "django create project / django create project",
      "django-admin newproject / django-admin newproject",
      "django-admin startproject mysite / django-admin startproject mysite",
      "python create project / python create project"
    ],
    "answer": "django-admin startproject mysite / django-admin startproject mysite",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13de",
    "question": "map() кайтарып берет? Что возвращает map()?",
    "options": [
      "undefined / undefined",
      "Объект / Object",
      "️ Жаңы массив / Новый массив",
      "Булев тип / Boolean"
    ],
    "answer": "️ Жаңы массив / Новый массив",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13dc",
    "question": "7. Где описываются модели? / Моделдер кайсы файлда жазылат?",
    "options": [
      "models.py / models.py",
      "views.py / views.py",
      "admin.py / admin.py",
      "forms.py / forms.py"
    ],
    "answer": "models.py / models.py",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13e1",
    "question": "8. Как получить длину списка? / Тизмени узундугун кантип алуу керек?",
    "options": [
      "size() / size()",
      "count() / count()",
      "length() / length()",
      "len() / len()"
    ],
    "answer": "len() / len()",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13df",
    "question": "StrictMode Viteте иштейби? / Работает ли StrictMode в Vite?",
    "options": [
      "Ооба / Да",
      "Жок / Нет",
      "Болгон эмес / Не существует",
      "Ката чыгат / Ошибка"
    ],
    "answer": "Ооба / Да",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13d3",
    "question": "6. Какой тип данных у \"Hello\"? / \"Hello\" тиби кайсы?",
    "options": [
      "int / int",
      "str / str",
      "list / list",
      "bool / bool"
    ],
    "answer": "str / str",
    "category": "Основа",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13cf",
    "question": "Тамгалар ортосундагы аралык? Расстояние между буквами?",
    "options": [
      "word-spacing",
      "letter-spacing",
      "line-height",
      "text-align"
    ],
    "answer": "letter-spacing",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13c1",
    "question": "CSSте текстти чоң тамга кылуу? Сделать текст заглавными буквами?",
    "options": [
      "font-style: 18px",
      "text-transform: uppercase",
      "font-weight: 900",
      "text-decoration: none"
    ],
    "answer": "text-transform: uppercase",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.072Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ac",
    "question": "<strong> теги эмне кылат? Что делает тег <strong>?",
    "options": [
      "Курсив кылат / Делает курсив",
      "Астын сызат / Подчёркивает",
      "Текстти маанилүү кылат (жирный) / Делает текст важным (жирным)",
      "Тексттин түсүн өзгөртөт / Меняет цвет"
    ],
    "answer": "Текстти маанилүү кылат (жирный) / Делает текст важным (жирным)",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b2",
    "question": "1. Как установить Django? / Djangoну кантип орнотуу керек?",
    "options": [
      "pip install django / pip install django",
      "install django / install django",
      "django start / django start",
      "python django.py / python django.py"
    ],
    "answer": "pip install django / pip install django",
    "category": "Django",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b0",
    "question": "1. Что такое Python? / Python деген эмне?",
    "options": [
      "Язык разметки / Белгилөө тили",
      "Язык программирования / Программалоо тили",
      "База данных / Маалымат базасы",
      "Операционная система / Операциялык система"
    ],
    "answer": "Язык программирования / Программалоо тили",
    "category": "Основа",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b5",
    "question": "React эмне үчүн бир тараптуу маалымат агымын (one-way data flow) колдонот? Почему в React односторонний поток данных?",
    "options": [
      "Кодду ылдамырак жана туруктуураак кылуу үчүн / Чтобы код был быстрым и предсказуемым",
      "HTML талап кылат / Требует HTML",
      "CSS үчүн / Для CSS",
      "Браузер ошондой иштейт / Потому что так работает браузер"
    ],
    "answer": "Кодду ылдамырак жана туруктуураак кылуу үчүн / Чтобы код был быстрым и предсказуемым",
    "category": "react",
    "difficulty": "сложный",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ad",
    "question": "JavaScript кайсы жерде иштейт? Где работает JavaScript?",
    "options": [
      "Фак гана серверде / Только на сервере",
      "Браузерде / В браузере",
      "Фак гана база данныхта / Только в базе данных",
      "HTML тегинде / В HTML теге"
    ],
    "answer": "Браузерде / В браузере",
    "category": "javascript",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b1",
    "question": "1. Что такое ООП? / Объектке багытталган программалоо деген эмне?",
    "options": [
      "Язык программирования / Программа тили",
      "Модуль Python / Python модулу",
      "Подход к программированию / Программалоонун ыкмасы",
      "CMS система / CMS система"
    ],
    "answer": "Подход к программированию / Программалоонун ыкмасы",
    "category": "Продвинутый",
    "difficulty": "легкий",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b4",
    "question": "Функция кантип жазылат? Как объявить функцию?",
    "options": [
      "function myFunc() {}",
      "const myFunc = () => {}",
      "myFunc = function() {}",
      "Все варианты"
    ],
    "answer": "Все варианты",
    "category": "javascript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13b3",
    "question": "<em> теги эмнени билдирет? Что означает <em>?",
    "options": [
      "Жирный текст / Жирный текст",
      "Акцент (курсив) / Акцент (курсив)",
      "Баш аталыш (заголовок) / Заголовок",
      "Шилтеме / Ссылка"
    ],
    "answer": "Акцент (курсив) / Акцент (курсив)",
    "category": "html",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13af",
    "question": "TypeScript код браузерде иштеши үчүн эмне болуш керек? / Чтобы код TypeScript работал в браузере?",
    "options": [
      "Түз иштейт / Работает напрямую",
      "JavaScriptке айланышы керек (compile) / Должен быть скомпилирован в JavaScript",
      "CSS керек / Нужен CSS",
      "Framework керек / Нужен фреймворк"
    ],
    "answer": "JavaScriptке айланышы керек (compile) / Должен быть скомпилирован в JavaScript",
    "category": "typescript",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.071Z"
  },
  {
    "_id": "697498d6f72c0a6e41fa13ae",
    "question": "Компонент качан кайра рендер болот? / Когда компонент выполняет повторный рендер?",
    "options": [
      "props же state өзгөргөндө / При изменении props/state",
      "CSS өзгөргөндө / При изменении CSS",
      "console.log жазганда / При вызове console.log",
      "Файл атын өзгөрткөндө / При изменении имени файла"
    ],
    "answer": "props же state өзгөргөндө / При изменении props/state",
    "category": "react",
    "difficulty": "средний",
    "createdAt": "2026-01-24T10:03:02.071Z"
  }
]

// 1. Главная функция отрисовки
function showQuestions(category) {
  const container = document.getElementById('quiz-container');
  container.innerHTML = ''; // Очищаем контейнер перед новой отрисовкой

  // Фильтруем данные: если категория 'all' — берем всё, иначе только нужную
  const filtered = category === 'all'
    ? data
    : data.filter(item => item.category === category);

  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div>
          <span class="badge ${item.category}">${item.category}</span>
          <span class="difficulty">Уровень: ${item.difficulty}</span>
      </div>
      <h3>${item.question}</h3>
      <div class="options">
          ${item.options.map(opt => `<div class="option">• ${opt}</div>`).join('')}
      </div>
      <button class="btn-hint" onclick="toggleAnswer('${item._id}')">💡</button>
      <div id="ans-${item._id}" class="answer" style="display:none">
          <strong>Ответ:</strong> ${item.answer}
      </div>
    `;
    container.appendChild(card);
  });
}

// 2. Функция переключения ответа
function toggleAnswer(id) {
  const ansDiv = document.getElementById(`ans-${id}`);
  ansDiv.style.display = (ansDiv.style.display === 'block') ? 'none' : 'block';
}

// 3. Вешаем события на кнопки табов
document.querySelectorAll('#tabs button').forEach(button => {
  button.addEventListener('click', () => {
    // Берем текст кнопки и приводим к нижнему регистру (js, html, react)
    const category = button.textContent.toLowerCase();
    showQuestions(category);
  });
});

// Инициализация: показываем всё при загрузке
showQuestions('all');